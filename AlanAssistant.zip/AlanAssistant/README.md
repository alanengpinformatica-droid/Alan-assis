# ALAN ASSISTANT

Assistente pessoal para Android, em português, feito para uma pessoa só: o Alan.

Fala e escuta, cria tarefas, lembretes, rotinas e compromissos, avisa na hora
certa mesmo com o app fechado e o celular reiniciado, e guarda memória
permanente em um banco local. Funciona sem internet.

---

## Por que Kotlin nativo e não Python

Você prefere Python, e eu levei isso a sério antes de decidir. A escolha foi
Kotlin nativo por um motivo específico, não por gosto:

O requisito número 1 do escopo é **o lembrete não pode falhar**. No Android,
isso depende de três coisas que só funcionam de forma confiável em código
nativo:

| O que é preciso | Kivy/BeeWare (Python) | Kotlin nativo |
|---|---|---|
| Alarme exato em modo Doze (`setExactAndAllowWhileIdle`) | acesso indireto via pyjnius, frágil entre versões | API direta |
| Reagendar tudo após reiniciar o celular (`BOOT_COMPLETED`) | receiver precisa de Java/Kotlin mesmo assim | nativo |
| Botões de ação na notificação (Concluir / Adiar) | não suportado de forma estável | nativo |
| Reconhecimento de voz e síntese pt-BR do sistema | wrappers incompletos | API direta |
| Tamanho e consumo do APK | +30 MB de runtime Python, bateria maior | leve |

Buildozer falharia justamente no item que mais importa para você. Chaquopy
(Python dentro de um app Android) resolveria a parte de lógica, mas ainda
exigiria escrever toda a camada de alarmes e notificações em Kotlin — ou seja,
o trabalho nativo não desaparece, só ganha uma ponte a mais para dar problema.

**Onde o Python ainda cabe**: o interpretador é uma interface
(`core/Intents.kt` → `interface Interpreter`). Qualquer implementação que
receba texto e devolva um `ParsedIntent` serve. Se um dia você quiser rodar
sua lógica de interpretação em Python via Chaquopy, é aí que ela pluga, sem
tocar em mais nada.

---

## Arquitetura

```
   VOZ ou TEXTO
        │
        ▼
  RuleBasedInterpreter      ← offline, determinístico, SEMPRE primeiro
        │  (confiança baixa?)
        ▼
   AiInterpreter            ← opcional, só com chave configurada
        │
        ▼
   ParsedIntent
        │
        ▼
  IntentValidator           ← OBRIGATÓRIO, inclusive para a saída da IA
        │
        ▼
  AssistantEngine           ← único componente que escreve no banco
        │
   ┌────┴─────┐
   ▼          ▼
 Room     AlarmManager → Notificação (Concluir / Adiar 30 min)
```

### Decisão central: núcleo em Kotlin puro

O pacote `com.alan.assistant.core` **não importa nada de Android**. Ele conhece
só interfaces (`TaskStore`, `ReminderStore`, `AlarmPort`, `ClockPort`…), que o
Room e o AlarmManager implementam no app e que implementações em memória
implementam nos testes.

Consequência prática: **toda a lógica roda e é testada na JVM, sem emulador.**
Foi isso que permitiu executar as 107 verificações de verdade durante o
desenvolvimento e achar bugs reais antes de qualquer build Android.

### Por que a IA nunca toca o banco

A IA é útil para entender frases estranhas e péssima para ser fonte de verdade.
Aqui ela só produz um `ParsedIntent`, que ainda passa pelo `IntentValidator`
(rejeita data no passado, data absurda, título vazio). Se a chave não existir,
se cair a internet ou se a API devolver lixo, o resultado é `UNKNOWN` e o
interpretador de regras assume. **O app nunca fica pior por causa da IA.**

### Por que não usamos `setRepeating`

Alarmes repetitivos do Android são inexatos e não entendem "toda sexta" ou
"primeiro dia útil do mês". Cada disparo calcula a próxima ocorrência (lógica
testada na JVM) e agenda um novo alarme exato. Um alarme por vez, sempre certo.

---

## O que funciona sem internet

| Recurso | Offline? |
|---|---|
| Entender comandos, criar tarefas/lembretes/rotinas | sim, sempre |
| Alarmes, notificações, resumos, recorrência | sim, sempre |
| Banco de dados e memória permanente | sim, sempre |
| Backup e exportação | sim, sempre |
| Assistente falando (TTS) | sim, se o pacote de voz pt-BR estiver instalado |
| Alan falando (reconhecimento) | depende do aparelho; Android 12+ costuma ter modelo local. Sem ele, cai para digitação automaticamente |
| Camada de IA | não — e é opcional |

---

## Confiabilidade dos lembretes

Três camadas independentes, porque uma só não basta:

1. **AlarmManager com `setExactAndAllowWhileIdle`** — dispara na hora exata,
   mesmo com a tela desligada.
2. **`BootReceiver`** — após reiniciar o celular, atualizar o app, mudar a hora
   ou o fuso, reconstrói todos os alarmes a partir do banco.
3. **`MaintenanceWorker`** — a cada ~4 horas e sempre que o app abre: reagenda
   tudo, **dispara os lembretes que ficaram para trás** (celular desligado na
   hora), garante os resumos e marca tarefas vencidas como atrasadas.

Se o celular estava desligado às 16h, você recebe o lembrete quando ligar, com
a marca "(atrasado)". Perder, não perde.

---

## Segurança e privacidade

- Nenhuma chave de API no código ou no APK. Ela vive no
  `EncryptedSharedPreferences`, cifrada por uma chave do Android Keystore.
- O arquivo de segredos é **excluído do backup do Google** (`backup_rules.xml`).
- PIN guardado como SHA-256 com salt aleatório e 20 mil iterações. Comparação
  em tempo constante.
- Desbloqueio por biometria/credencial do aparelho, com PIN como alternativa.
- Voz **não** é usada como autenticação — uma gravação enganaria o app.
- Sem chave de IA configurada, **nada sai do aparelho**.

---

## Estrutura do projeto

```
app/src/main/java/com/alan/assistant/
├── core/            Kotlin puro — testado na JVM
│   ├── Models.kt              modelos de domínio
│   ├── Recurrence.kt          recorrência + cálculo da próxima ocorrência
│   ├── PtBrDateTime.kt        parser de data/hora em português
│   ├── RuleBasedInterpreter.kt   classificação offline de intenção
│   ├── IntentValidator.kt     sanidade temporal e de conteúdo
│   ├── AssistantEngine.kt     motor de negócio
│   ├── Summaries.kt           resumos diário/noturno/semanal
│   ├── Ports.kt               interfaces (banco, alarme, relógio)
│   └── Intents.kt             contrato com a camada de interpretação
├── data/            Room: entidades, DAOs, banco, implementação das portas
├── ai/              camada de IA isolada + combinador regras/IA
├── alarm/           agendador de alarmes exatos e receivers
├── notify/          notificações com ações
├── voice/           TTS e reconhecimento de fala
├── security/        segredos cifrados, biometria e PIN
├── backup/          exportação JSON/CSV/SQLite e restauração
├── work/            worker de manutenção e recuperação
├── ui/              Compose: tema, telas e ViewModel
└── AlanApp.kt       Application + injeção manual de dependências

app/src/test/        107 verificações na JVM (CoreTest.kt)
app/src/androidTest/ testes de Room e integração (DatabaseTest.kt)
```

---

## Banco de dados

10 tabelas: `users`, `tasks`, `reminders`, `memories`, `events`, `routines`,
`conversations`, `notifications`, `settings`, `audit_log`.

Duas decisões que valem citar:

- **Enums e recorrência gravados como texto.** Adicionar um novo tipo de
  recorrência no futuro não exige migração de banco.
- **`fallbackToDestructiveMigration` nunca é usado.** Se o esquema mudar sem
  migração, o app prefere falhar ao abrir a apagar seus dados. O esquema é
  exportado para `app/schemas/`, que é o que permite escrever migrações com
  segurança. As instruções estão no cabeçalho de `AlanDatabase.kt`.

---

## Testes

```bash
./gradlew testDebugUnitTest          # 107 verificações, ~2 s, sem emulador
./gradlew connectedDebugAndroidTest  # banco real, precisa de celular/emulador
```

As 107 verificações cobrem: parser de datas em português (incluindo "daqui a
meia hora", "às 2 da tarde", "primeiro dia útil do mês"), recorrência, cálculo
da próxima ocorrência com clamp de dia do mês (31 de janeiro → 28 de
fevereiro), classificação de intenção, extração de título, fluxo completo do
motor, desambiguação ("qual relatório?"), disparo e reagendamento,
recuperação após reinicialização, resumos e rejeição de entradas inválidas.

**Bugs reais que esses testes encontraram durante o desenvolvimento:**

1. "Me lembra de **concluir** o relatório" era lido como *concluir tarefa*.
2. "Todo dia às 7h me lembra de revisar **minhas tarefas**" caía em consulta.
3. Lembrete com dia mas sem hora inventava um horário em vez de perguntar.
4. Responder só com o horário perdia o dia já combinado.
5. Lembrete de prazo de tarefa não herdava o dia do prazo.

Todos corrigidos.

---

## Riscos técnicos conhecidos

**1. Fabricantes agressivos com bateria.** Xiaomi, Samsung, Motorola e Oppo
matam apps em segundo plano mais do que o Android padrão. O app pede isenção da
otimização de bateria e tem o `MaintenanceWorker` como rede de segurança, mas
em aparelhos muito restritivos o lembrete pode chegar com minutos de atraso.
Mitigação: liberar o app na lista de exceções do fabricante (passo 8 do guia de
instalação).

**2. Permissão de alarme exato.** No Android 12, `SCHEDULE_EXACT_ALARM` pode ser
revogada pelo usuário. O app detecta, avisa na tela inicial e cai para alarme
aproximado em vez de perder o lembrete.

**3. Pacote de voz pt-BR ausente.** Alguns aparelhos vêm sem ele. O app detecta
e continua respondendo por texto.

**4. Reconhecimento de fala sem internet.** Depende do aparelho. Sem ele, o
campo de texto assume — nada trava.

**5. A camada Android não foi compilada no ambiente onde foi escrita.** Não
havia Android SDK disponível. O núcleo Kotlin foi compilado e testado de
verdade (107/107 verdes), mas a camada Android — Room, Compose, receivers —
pode exigir pequenos ajustes de versão no primeiro sync do Android Studio.
É o tipo de coisa que o próprio Android Studio aponta e resolve.

---

## O que ficou para a versão 2

Conforme o item 21 do escopo, estas integrações não entraram na v1 porque
dependem de credenciais externas, revisão de segurança corporativa ou de
infraestrutura que não existe no aparelho:

- Google Calendar e Outlook Calendar (OAuth + política da empresa)
- WhatsApp e e-mail (APIs de terceiros, envio automatizado)
- Microsoft Teams (registro de app corporativo)
- Dashboard web e sincronização entre dispositivos (exigiria servidor)
- Widget na tela inicial e atalhos do Assistente do Google

O banco e o motor já estão prontos para isso: `events` tem campo de local e
notas, e `AlarmPort` é uma interface — uma implementação que também escreva
no Google Calendar entra sem mexer no motor.

---

## Licença de uso

Projeto pessoal do Alan. Sem dependências pagas, sem telemetria, sem
servidor. Tudo roda no aparelho.
