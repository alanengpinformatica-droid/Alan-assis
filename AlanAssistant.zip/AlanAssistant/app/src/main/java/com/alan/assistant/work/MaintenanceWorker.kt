package com.alan.assistant.work

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.alan.assistant.AlanApp
import com.alan.assistant.core.ReminderKind
import java.util.concurrent.TimeUnit

/**
 * Rede de segurança do sistema de lembretes (itens 18, 19 e 29).
 *
 * Roda depois do boot e, de forma periódica, a cada ~4 horas. Em cada execução:
 *
 *  1. reagenda no AlarmManager todos os lembretes ativos do banco;
 *  2. dispara imediatamente os que ficaram PARA TRÁS (celular desligado na
 *     hora do lembrete, por exemplo) — o Alan é avisado com atraso,
 *     mas NUNCA perde o lembrete;
 *  3. garante que os lembretes de resumo diário/noturno existam e estejam
 *     no horário configurado;
 *  4. marca como ATRASADA as tarefas cujo prazo passou;
 *  5. poda o histórico para o banco não crescer sem limite.
 *
 * É trabalho curto e espaçado: não há serviço em primeiro plano nem loop,
 * o consumo de bateria é desprezível.
 */
class MaintenanceWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext as? AlanApp ?: return Result.success()
        val deBoot = inputData.getBoolean(CHAVE_BOOT, false)

        return try {
            val c = app.container

            // 3. Resumos configurados
            c.engine.garantirResumos(
                horaManha = c.settings.getHora(
                    com.alan.assistant.data.Settings.RESUMO_MANHA, 7
                ),
                horaNoite = c.settings.getHora(
                    com.alan.assistant.data.Settings.RESUMO_NOITE, 21
                )
            )

            // 1. Reagendamento + 2. lembretes perdidos
            val perdidos = c.engine.reagendarTudo()
            for (r in perdidos) {
                val lembrete = c.reminders.byId(r.id) ?: continue
                val disparo = c.engine.dispararLembrete(r.id) ?: continue
                c.notifier.mostrarLembrete(
                    reminderId = disparo.reminderId,
                    titulo = disparo.titulo,
                    corpo = if (deBoot) "${disparo.texto} (atrasado)" else disparo.texto,
                    taskId = disparo.taskId,
                    kind = lembrete.kind
                )
            }

            // 4. Tarefas vencidas
            c.engine.atualizarAtrasadas()

            // 5. Poda de histórico
            runCatching {
                c.db.conversationDao().podar(MAX_CONVERSAS)
                c.db.auditDao().podar(MAX_AUDITORIA)
            }

            Log.i(TAG, "Manutenção concluída. Perdidos reapresentados: ${perdidos.size}")
            Result.success()
        } catch (e: Throwable) {
            Log.e(TAG, "Falha na manutenção: ${e.message}", e)
            // Tenta de novo mais tarde em vez de desistir silenciosamente.
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }

    companion object {
        private const val TAG = "AlanManutencao"
        private const val CHAVE_BOOT = "de_boot"
        private const val MAX_CONVERSAS = 2000
        private const val MAX_AUDITORIA = 5000

        const val TRABALHO_BOOT = "alan_manutencao_boot"
        const val TRABALHO_PERIODICO = "alan_manutencao_periodica"

        fun dadosDeBoot(): Data = Data.Builder().putBoolean(CHAVE_BOOT, true).build()

        /** Chamado no Application. Idempotente. */
        fun agendarPeriodico(context: Context) {
            val pedido = PeriodicWorkRequestBuilder<MaintenanceWorker>(4, TimeUnit.HOURS)
                .build()
            WorkManager.getInstance(context.applicationContext)
                .enqueueUniquePeriodicWork(
                    TRABALHO_PERIODICO,
                    ExistingPeriodicWorkPolicy.KEEP,
                    pedido
                )
        }

        /** Usado pelo app ao abrir, para recuperar o estado o quanto antes. */
        fun agendarAgora(context: Context) {
            val pedido = androidx.work.OneTimeWorkRequestBuilder<MaintenanceWorker>().build()
            WorkManager.getInstance(context.applicationContext)
                .enqueueUniqueWork(
                    "alan_manutencao_imediata",
                    androidx.work.ExistingWorkPolicy.REPLACE,
                    pedido
                )
        }

        @Suppress("unused")
        private val tiposDeResumo = listOf(ReminderKind.DAILY_SUMMARY, ReminderKind.NIGHT_SUMMARY)
    }
}
