package com.alan.assistant.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

/**
 * Configurações (item 33 do escopo).
 *
 * Tudo o que muda o comportamento do assistente está aqui, sem menus
 * escondidos: voz, horários dos resumos, IA opcional, bloqueio e backup.
 */
@Composable
fun SettingsScreen(vm: AssistantViewModel, aoNavegar: (String) -> Unit = {}) {
    val ctx = LocalContext.current

    var fala by remember { mutableStateOf(vm.falaAtiva()) }
    var ia by remember { mutableStateOf(vm.iaAtiva()) }
    var temChave by remember { mutableStateOf(vm.temChaveIa()) }
    var chave by remember { mutableStateOf("") }
    var bloqueio by remember { mutableStateOf(vm.bloqueioAtivo()) }
    var pin by remember { mutableStateOf("") }
    var manha by remember { mutableStateOf(vm.horaResumo(true)) }
    var noite by remember { mutableStateOf(vm.horaResumo(false)) }
    var mensagem by remember { mutableStateOf<String?>(null) }

    val salvarBackup = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? -> uri?.let { vm.exportarPara(it) { m -> mensagem = m } } }

    val abrirBackup = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { vm.restaurarDe(it) { m -> mensagem = m } } }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        mensagem?.let {
            Card(Modifier.fillMaxWidth()) {
                Text(it, Modifier.padding(14.dp), style = MaterialTheme.typography.bodyLarge)
            }
        }

        Secao("Outras telas") {
            OutlinedButton(onClick = { aoNavegar(Rota.ROTINAS) }, Modifier.fillMaxWidth()) {
                Text("Rotinas")
            }
            OutlinedButton(onClick = { aoNavegar(Rota.HISTORICO) }, Modifier.fillMaxWidth()) {
                Text("Histórico de ações")
            }
        }

        // ---------------- Voz ----------------
        Secao("Voz") {
            LinhaSwitch("Responder falando", fala) {
                fala = it
                vm.definirFala(it)
            }
            Text(
                "A voz em português precisa do pacote de fala do aparelho. Se faltar, baixe em " +
                    "Configurações do Android > Idiomas > Saída de texto para voz.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // ---------------- Resumos ----------------
        Secao("Resumos automáticos") {
            SeletorHora("Resumo da manhã", manha) {
                manha = it
                vm.definirResumo(true, it)
            }
            SeletorHora("Resumo da noite", noite) {
                noite = it
                vm.definirResumo(false, it)
            }
        }

        // ---------------- Lembretes ----------------
        Secao("Lembretes") {
            Text(
                if (vm.podeAgendarExato())
                    "Alarmes exatos ativos. Os lembretes tocam na hora certa mesmo com a tela desligada."
                else
                    "Alarmes exatos desativados. Os lembretes podem atrasar alguns minutos.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    OutlinedButton(onClick = {
                        runCatching {
                            ctx.startActivity(
                                Intent(AndroidSettings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                            )
                        }
                    }) { Text("Ajustar alarmes") }
                }
                OutlinedButton(onClick = {
                    runCatching {
                        ctx.startActivity(Intent(AndroidSettings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    }
                }) { Text("Bateria") }
            }
            Text(
                "Se o fabricante do seu celular for agressivo com economia de bateria (Xiaomi, " +
                    "Samsung, Motorola), libere o Alan Assistant na lista de exceções — é o que " +
                    "garante que o lembrete toque.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // ---------------- IA opcional ----------------
        Secao("Compreensão por IA (opcional)") {
            Text(
                "O app entende os comandos do dia a dia sem internet. A IA entra só quando as " +
                    "regras não entendem a frase. Sem chave configurada, nada é enviado para fora " +
                    "do aparelho.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            LinhaSwitch("Usar IA quando eu não entender", ia) {
                ia = it
                vm.definirIa(it)
            }
            OutlinedTextField(
                value = chave,
                onValueChange = { chave = it },
                label = { Text(if (temChave) "Trocar chave da API" else "Chave da API") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        vm.salvarChaveIa(chave)
                        temChave = chave.isNotBlank()
                        chave = ""
                        mensagem = if (temChave) "Chave salva." else "Chave removida."
                    },
                    enabled = chave.isNotBlank()
                ) { Text("Salvar chave") }
                if (temChave) {
                    OutlinedButton(onClick = {
                        vm.salvarChaveIa(null)
                        temChave = false
                        mensagem = "Chave removida. O app segue funcionando offline."
                    }) { Text("Remover") }
                }
            }
        }

        // ---------------- Segurança ----------------
        Secao("Segurança") {
            LinhaSwitch("Pedir biometria ou PIN ao abrir", bloqueio) {
                bloqueio = it
                vm.definirBloqueio(it)
            }
            OutlinedTextField(
                value = pin,
                onValueChange = { novo -> pin = novo.filter { it.isDigit() }.take(8) },
                label = { Text(if (vm.temPin()) "Trocar PIN" else "Definir PIN (4 a 8 dígitos)") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    keyboardType = KeyboardType.NumberPassword
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    vm.definirPin(pin)
                    pin = ""
                    mensagem = "PIN salvo."
                },
                enabled = pin.length in 4..8
            ) { Text("Salvar PIN") }
        }

        // ---------------- Backup ----------------
        Secao("Backup e exportação") {
            Text(
                "O backup completo sai em JSON, CSV e uma cópia do banco. Nada é enviado para " +
                    "a nuvem: os arquivos ficam no seu aparelho.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { vm.exportar { m -> mensagem = m } }, Modifier.fillMaxWidth()) {
                Text("Gerar backup na pasta do app")
            }
            OutlinedButton(
                onClick = { salvarBackup.launch("alan_backup.json") },
                Modifier.fillMaxWidth()
            ) { Text("Salvar backup onde eu escolher") }
            OutlinedButton(
                onClick = { abrirBackup.launch(arrayOf("*/*")) },
                Modifier.fillMaxWidth()
            ) { Text("Restaurar de um arquivo .db") }
            Text(
                "Restaurar substitui todos os dados atuais. O banco de antes é guardado " +
                    "automaticamente na pasta de backups.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // ---------------- Ajuda ----------------
        Secao("O que eu entendo") {
            Text(vm.ajuda(), style = MaterialTheme.typography.bodyLarge)
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Secao(titulo: String, conteudo: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(titulo, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            HorizontalDivider(Modifier.padding(vertical = 10.dp))
            conteudo()
        }
    }
}

@Composable
private fun LinhaSwitch(rotulo: String, valor: Boolean, aoMudar: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(rotulo, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = valor, onCheckedChange = aoMudar)
    }
}

@Composable
private fun SeletorHora(rotulo: String, hora: Int?, aoMudar: (Int?) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(rotulo, style = MaterialTheme.typography.bodyLarge)
            Text(
                if (hora == null) "desligado" else "%02d:00".format(hora),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        OutlinedButton(onClick = { aoMudar(if (hora == null) 7 else null) }) {
            Text(if (hora == null) "Ligar" else "Desligar")
        }
        if (hora != null) {
            OutlinedButton(onClick = { aoMudar(((hora + 1) % 24)) }) { Text("+1 h") }
        }
    }
}
