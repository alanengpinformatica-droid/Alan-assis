package com.alan.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale

/**
 * VOZ (itens 13 e 14 do escopo).
 *
 * O QUE FUNCIONA OFFLINE E O QUE PRECISA DE INTERNET
 * --------------------------------------------------
 * SÍNTESE DE VOZ (o assistente falando): funciona OFFLINE na grande maioria
 *   dos aparelhos, desde que o pacote de voz pt-BR esteja baixado
 *   (Configurações > Sistema > Idiomas > Saída de texto para voz > baixar).
 *   Se faltar o pacote, a classe avisa e o app continua respondendo por texto.
 *
 * RECONHECIMENTO DE FALA (o Alan falando): na maioria dos Android é um
 *   serviço do Google que usa a internet. A partir do Android 12 muitos
 *   aparelhos têm reconhecimento no próprio dispositivo — pedimos isso com
 *   `EXTRA_PREFER_OFFLINE`, e o sistema usa offline quando puder.
 *   Sem internet e sem modelo local, o reconhecimento falha; nesse caso o app
 *   cai automaticamente para a digitação (fallback), sem travar.
 *
 * INTERPRETAÇÃO: as regras (RuleBasedInterpreter) são 100% offline.
 *   Só a camada opcional de IA usa internet.
 *
 * Ou seja: o app inteiro é utilizável sem internet — no pior caso,
 * digitando em vez de falando.
 */

/** Síntese de voz em pt-BR. */
class Speaker(context: Context) {

    private var tts: TextToSpeech? = null
    @Volatile private var pronto = false
    @Volatile private var idiomaOk = false
    private var pendente: String? = null

    /** Ligado/desligado pelo Alan nas Configurações (item 13). */
    @Volatile var ativo: Boolean = true

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val resultado = tts?.setLanguage(Locale("pt", "BR"))
                idiomaOk = resultado != TextToSpeech.LANG_MISSING_DATA &&
                    resultado != TextToSpeech.LANG_NOT_SUPPORTED
                if (!idiomaOk) {
                    Log.w(TAG, "Voz pt-BR não instalada neste aparelho")
                }
                tts?.setSpeechRate(1.0f)
                pronto = true
                pendente?.let { falar(it); pendente = null }
            } else {
                Log.w(TAG, "TextToSpeech indisponível (status=$status)")
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {}
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                Log.w(TAG, "Falha ao falar ($utteranceId)")
            }
        })
    }

    fun disponivel(): Boolean = pronto && idiomaOk

    fun falar(texto: String) {
        if (!ativo || texto.isBlank()) return
        if (!pronto) { pendente = texto; return }
        if (!idiomaOk) return
        try {
            tts?.speak(texto, TextToSpeech.QUEUE_FLUSH, null, "alan-${System.currentTimeMillis()}")
        } catch (e: Throwable) {
            Log.e(TAG, "Erro ao falar: ${e.message}", e)
        }
    }

    fun parar() {
        runCatching { tts?.stop() }
    }

    fun liberar() {
        runCatching {
            tts?.stop()
            tts?.shutdown()
        }
        tts = null
        pronto = false
    }

    companion object { private const val TAG = "AlanSpeaker" }
}

/**
 * Reconhecimento de fala com tratamento de ruído e mensagens amigáveis.
 *
 * Exige a permissão RECORD_AUDIO, pedida pela MainActivity.
 */
class Listener(private val context: Context) {

    private var recognizer: SpeechRecognizer? = null
    @Volatile private var ouvindo = false

    fun disponivel(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    /**
     * @param aoTexto recebe o texto reconhecido.
     * @param aoErro recebe uma mensagem já traduzida para o Alan.
     * @param aoNivel recebe o nível de voz (0..10) para animar o botão.
     */
    fun ouvir(
        aoTexto: (String) -> Unit,
        aoErro: (String) -> Unit,
        aoNivel: (Float) -> Unit = {},
        aoFim: () -> Unit = {}
    ) {
        if (ouvindo) return
        if (!disponivel()) {
            aoErro("Este aparelho não tem reconhecimento de voz. Pode digitar que eu entendo igual.")
            return
        }

        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { ouvindo = true }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {
                        aoNivel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f) * 10f)
                    }
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { ouvindo = false }

                    override fun onError(error: Int) {
                        ouvindo = false
                        aoErro(traduzirErro(error))
                        aoFim()
                    }

                    override fun onResults(results: Bundle?) {
                        ouvindo = false
                        val lista = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val texto = lista?.firstOrNull()?.trim().orEmpty()
                        if (texto.isEmpty()) {
                            aoErro("Não consegui entender. Pode repetir?")
                        } else {
                            aoTexto(texto)
                        }
                        aoFim()
                    }

                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                startListening(montarIntent())
            }
        } catch (e: Throwable) {
            ouvindo = false
            Log.e(TAG, "Falha ao iniciar escuta: ${e.message}", e)
            aoErro("Não consegui ligar o microfone. Pode digitar.")
            aoFim()
        }
    }

    private fun montarIntent(): Intent =
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            // Tolerância a ruído: espera um pouco mais antes de cortar a fala.
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1200L)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // Usa o modelo do próprio aparelho quando existir (sem internet).
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
        }

    fun parar() {
        runCatching { recognizer?.stopListening() }
        ouvindo = false
    }

    fun liberar() {
        runCatching { recognizer?.destroy() }
        recognizer = null
        ouvindo = false
    }

    private fun traduzirErro(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_AUDIO -> "Problema no microfone. Tente de novo."
        SpeechRecognizer.ERROR_CLIENT -> "O reconhecimento foi interrompido."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
            "Preciso da permissão de microfone. Autorize nas configurações do app."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
            "Sem internet para reconhecer a fala. Pode digitar que funciona igual."
        SpeechRecognizer.ERROR_NO_MATCH -> "Não entendi. Pode repetir?"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Ainda estou processando a fala anterior."
        SpeechRecognizer.ERROR_SERVER -> "O serviço de voz falhou. Pode digitar."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Não ouvi nada. Toque e fale de novo."
        else -> "Não consegui reconhecer a fala. Pode digitar."
    }

    companion object { private const val TAG = "AlanListener" }
}
