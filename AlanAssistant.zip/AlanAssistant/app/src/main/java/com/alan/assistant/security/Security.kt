package com.alan.assistant.security

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.util.Log
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * SEGURANÇA E PRIVACIDADE (itens 16 e 20 do escopo).
 *
 * - A chave da API e o PIN ficam em EncryptedSharedPreferences, cifrados por
 *   uma chave do Android Keystore (que não sai do hardware seguro).
 * - NENHUMA chave aparece no código-fonte nem no APK.
 * - O arquivo `alan_secrets.xml` é explicitamente EXCLUÍDO do backup do
 *   Google (ver res/xml/backup_rules.xml).
 * - O desbloqueio usa biometria do aparelho, com PIN próprio como alternativa.
 *   O PIN é guardado só como hash SHA-256 + salt aleatório, nunca em claro.
 * - Reconhecimento de voz NÃO é usado como autenticação: é fácil de enganar
 *   com uma gravação. Ele serve apenas como entrada de comandos.
 */
class SecretsStore(context: Context) {

    private val prefs: SharedPreferences = criar(context.applicationContext)

    private fun criar(context: Context): SharedPreferences = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            ARQUIVO,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Throwable) {
        // Alguns aparelhos com Keystore corrompido falham aqui. Em vez de
        // impedir o uso do app, caímos para prefs normais SEM guardar segredos.
        Log.e(TAG, "Keystore indisponível, segredos desabilitados: ${e.message}", e)
        context.getSharedPreferences("alan_secrets_fallback", Context.MODE_PRIVATE)
    }

    // ---------------- Chave da API (opcional) ----------------

    fun apiKey(): String? = prefs.getString(CHAVE_API, null)?.ifBlank { null }

    fun salvarApiKey(chave: String?) {
        prefs.edit().apply {
            if (chave.isNullOrBlank()) remove(CHAVE_API) else putString(CHAVE_API, chave.trim())
        }.apply()
    }

    fun temApiKey(): Boolean = !apiKey().isNullOrBlank()

    // ---------------- PIN ----------------

    fun definirPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val saltHex = salt.joinToString("") { "%02x".format(it) }
        prefs.edit()
            .putString(CHAVE_PIN_SALT, saltHex)
            .putString(CHAVE_PIN_HASH, hash(pin, saltHex))
            .apply()
    }

    fun temPin(): Boolean = prefs.getString(CHAVE_PIN_HASH, null) != null

    fun conferirPin(pin: String): Boolean {
        val salt = prefs.getString(CHAVE_PIN_SALT, null) ?: return false
        val esperado = prefs.getString(CHAVE_PIN_HASH, null) ?: return false
        return constanteIgual(hash(pin, salt), esperado)
    }

    fun removerPin() {
        prefs.edit().remove(CHAVE_PIN_HASH).remove(CHAVE_PIN_SALT).apply()
    }

    private fun hash(pin: String, saltHex: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        // 20 mil iterações: barato para o aparelho, caro para força bruta.
        var atual = (saltHex + pin).toByteArray(Charsets.UTF_8)
        repeat(20_000) { atual = md.digest(atual) }
        return atual.joinToString("") { "%02x".format(it) }
    }

    /** Comparação em tempo constante — evita ataque por medição de tempo. */
    private fun constanteIgual(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var diff = 0
        for (i in a.indices) diff = diff or (a[i].code xor b[i].code)
        return diff == 0
    }

    companion object {
        private const val TAG = "AlanSecrets"
        const val ARQUIVO = "alan_secrets"
        private const val CHAVE_API = "anthropic_api_key"
        private const val CHAVE_PIN_HASH = "pin_hash"
        private const val CHAVE_PIN_SALT = "pin_salt"
    }
}

/**
 * Porta de entrada do app quando o bloqueio está ativo.
 *
 * Tenta biometria/credencial do aparelho (digital, rosto, padrão do celular).
 * Se o aparelho não tiver nada disso, cai para o PIN interno do app.
 */
class AuthGate(private val activity: FragmentActivity) {

    enum class Disponibilidade { BIOMETRIA, CREDENCIAL_DO_APARELHO, NENHUMA }

    fun disponibilidade(): Disponibilidade {
        val bm = BiometricManager.from(activity)
        val forte = bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)
        if (forte == BiometricManager.BIOMETRIC_SUCCESS) return Disponibilidade.BIOMETRIA

        val credencial = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            bm.canAuthenticate(BiometricManager.Authenticators.DEVICE_CREDENTIAL)
        } else {
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE
        }
        if (credencial == BiometricManager.BIOMETRIC_SUCCESS) {
            return Disponibilidade.CREDENCIAL_DO_APARELHO
        }
        return Disponibilidade.NENHUMA
    }

    /**
     * @param aoSucesso chamado na main thread quando o Alan se autentica.
     * @param aoFalhar recebe uma mensagem amigável (ou null se o usuário cancelou).
     */
    fun pedirAutenticacao(aoSucesso: () -> Unit, aoFalhar: (String?) -> Unit) {
        val tipos = when (disponibilidade()) {
            Disponibilidade.BIOMETRIA ->
                BiometricManager.Authenticators.BIOMETRIC_WEAK or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            Disponibilidade.CREDENCIAL_DO_APARELHO ->
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
            Disponibilidade.NENHUMA -> {
                aoFalhar("Este aparelho não tem biometria nem bloqueio de tela. Use o PIN do app.")
                return
            }
        }

        val prompt = BiometricPrompt(
            activity,
            androidx.core.content.ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    aoSucesso()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    val cancelou = errorCode == BiometricPrompt.ERROR_USER_CANCELED ||
                        errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON
                    aoFalhar(if (cancelou) null else errString.toString())
                }
            }
        )

        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Alan Assistant")
            .setSubtitle("Confirme que é você")
            .setAllowedAuthenticators(tipos)
            .build()

        runCatching { prompt.authenticate(info) }
            .onFailure { aoFalhar("Não foi possível abrir a autenticação: ${it.message}") }
    }
}
