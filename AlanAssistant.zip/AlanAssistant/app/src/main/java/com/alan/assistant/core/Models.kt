package com.alan.assistant.core

/**
 * Modelos de domínio do ALAN ASSISTANT.
 *
 * IMPORTANTE: este pacote (`core`) é Kotlin puro — não importa NADA de Android.
 * Isso permite rodar todos os testes de lógica na JVM (rápido, sem emulador)
 * e, no futuro, reaproveitar a mesma lógica em desktop/servidor.
 *
 * Todas as datas/horas são guardadas como epoch millis (UTC) e convertidas
 * para o fuso do usuário (America/Sao_Paulo) apenas na borda.
 */

const val USUARIO_PRINCIPAL = "Alan"

enum class TaskStatus(val label: String) {
    PENDENTE("pendente"),
    EM_ANDAMENTO("em andamento"),
    CONCLUIDA("concluída"),
    ATRASADA("atrasada"),
    CANCELADA("cancelada"),
    ADIADA("adiada");

    val aberta: Boolean get() = this == PENDENTE || this == EM_ANDAMENTO || this == ATRASADA || this == ADIADA

    companion object {
        fun from(value: String?): TaskStatus =
            entries.firstOrNull { it.name.equals(value, true) } ?: PENDENTE
    }
}

enum class Priority(val label: String, val peso: Int) {
    BAIXA("baixa", 0),
    NORMAL("normal", 1),
    ALTA("alta", 2),
    URGENTE("urgente", 3);

    companion object {
        fun from(value: String?): Priority =
            entries.firstOrNull { it.name.equals(value, true) } ?: NORMAL
    }
}

enum class ReminderKind {
    /** Lembrete criado explicitamente pelo Alan. */
    USER,
    /** Lembrete vinculado ao prazo de uma tarefa. */
    TASK,
    /** Aviso de um compromisso/evento. */
    EVENT,
    /** Resumo diário automático (item 23 do escopo). */
    DAILY_SUMMARY,
    /** Resumo noturno automático (item 24 do escopo). */
    NIGHT_SUMMARY;

    companion object {
        fun from(value: String?): ReminderKind =
            entries.firstOrNull { it.name.equals(value, true) } ?: USER
    }
}

enum class IntentType {
    CREATE_TASK,
    UPDATE_TASK,
    COMPLETE_TASK,
    DELETE_TASK,
    CREATE_REMINDER,
    UPDATE_REMINDER,
    DELETE_REMINDER,
    CREATE_RECURRING_REMINDER,
    CREATE_ROUTINE,
    UPDATE_ROUTINE,
    CREATE_EVENT,
    QUERY_TASKS,
    QUERY_REMINDERS,
    QUERY_ROUTINES,
    QUERY_MEMORY,
    SAVE_MEMORY,
    DELETE_MEMORY,
    POSTPONE_TASK,
    POSTPONE_REMINDER,
    DAILY_SUMMARY,
    WEEKLY_SUMMARY,
    NIGHT_SUMMARY,
    GENERAL_CONVERSATION,
    UNKNOWN
}

/** Janela de consulta usada pelas intenções QUERY_*. */
enum class QueryScope { HOJE, AMANHA, SEMANA, ATRASADAS, ABERTAS, CONCLUIDAS, TODAS }

data class Task(
    val id: String,
    val title: String,
    val description: String? = null,
    val createdAt: Long,
    val updatedAt: Long,
    val dueAt: Long? = null,
    val hasTime: Boolean = false,
    val priority: Priority = Priority.NORMAL,
    val category: String? = null,
    val status: TaskStatus = TaskStatus.PENDENTE,
    val notes: String? = null,
    val recurrence: Recurrence = Recurrence.NONE,
    val completedAt: Long? = null,
    val reminderId: String? = null
)

data class Reminder(
    val id: String,
    val title: String,
    val message: String? = null,
    val triggerAt: Long,
    val active: Boolean = true,
    val recurrence: Recurrence = Recurrence.NONE,
    val kind: ReminderKind = ReminderKind.USER,
    val taskId: String? = null,
    val eventId: String? = null,
    val lastFiredAt: Long? = null,
    val fireCount: Int = 0,
    val snoozeCount: Int = 0,
    val createdAt: Long,
    val updatedAt: Long
)

data class MemoryItem(
    val id: String,
    val content: String,
    val topic: String? = null,
    val pinned: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

data class EventItem(
    val id: String,
    val title: String,
    val startAt: Long,
    val endAt: Long? = null,
    val location: String? = null,
    val notes: String? = null,
    val reminderId: String? = null,
    val createdAt: Long,
    val updatedAt: Long
)

data class RoutineItem(
    val id: String,
    val title: String,
    val recurrence: Recurrence,
    val timeOfDayMinutes: Int,
    val active: Boolean = true,
    val reminderId: String? = null,
    val createdAt: Long,
    val updatedAt: Long
)

data class AuditEvent(
    val id: String,
    val at: Long,
    val actor: String,
    val action: String,
    val entityType: String,
    val entityId: String?,
    val detail: String?
)

data class ConversationTurn(
    val id: String,
    val at: Long,
    val role: String,            // "alan" | "assistente"
    val text: String,
    val intent: String? = null,
    val viaVoice: Boolean = false
)

/** Resposta que o motor devolve para a camada de UI/voz. */
data class AssistantReply(
    val text: String,
    val speak: Boolean = true,
    /** Quando != null, o assistente está aguardando uma resposta do Alan. */
    val pending: PendingRequest? = null,
    val intent: IntentType = IntentType.UNKNOWN,
    val createdTaskId: String? = null,
    val createdReminderId: String? = null
)

/**
 * Estado de desambiguação (itens 9 e 26 do escopo).
 * Guardado no banco para sobreviver ao fechamento do app.
 */
data class PendingRequest(
    val question: String,
    val missingSlot: Slot,
    val partial: ParsedIntent,
    val options: List<String> = emptyList(),
    /**
     * Quando true, responder "não" NÃO cancela: executa a intenção com o
     * valor padrão (ex.: lembrete no dia certo, às 09:00).
     */
    val executarSeNegativa: Boolean = false
)

enum class Slot { TITULO, DATA_HORA, HORA, ALVO, CONTEUDO }
