package com.alan.assistant.core

/**
 * Camada de validação (item 15 do escopo).
 *
 * NENHUMA intenção — nem a produzida pela IA — chega ao banco sem passar
 * por aqui. Se faltar informação essencial, o assistente PERGUNTA em vez de
 * inventar data ou horário (item 9).
 */
object IntentValidator {

    private const val CINCO_ANOS_MS = 5L * 365 * 24 * 60 * 60 * 1000
    private const val TOLERANCIA_PASSADO_MS = 60_000L

    sealed class Result {
        data class Ok(val intent: ParsedIntent) : Result()
        data class Ask(
            val question: String,
            val slot: Slot,
            val intent: ParsedIntent,
            /** "não" executa com o padrão em vez de cancelar. */
            val executarSeNegativa: Boolean = false
        ) : Result()
        data class Reject(val reason: String) : Result()
    }

    fun validate(intent: ParsedIntent, agoraMillis: Long): Result {
        // Sanidade temporal — vale para qualquer intenção com data.
        intent.whenAt?.let { quando ->
            if (quando > agoraMillis + CINCO_ANOS_MS) {
                return Result.Reject("Essa data ficou muito distante. Pode repetir o dia?")
            }
            if (quando < agoraMillis - TOLERANCIA_PASSADO_MS && exigeFuturo(intent.type)) {
                return Result.Ask(
                    "Esse horário já passou, Alan. Para quando eu remarco?",
                    Slot.DATA_HORA,
                    intent.copy(whenAt = null)
                )
            }
        }

        return when (intent.type) {
            IntentType.CREATE_REMINDER -> {
                if (intent.title.isNullOrBlank())
                    Result.Ask("Claro, Alan. O que você quer que eu te lembre?", Slot.TITULO, intent)
                else if (intent.whenAt == null)
                    Result.Ask("Claro, Alan. Quando você quer ser lembrado?", Slot.DATA_HORA, intent)
                else if (!intent.hasTime)
                // Item 36: temos o dia, mas o Alan não disse a hora — perguntamos
                // em vez de inventar. Se ele disser "não", vale o padrão (09:00).
                    Result.Ask(
                        "Quer que eu te lembre em algum horário específico?",
                        Slot.HORA, intent, executarSeNegativa = true
                    )
                else Result.Ok(intent)
            }

            IntentType.CREATE_RECURRING_REMINDER, IntentType.CREATE_ROUTINE -> {
                if (intent.title.isNullOrBlank())
                    Result.Ask("O que você quer que eu te lembre nessa recorrência?", Slot.TITULO, intent)
                else if (!intent.recurrence.isRecurring)
                    Result.Ask("Com que frequência eu te lembro disso?", Slot.DATA_HORA, intent)
                else if (intent.whenAt == null)
                    Result.Ask("Em que horário, Alan?", Slot.HORA, intent)
                else if (!intent.hasTime)
                    Result.Ask(
                        "Em que horário, Alan?", Slot.HORA, intent, executarSeNegativa = true
                    )
                else Result.Ok(intent)
            }

            IntentType.CREATE_TASK -> {
                if (intent.title.isNullOrBlank())
                    Result.Ask("O que eu anoto como tarefa?", Slot.TITULO, intent)
                else Result.Ok(intent)
            }

            IntentType.CREATE_EVENT -> {
                if (intent.title.isNullOrBlank())
                    Result.Ask("Qual é o compromisso?", Slot.TITULO, intent)
                else if (intent.whenAt == null)
                    Result.Ask("Para quando é o compromisso?", Slot.DATA_HORA, intent)
                else Result.Ok(intent)
            }

            IntentType.SAVE_MEMORY -> {
                if (intent.content.isNullOrBlank())
                    Result.Ask("O que você quer que eu guarde?", Slot.CONTEUDO, intent)
                else Result.Ok(intent)
            }

            IntentType.COMPLETE_TASK, IntentType.DELETE_TASK,
            IntentType.DELETE_REMINDER, IntentType.DELETE_MEMORY -> {
                if (intent.targetRef.isNullOrBlank() && intent.targetId.isNullOrBlank())
                    Result.Ask("Qual item, Alan?", Slot.ALVO, intent)
                else Result.Ok(intent)
            }

            IntentType.POSTPONE_TASK, IntentType.POSTPONE_REMINDER -> {
                if (intent.targetRef.isNullOrBlank() && intent.targetId.isNullOrBlank())
                    Result.Ask("Qual item você quer adiar?", Slot.ALVO, intent)
                else if (intent.whenAt == null && intent.offsetMinutes == null)
                    Result.Ask("Adiar para quando?", Slot.DATA_HORA, intent)
                else Result.Ok(intent)
            }

            IntentType.UNKNOWN ->
                Result.Reject("Não entendi, Alan. Pode dizer de outro jeito?")

            else -> Result.Ok(intent)
        }
    }

    private fun exigeFuturo(t: IntentType) = when (t) {
        IntentType.CREATE_REMINDER,
        IntentType.CREATE_RECURRING_REMINDER,
        IntentType.CREATE_EVENT,
        IntentType.CREATE_ROUTINE,
        IntentType.POSTPONE_TASK,
        IntentType.POSTPONE_REMINDER -> true
        else -> false
    }

    /**
     * Sanidade extra para respostas vindas da IA (item 19: "resposta da IA
     * malformada"). Descarta campos impossíveis antes de validar.
     */
    fun sanitizeFromAi(intent: ParsedIntent, agoraMillis: Long): ParsedIntent {
        var out = intent
        if (out.title != null && out.title.length > 200) out = out.copy(title = out.title.take(200))
        if (out.content != null && out.content.length > 2000) out = out.copy(content = out.content.take(2000))
        out.whenAt?.let {
            if (it <= 0 || it > agoraMillis + CINCO_ANOS_MS) out = out.copy(whenAt = null, hasTime = false)
        }
        out.offsetMinutes?.let {
            if (it <= 0 || it > 60 * 24 * 365) out = out.copy(offsetMinutes = null)
        }
        return out
    }
}
