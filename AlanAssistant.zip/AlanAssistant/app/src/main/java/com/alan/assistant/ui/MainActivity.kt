package com.alan.assistant.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.alan.assistant.AlanApp
import com.alan.assistant.data.Settings
import com.alan.assistant.security.AuthGate
import com.alan.assistant.work.MaintenanceWorker

/**
 * Única Activity do app.
 *
 * Estende FragmentActivity porque o BiometricPrompt exige isso — e também
 * é uma ComponentActivity, então `setContent` do Compose funciona normalmente.
 */
class MainActivity : FragmentActivity() {

    private lateinit var vm: AssistantViewModel
    private var microfoneLiberado by mutableStateOf(false)

    private val pedirMicrofone = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { concedida ->
        microfoneLiberado = concedida
        if (concedida) vm.ouvir()
    }

    private val pedirNotificacoes = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Se negar, o app segue; a tela inicial avisa o que deixa de funcionar. */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val container = (application as AlanApp).container
        vm = ViewModelProvider(this, AssistantViewModel.Factory(container))[AssistantViewModel::class.java]

        microfoneLiberado = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            pedirNotificacoes.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        val precisaDesbloquear = container.settings.getBool(Settings.BLOQUEIO_ATIVO, false)
        val portao = AuthGate(this)

        setContent {
            AlanTheme {
                var liberado by remember { mutableStateOf(!precisaDesbloquear) }

                if (!liberado) {
                    TelaBloqueio(
                        aoPedirBiometria = { aoOk, aoErro ->
                            portao.pedirAutenticacao(aoOk, aoErro)
                        },
                        aoConferirPin = { pin -> container.secrets.conferirPin(pin) },
                        temPin = container.secrets.temPin(),
                        aoLiberar = { liberado = true }
                    )
                } else {
                    Conteudo(vm)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Reconcilia estado ao voltar para o app: atrasadas, contadores e
        // qualquer lembrete que tenha ficado para trás.
        vm.atualizarContadores()
        MaintenanceWorker.agendarAgora(this)
    }

    @Composable
    private fun Conteudo(vm: AssistantViewModel) {
        val nav = rememberNavController()
        val entrada by nav.currentBackStackEntryAsState()
        val rotaAtual = entrada?.destination?.route ?: Rota.INICIO

        Scaffold(
            topBar = { BarraSuperior(tituloDe(rotaAtual)) },
            bottomBar = {
                NavigationBar {
                    Rota.abas.forEach { aba ->
                        val rota = aba.rota
                        val rotulo = aba.rotulo
                        NavigationBarItem(
                            selected = rotaAtual == rota,
                            onClick = {
                                if (rotaAtual != rota) {
                                    nav.navigate(rota) {
                                        popUpTo(Rota.INICIO) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = { Icon(aba.icone, contentDescription = null) },
                            label = { Text(rotulo) }
                        )
                    }
                }
            }
        ) { padding ->
            Surface(Modifier.padding(padding)) {
                NavHost(navController = nav, startDestination = Rota.INICIO) {
                    composable(Rota.INICIO) {
                        HomeScreen(
                            vm = vm,
                            aoPedirMicrofone = { pedirMicrofone.launch(Manifest.permission.RECORD_AUDIO) },
                            microfoneLiberado = microfoneLiberado
                        )
                    }
                    composable(Rota.TAREFAS) { TarefasScreen(vm) }
                    composable(Rota.LEMBRETES) { LembretesScreen(vm) }
                    composable(Rota.ROTINAS) { RotinasScreen(vm) }
                    composable(Rota.MEMORIA) { MemoriaScreen(vm) }
                    composable(Rota.HISTORICO) { HistoricoScreen(vm) }
                    composable(Rota.CONFIG) {
                        SettingsScreen(vm) { destino -> nav.navigate(destino) }
                    }
                }
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun BarraSuperior(titulo: String) {
        TopAppBar(title = { Text(titulo) })
    }

    private fun tituloDe(rota: String): String = when (rota) {
        Rota.TAREFAS -> "Tarefas"
        Rota.LEMBRETES -> "Lembretes"
        Rota.ROTINAS -> "Rotinas"
        Rota.MEMORIA -> "Memória"
        Rota.HISTORICO -> "Histórico"
        Rota.CONFIG -> "Configurações"
        else -> "Alan Assistant"
    }

    override fun onDestroy() {
        if (isFinishing) {
            (application as? AlanApp)?.container?.speaker?.parar()
        }
        super.onDestroy()
    }
}

object Rota {
    const val INICIO = "inicio"
    const val TAREFAS = "tarefas"
    const val LEMBRETES = "lembretes"
    const val ROTINAS = "rotinas"
    const val MEMORIA = "memoria"
    const val HISTORICO = "historico"
    const val CONFIG = "config"

    data class Aba(
        val rota: String,
        val rotulo: String,
        val icone: androidx.compose.ui.graphics.vector.ImageVector
    )

    /** Abas da barra inferior. O histórico fica dentro de Configurações. */
    val abas = listOf(
        Aba(INICIO, "Início", Icons.Filled.Home),
        Aba(TAREFAS, "Tarefas", Icons.Filled.List),
        Aba(LEMBRETES, "Lembretes", Icons.Filled.Notifications),
        Aba(MEMORIA, "Memória", Icons.Filled.Star),
        Aba(CONFIG, "Ajustes", Icons.Filled.Settings)
    )
}

@Composable
private fun TelaBloqueio(
    aoPedirBiometria: (() -> Unit, (String?) -> Unit) -> Unit,
    aoConferirPin: (String) -> Boolean,
    temPin: Boolean,
    aoLiberar: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var erro by remember { mutableStateOf<String?>(null) }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Alan Assistant", style = MaterialTheme.typography.displaySmall)
            Text(
                "Confirme que é você para continuar.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Button(
                onClick = { aoPedirBiometria(aoLiberar) { msg -> erro = msg } },
                modifier = Modifier.fillMaxWidth().padding(top = 24.dp)
            ) { Text("Desbloquear") }

            if (temPin) {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { novo -> pin = novo.filter { it.isDigit() }.take(8); erro = null },
                    label = { Text("Ou digite o PIN") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                        keyboardType = KeyboardType.NumberPassword
                    ),
                    modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
                )
                Button(
                    onClick = {
                        if (aoConferirPin(pin)) aoLiberar() else erro = "PIN incorreto."
                    },
                    enabled = pin.length >= 4,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                ) { Text("Entrar com PIN") }
            }

            erro?.let {
                Text(
                    it,
                    Modifier.padding(top = 16.dp),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
