package com.alan.assistant.backup

import android.content.Context
import android.net.Uri
import android.util.Log
import com.alan.assistant.data.AlanDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * EXPORTAÇÃO E BACKUP (item 28 do escopo).
 *
 * Três formatos:
 *  - JSON: backup completo, legível, com todas as tabelas. É o formato
 *    recomendado para guardar/versionar.
 *  - CSV: um arquivo por tabela, para abrir no Excel.
 *  - SQLite: cópia binária fiel do banco — é o que permite restaurar tudo.
 *
 * Os arquivos vão para a pasta do app em Armazenamento interno
 * (`Android/data/com.alan.assistant/files/backups`), que o Alan acessa pelo
 * gerenciador de arquivos e não exige nenhuma permissão extra. A tela de
 * Configurações também permite salvar em qualquer pasta escolhida.
 */
class BackupManager(
    private val context: Context,
    private val db: AlanDatabase
) {

    data class Resultado(val ok: Boolean, val mensagem: String, val arquivos: List<File> = emptyList())

    private val carimbo: String
        get() = SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale("pt", "BR")).format(Date())

    private fun pasta(): File =
        File(context.getExternalFilesDir(null) ?: context.filesDir, "backups").apply { mkdirs() }

    // ==================================================================
    // Exportação
    // ==================================================================

    fun exportarTudo(): Resultado = try {
        val destino = pasta()
        val gerados = mutableListOf<File>()

        val json = File(destino, "alan_backup_$carimbo.json")
        json.writeText(gerarJson(), Charsets.UTF_8)
        gerados += json

        gerados += gerarCsvs(destino)

        copiarBanco()?.let { gerados += it }

        Resultado(true, "Backup gerado em ${destino.absolutePath}", gerados)
    } catch (e: Throwable) {
        Log.e(TAG, "Falha no backup: ${e.message}", e)
        Resultado(false, "Não consegui gerar o backup: ${e.message}")
    }

    /** Backup JSON completo, como texto. */
    fun gerarJson(): String {
        val raiz = JSONObject()
        raiz.put("app", "ALAN ASSISTANT")
        raiz.put("versao_backup", 1)
        raiz.put("gerado_em", System.currentTimeMillis())

        raiz.put("users", JSONArray().apply {
            db.userDao().primeiro()?.let {
                put(
                    JSONObject()
                        .put("id", it.id).put("name", it.name)
                        .put("language", it.language).put("timezone", it.timezone)
                        .put("createdAt", it.createdAt)
                )
            }
        })

        raiz.put("tasks", JSONArray().apply {
            db.taskDao().todas().forEach {
                put(
                    JSONObject()
                        .put("id", it.id).put("title", it.title)
                        .put("description", it.description ?: JSONObject.NULL)
                        .put("createdAt", it.createdAt).put("updatedAt", it.updatedAt)
                        .put("dueAt", it.dueAt ?: JSONObject.NULL)
                        .put("hasTime", it.hasTime).put("priority", it.priority)
                        .put("category", it.category ?: JSONObject.NULL)
                        .put("status", it.status).put("notes", it.notes ?: JSONObject.NULL)
                        .put("recurrence", it.recurrence)
                        .put("completedAt", it.completedAt ?: JSONObject.NULL)
                        .put("reminderId", it.reminderId ?: JSONObject.NULL)
                )
            }
        })

        raiz.put("reminders", JSONArray().apply {
            db.reminderDao().let { dao ->
                // inclui inativos: percorremos todos os tipos conhecidos
                val todos = com.alan.assistant.core.ReminderKind.entries
                    .flatMap { k -> dao.porTipo(k.name) }
                    .distinctBy { it.id }
                todos.forEach {
                    put(
                        JSONObject()
                            .put("id", it.id).put("title", it.title)
                            .put("message", it.message ?: JSONObject.NULL)
                            .put("triggerAt", it.triggerAt).put("active", it.active)
                            .put("recurrence", it.recurrence).put("kind", it.kind)
                            .put("taskId", it.taskId ?: JSONObject.NULL)
                            .put("eventId", it.eventId ?: JSONObject.NULL)
                            .put("lastFiredAt", it.lastFiredAt ?: JSONObject.NULL)
                            .put("fireCount", it.fireCount).put("snoozeCount", it.snoozeCount)
                            .put("createdAt", it.createdAt).put("updatedAt", it.updatedAt)
                    )
                }
            }
        })

        raiz.put("memories", JSONArray().apply {
            db.memoryDao().todas().forEach {
                put(
                    JSONObject()
                        .put("id", it.id).put("content", it.content)
                        .put("topic", it.topic ?: JSONObject.NULL).put("pinned", it.pinned)
                        .put("createdAt", it.createdAt).put("updatedAt", it.updatedAt)
                )
            }
        })

        raiz.put("events", JSONArray().apply {
            db.eventDao().todos().forEach {
                put(
                    JSONObject()
                        .put("id", it.id).put("title", it.title)
                        .put("startAt", it.startAt).put("endAt", it.endAt ?: JSONObject.NULL)
                        .put("location", it.location ?: JSONObject.NULL)
                        .put("notes", it.notes ?: JSONObject.NULL)
                        .put("reminderId", it.reminderId ?: JSONObject.NULL)
                        .put("createdAt", it.createdAt).put("updatedAt", it.updatedAt)
                )
            }
        })

        raiz.put("routines", JSONArray().apply {
            db.routineDao().todas().forEach {
                put(
                    JSONObject()
                        .put("id", it.id).put("title", it.title)
                        .put("recurrence", it.recurrence)
                        .put("timeOfDayMinutes", it.timeOfDayMinutes)
                        .put("active", it.active)
                        .put("reminderId", it.reminderId ?: JSONObject.NULL)
                        .put("createdAt", it.createdAt).put("updatedAt", it.updatedAt)
                )
            }
        })

        raiz.put("conversations", JSONArray().apply {
            db.conversationDao().todas().forEach {
                put(
                    JSONObject()
                        .put("id", it.id).put("at", it.at).put("role", it.role)
                        .put("text", it.text).put("intent", it.intent ?: JSONObject.NULL)
                        .put("viaVoice", it.viaVoice)
                )
            }
        })

        raiz.put("notifications", JSONArray().apply {
            db.notificationDao().todas().forEach {
                put(
                    JSONObject()
                        .put("id", it.id).put("at", it.at)
                        .put("reminderId", it.reminderId ?: JSONObject.NULL)
                        .put("title", it.title).put("body", it.body)
                        .put("delivered", it.delivered)
                )
            }
        })

        raiz.put("settings", JSONArray().apply {
            db.settingDao().todas().forEach {
                put(JSONObject().put("key", it.key).put("value", it.value))
            }
        })

        raiz.put("audit_log", JSONArray().apply {
            db.auditDao().todos().forEach {
                put(
                    JSONObject()
                        .put("id", it.id).put("at", it.at).put("actor", it.actor)
                        .put("action", it.action).put("entityType", it.entityType)
                        .put("entityId", it.entityId ?: JSONObject.NULL)
                        .put("detail", it.detail ?: JSONObject.NULL)
                )
            }
        })

        return raiz.toString(2)
    }

    private fun gerarCsvs(destino: File): List<File> {
        val gerados = mutableListOf<File>()
        val c = carimbo

        File(destino, "tarefas_$c.csv").also { f ->
            f.writeText(
                csv(
                    listOf(
                        "id", "titulo", "descricao", "criada_em", "prazo", "tem_hora",
                        "prioridade", "categoria", "status", "recorrencia", "concluida_em"
                    ),
                    db.taskDao().todas().map {
                        listOf(
                            it.id, it.title, it.description, data(it.createdAt), data(it.dueAt),
                            it.hasTime.toString(), it.priority, it.category, it.status,
                            it.recurrence, data(it.completedAt)
                        )
                    }
                ),
                Charsets.UTF_8
            )
            gerados += f
        }

        File(destino, "lembretes_$c.csv").also { f ->
            val todos = com.alan.assistant.core.ReminderKind.entries
                .flatMap { k -> db.reminderDao().porTipo(k.name) }
                .distinctBy { it.id }
            f.writeText(
                csv(
                    listOf("id", "titulo", "dispara_em", "ativo", "recorrencia", "tipo", "disparos"),
                    todos.map {
                        listOf(
                            it.id, it.title, data(it.triggerAt), it.active.toString(),
                            it.recurrence, it.kind, it.fireCount.toString()
                        )
                    }
                ),
                Charsets.UTF_8
            )
            gerados += f
        }

        File(destino, "memoria_$c.csv").also { f ->
            f.writeText(
                csv(
                    listOf("id", "conteudo", "topico", "fixado", "criado_em"),
                    db.memoryDao().todas().map {
                        listOf(it.id, it.content, it.topic, it.pinned.toString(), data(it.createdAt))
                    }
                ),
                Charsets.UTF_8
            )
            gerados += f
        }

        File(destino, "historico_$c.csv").also { f ->
            f.writeText(
                csv(
                    listOf("quando", "acao", "tipo", "item", "detalhe"),
                    db.auditDao().todos().map {
                        listOf(data(it.at), it.action, it.entityType, it.entityId, it.detail)
                    }
                ),
                Charsets.UTF_8
            )
            gerados += f
        }

        return gerados
    }

    /** Cópia binária do banco (inclui os arquivos -wal e -shm quando existem). */
    fun copiarBanco(): File? = try {
        db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").use { it.moveToFirst() }
        val origem = context.getDatabasePath(AlanDatabase.NOME_ARQUIVO)
        if (!origem.exists()) null
        else File(pasta(), "alan_assistant_$carimbo.db").also { origem.copyTo(it, overwrite = true) }
    } catch (e: Throwable) {
        Log.e(TAG, "Falha ao copiar banco: ${e.message}", e)
        null
    }

    /** Grava o backup JSON numa pasta escolhida pelo Alan (SAF). */
    fun exportarJsonPara(uri: Uri): Resultado = try {
        context.contentResolver.openOutputStream(uri)?.use {
            it.write(gerarJson().toByteArray(Charsets.UTF_8))
        } ?: return Resultado(false, "Não consegui abrir o arquivo escolhido.")
        Resultado(true, "Backup salvo.")
    } catch (e: Throwable) {
        Log.e(TAG, "Falha ao exportar: ${e.message}", e)
        Resultado(false, "Falha ao salvar: ${e.message}")
    }

    /** Grava a cópia do banco numa pasta escolhida pelo Alan (SAF). */
    fun exportarBancoPara(uri: Uri): Resultado = try {
        val copia = copiarBanco() ?: return Resultado(false, "Banco não encontrado.")
        context.contentResolver.openOutputStream(uri)?.use { saida ->
            copia.inputStream().use { it.copyTo(saida) }
        } ?: return Resultado(false, "Não consegui abrir o arquivo escolhido.")
        Resultado(true, "Banco exportado.")
    } catch (e: Throwable) {
        Log.e(TAG, "Falha ao exportar banco: ${e.message}", e)
        Resultado(false, "Falha ao exportar: ${e.message}")
    }

    // ==================================================================
    // Restauração
    // ==================================================================

    /**
     * Substitui o banco atual por um arquivo .db de backup.
     *
     * Segurança: antes de sobrescrever, o banco atual é salvo como
     * `antes_da_restauracao_*.db`. Depois disso o app PRECISA ser reaberto,
     * porque o Room mantém o arquivo aberto em memória.
     */
    fun restaurarDe(uri: Uri): Resultado = try {
        val destinoDb = context.getDatabasePath(AlanDatabase.NOME_ARQUIVO)

        if (destinoDb.exists()) {
            destinoDb.copyTo(File(pasta(), "antes_da_restauracao_$carimbo.db"), overwrite = true)
        }

        AlanDatabase.fechar()

        // Remove os arquivos auxiliares do WAL — senão o SQLite mistura
        // dados novos com o banco restaurado.
        File(destinoDb.parentFile, "${AlanDatabase.NOME_ARQUIVO}-wal").delete()
        File(destinoDb.parentFile, "${AlanDatabase.NOME_ARQUIVO}-shm").delete()

        context.contentResolver.openInputStream(uri)?.use { entrada ->
            destinoDb.outputStream().use { entrada.copyTo(it) }
        } ?: return Resultado(false, "Não consegui abrir o arquivo de backup.")

        Resultado(true, "Backup restaurado. Feche e abra o aplicativo para concluir.")
    } catch (e: Throwable) {
        Log.e(TAG, "Falha ao restaurar: ${e.message}", e)
        Resultado(false, "Falha ao restaurar: ${e.message}")
    }

    // ==================================================================
    // Utilidades
    // ==================================================================

    private fun csv(cabecalho: List<String>, linhas: List<List<String?>>): String {
        val sb = StringBuilder()
        // BOM: faz o Excel abrir acentos corretamente.
        sb.append('\uFEFF')
        sb.append(cabecalho.joinToString(";")).append('\n')
        linhas.forEach { l -> sb.append(l.joinToString(";") { escapar(it) }).append('\n') }
        return sb.toString()
    }

    private fun escapar(v: String?): String {
        val s = v ?: ""
        return if (s.contains(';') || s.contains('"') || s.contains('\n')) {
            "\"" + s.replace("\"", "\"\"").replace("\n", " ") + "\""
        } else {
            s
        }
    }

    private fun data(ms: Long?): String =
        if (ms == null) "" else SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date(ms))

    companion object { private const val TAG = "AlanBackup" }
}
