package com.alan.assistant.core

import java.time.Instant
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.temporal.ChronoUnit

/**
 * MOTOR DE NEGÓCIO.
 *
 * É o único componente que escreve no banco e agenda alarmes.
 * Recebe texto -> interpreta -> valida -> executa -> responde.
 *
 * Fica em Kotlin puro de propósito: todos os fluxos abaixo são testados na
 * JVM, com stores em memória, sem precisar de emulador Android.
 */
class AssistantEngine(
    private val interpreter: Interpreter,
    private val tasks: TaskStore,
    private val reminders: ReminderStore,
    private val memories: MemoryStore,
    private val events: EventStore,
    private val routines: RoutineStore,
    private val audit: AuditPort,
    private val alarms: AlarmPort,
    private val clock: ClockPort,
    private val pendings: PendingStore,
    private val zone: ZoneId,
    /** Antecedência padrão do aviso de compromisso, em minutos. */
    private val avisoEventoMinutos: Int = 30
) {

    // ==================================================================
    // Entrada principal
    // ==================================================================

    fun handle(entrada: String, viaVoice: Boolean = false): AssistantReply {
        val texto = entrada.trim()
        if (texto.isEmpty()) {
            return AssistantReply("Não ouvi nada, $USUARIO_PRINCIPAL. Pode repetir?", intent = IntentType.UNKNOWN)
        }
        atualizarAtrasadas()

        val pendente = pendings.carregar()
        if (pendente != null) {
            return responderPendencia(pendente, texto)
        }

        val ctx = InterpreterContext(
            tarefasRecentes = tasks.abertas().sortedByDescending { it.createdAt }.take(10)
                .map { it.id to it.title },
            lembretesRecentes = reminders.ativos().sortedBy { it.triggerAt }.take(10)
                .map { it.id to it.title },
            nowMillis = clock.nowMillis()
        )
        val intent = interpreter.interpret(texto, ctx)
        return validarEExecutar(intent)
    }

    private fun validarEExecutar(intent: ParsedIntent): AssistantReply {
        val agora = clock.nowMillis()
        val limpo = if (intent.source == "ia") IntentValidator.sanitizeFromAi(intent, agora) else intent
        return when (val v = IntentValidator.validate(limpo, agora)) {
            is IntentValidator.Result.Ok -> executar(v.intent)
            is IntentValidator.Result.Ask -> {
                val p = PendingRequest(v.question, v.slot, v.intent, executarSeNegativa = v.executarSeNegativa)
                pendings.salvar(p)
                AssistantReply(v.question, pending = p, intent = limpo.type)
            }
            is IntentValidator.Result.Reject -> AssistantReply(v.reason, intent = limpo.type)
        }
    }

    // ==================================================================
    // Desambiguação / perguntas em aberto
    // ==================================================================

    private fun responderPendencia(p: PendingRequest, texto: String): AssistantReply {
        if (ehNegativa(texto)) {
            pendings.salvar(null)
            // "não" pode significar "pode usar o padrão" (ex.: horário do lembrete).
            return if (p.executarSeNegativa && p.partial.whenAt != null) {
                executar(p.partial.copy(hasTime = true))
            } else {
                AssistantReply("Tudo bem, $USUARIO_PRINCIPAL. Deixei como está.")
            }
        }

        val agora = LocalDateTime.ofInstant(Instant.ofEpochMilli(clock.nowMillis()), zone)

        val preenchido: ParsedIntent? = when (p.missingSlot) {
            Slot.DATA_HORA, Slot.HORA -> {
                val t = PtBrDateTime.parse(texto, agora)
                var quando = t.dateTime ?: (t.recurrence.takeIf { it.isRecurring }
                    ?.next(agora, LocalTime.of(9, 0)))
                // Se o Alan respondeu só o HORÁRIO, mantemos o DIA já combinado.
                if (quando != null && !t.hasDate && p.partial.whenAt != null) {
                    quando = local(p.partial.whenAt).toLocalDate().atTime(quando.toLocalTime())
                }
                if (quando == null) null
                else p.partial.copy(
                    whenAt = quando.atZone(zone).toInstant().toEpochMilli(),
                    hasTime = t.hasExplicitTime,
                    recurrence = if (t.recurrence.isRecurring) t.recurrence else p.partial.recurrence
                )
            }

            Slot.TITULO -> {
                val t = PtBrDateTime.parse(texto, agora)
                val titulo = RuleBasedInterpreter(zone).limparTitulo(texto, t.consumed) ?: texto.trim()
                p.partial.copy(
                    title = titulo,
                    whenAt = p.partial.whenAt ?: t.dateTime?.atZone(zone)?.toInstant()?.toEpochMilli(),
                    hasTime = p.partial.hasTime || t.hasExplicitTime,
                    recurrence = if (p.partial.recurrence.isRecurring) p.partial.recurrence else t.recurrence
                )
            }

            Slot.CONTEUDO -> p.partial.copy(content = texto.trim(), title = texto.trim())

            Slot.ALVO -> {
                val escolhido = escolherOpcao(texto, p.options)
                if (escolhido == null) null else p.partial.copy(targetId = escolhido, targetRef = null)
            }
        }

        if (preenchido == null) {
            return AssistantReply(p.question, pending = p, intent = p.partial.type)
        }

        pendings.salvar(null)
        return validarEExecutar(preenchido)
    }

    private fun escolherOpcao(texto: String, opcoes: List<String>): String? {
        if (opcoes.isEmpty()) return null
        val n = PtBrDateTime.normalize(texto)
        // "primeiro"/"1" etc.
        Regex("""\b([1-9])\b""").find(n)?.let { m ->
            val i = m.groupValues[1].toInt() - 1
            if (i in opcoes.indices) return opcoes[i]
        }
        if (Regex("""\b(primeir[oa])\b""").containsMatchIn(n) && opcoes.isNotEmpty()) return opcoes[0]
        if (Regex("""\b(segund[oa])\b""").containsMatchIn(n) && opcoes.size > 1) return opcoes[1]
        // Casamento por texto contra as tarefas/lembretes das opções
        val candidatos = opcoes.mapNotNull { id ->
            val titulo = tasks.byId(id)?.title ?: reminders.byId(id)?.title
            if (titulo == null) null else id to titulo
        }
        val melhor = candidatos.maxByOrNull { pontuar(PtBrDateTime.normalize(it.second), n) }
        return if (melhor != null && pontuar(PtBrDateTime.normalize(melhor.second), n) > 0) melhor.first else null
    }

    private fun ehNegativa(texto: String): Boolean {
        val n = PtBrDateTime.normalize(texto).trim()
        return Regex("""^(nao|nao precisa|nao quero|deixa|deixa pra la|esquece|esquece isso|cancela|cancelar|nada|tanto faz|depois eu vejo)\b""")
            .containsMatchIn(n)
    }

    // ==================================================================
    // Execução das intenções
    // ==================================================================

    private fun executar(intent: ParsedIntent): AssistantReply {
        val agoraMs = clock.nowMillis()
        val agora = LocalDateTime.ofInstant(Instant.ofEpochMilli(agoraMs), zone)

        return when (intent.type) {
            IntentType.CREATE_REMINDER, IntentType.CREATE_RECURRING_REMINDER ->
                criarLembrete(intent, agora, agoraMs)

            IntentType.CREATE_TASK -> criarTarefa(intent, agora, agoraMs)

            IntentType.CREATE_EVENT -> criarEvento(intent, agora, agoraMs)

            IntentType.CREATE_ROUTINE -> criarRotina(intent, agora, agoraMs)

            IntentType.COMPLETE_TASK -> concluirTarefa(intent)

            IntentType.POSTPONE_TASK -> adiarTarefa(intent, agora, agoraMs)

            IntentType.POSTPONE_REMINDER -> adiarLembretePorTexto(intent, agora, agoraMs)

            IntentType.DELETE_TASK -> apagarTarefa(intent)

            IntentType.DELETE_REMINDER -> apagarLembrete(intent)

            IntentType.SAVE_MEMORY -> {
                val item = MemoryItem(
                    id = Ids.novo(),
                    content = intent.content ?: intent.title.orEmpty(),
                    createdAt = agoraMs,
                    updatedAt = agoraMs
                )
                memories.insert(item)
                audit.registrar("MEMORY_CREATE", "memory", item.id, item.content)
                AssistantReply("Guardado, $USUARIO_PRINCIPAL.", intent = intent.type)
            }

            IntentType.DELETE_MEMORY -> {
                val termo = intent.targetRef.orEmpty()
                val achados = memories.buscar(termo)
                if (achados.isEmpty()) {
                    AssistantReply("Não encontrei essa anotação, $USUARIO_PRINCIPAL.", intent = intent.type)
                } else {
                    achados.forEach { memories.delete(it.id) }
                    audit.registrar("MEMORY_DELETE", "memory", null, termo)
                    AssistantReply(
                        "Apaguei ${Summaries.plural(achados.size, "anotação", "anotações")}.",
                        intent = intent.type
                    )
                }
            }

            IntentType.QUERY_MEMORY -> {
                val s = Summaries.listaMemoria(memories.todas())
                AssistantReply(s.texto, intent = intent.type)
            }

            IntentType.QUERY_TASKS -> {
                val (lista, titulo) = tarefasPorEscopo(intent.scope, agora)
                val s = Summaries.listaTarefas(lista, titulo, agora, zone)
                AssistantReply(s.texto, intent = intent.type)
            }

            IntentType.QUERY_REMINDERS -> {
                val lista = reminders.ativos().sortedBy { it.triggerAt }
                    .filter { it.kind == ReminderKind.USER || it.kind == ReminderKind.TASK }
                val s = Summaries.listaLembretes(lista, agora, zone)
                AssistantReply(s.texto, intent = intent.type)
            }

            IntentType.QUERY_ROUTINES -> {
                val s = Summaries.listaRotinas(routines.ativas())
                AssistantReply(s.texto, intent = intent.type)
            }

            IntentType.DAILY_SUMMARY -> {
                val s = resumoDiario(agora)
                AssistantReply(s.texto, intent = intent.type)
            }

            IntentType.NIGHT_SUMMARY -> {
                val s = resumoNoturno(agora)
                AssistantReply(s.texto, intent = intent.type)
            }

            IntentType.WEEKLY_SUMMARY -> {
                val s = resumoSemanal(agora)
                AssistantReply(s.texto, intent = intent.type)
            }

            IntentType.GENERAL_CONVERSATION -> {
                val resposta = intent.content?.takeIf { it.isNotBlank() } ?: AJUDA
                AssistantReply(resposta, intent = intent.type)
            }

            else -> AssistantReply(
                "Ainda não sei fazer isso, $USUARIO_PRINCIPAL.",
                intent = intent.type
            )
        }
    }

    // ------------------------------------------------------------------

    private fun criarLembrete(intent: ParsedIntent, agora: LocalDateTime, agoraMs: Long): AssistantReply {
        val trigger = intent.whenAt ?: return AssistantReply("Quando eu te lembro, $USUARIO_PRINCIPAL?")
        val r = Reminder(
            id = Ids.novo(),
            title = intent.title!!,
            triggerAt = trigger,
            recurrence = intent.recurrence,
            kind = if (intent.targetId != null) ReminderKind.TASK else ReminderKind.USER,
            taskId = intent.targetId,
            createdAt = agoraMs,
            updatedAt = agoraMs
        )
        reminders.insert(r)
        alarms.agendar(r)
        audit.registrar("REMINDER_CREATE", "reminder", r.id, "${r.title} @ ${r.triggerAt}")

        val quando = PtBrDateTime.formatFriendly(local(trigger), agora)
        val txt = if (r.recurrence.isRecurring)
            "Combinado, $USUARIO_PRINCIPAL. Vou te lembrar ${r.recurrence.describe()} às ${hhmm(trigger)}. O primeiro é $quando."
        else
            "Anotado, $USUARIO_PRINCIPAL. Vou te lembrar $quando: ${r.title}."

        return AssistantReply(txt, intent = intent.type, createdReminderId = r.id)
    }

    private fun criarTarefa(intent: ParsedIntent, agora: LocalDateTime, agoraMs: Long): AssistantReply {
        val t = Task(
            id = Ids.novo(),
            title = intent.title!!,
            createdAt = agoraMs,
            updatedAt = agoraMs,
            dueAt = intent.whenAt,
            hasTime = intent.hasTime,
            priority = intent.priority ?: Priority.NORMAL,
            category = intent.category,
            status = TaskStatus.PENDENTE
        )
        tasks.insert(t)
        audit.registrar("TASK_CREATE", "task", t.id, t.title)

        // Prazo com horário -> cria lembrete vinculado automaticamente.
        var lembreteId: String? = null
        if (t.dueAt != null && t.hasTime) {
            val r = Reminder(
                id = Ids.novo(),
                title = t.title,
                triggerAt = t.dueAt,
                kind = ReminderKind.TASK,
                taskId = t.id,
                createdAt = agoraMs,
                updatedAt = agoraMs
            )
            reminders.insert(r)
            alarms.agendar(r)
            tasks.update(t.copy(reminderId = r.id, updatedAt = agoraMs))
            lembreteId = r.id
        }

        val prazoTxt = t.dueAt?.let { " Prazo: ${PtBrDateTime.formatFriendly(local(it), agora, t.hasTime)}." } ?: ""
        val base = "Anotado, $USUARIO_PRINCIPAL. Tarefa criada: ${t.title}.$prazoTxt"

        // Item 36: prazo sem horário -> oferece lembrete, sem inventar hora.
        if (t.dueAt != null && !t.hasTime) {
            val partial = ParsedIntent(
                type = IntentType.CREATE_REMINDER,
                title = t.title,
                targetId = t.id,
                whenAt = t.dueAt,      // mantém o dia do prazo; falta só a hora
                hasTime = false,
                rawText = intent.rawText
            )
            val p = PendingRequest(
                "Quer que eu te lembre em algum horário específico?",
                Slot.HORA,
                partial
            )
            pendings.salvar(p)
            return AssistantReply(
                "$base Quer que eu te lembre em algum horário específico?",
                pending = p,
                intent = intent.type,
                createdTaskId = t.id
            )
        }

        return AssistantReply(base, intent = intent.type, createdTaskId = t.id, createdReminderId = lembreteId)
    }

    private fun criarEvento(intent: ParsedIntent, agora: LocalDateTime, agoraMs: Long): AssistantReply {
        val inicio = intent.whenAt!!
        val ev = EventItem(
            id = Ids.novo(),
            title = intent.title!!,
            startAt = inicio,
            endAt = inicio + 60 * 60 * 1000,
            createdAt = agoraMs,
            updatedAt = agoraMs
        )
        events.insert(ev)

        val avisoEm = inicio - avisoEventoMinutos * 60_000L
        var aviso: String? = null
        if (avisoEm > agoraMs) {
            val r = Reminder(
                id = Ids.novo(),
                title = ev.title,
                message = "Compromisso em $avisoEventoMinutos minutos",
                triggerAt = avisoEm,
                kind = ReminderKind.EVENT,
                eventId = ev.id,
                createdAt = agoraMs,
                updatedAt = agoraMs
            )
            reminders.insert(r)
            alarms.agendar(r)
            aviso = " Te aviso $avisoEventoMinutos minutos antes."
        }
        audit.registrar("EVENT_CREATE", "event", ev.id, ev.title)

        return AssistantReply(
            "Agendado, $USUARIO_PRINCIPAL: ${ev.title}, ${PtBrDateTime.formatFriendly(local(inicio), agora)}.${aviso ?: ""}",
            intent = intent.type
        )
    }

    private fun criarRotina(intent: ParsedIntent, agora: LocalDateTime, agoraMs: Long): AssistantReply {
        val quando = intent.whenAt!!
        val dt = local(quando)
        val rotina = RoutineItem(
            id = Ids.novo(),
            title = intent.title!!,
            recurrence = intent.recurrence,
            timeOfDayMinutes = dt.hour * 60 + dt.minute,
            createdAt = agoraMs,
            updatedAt = agoraMs
        )
        val r = Reminder(
            id = Ids.novo(),
            title = rotina.title,
            triggerAt = quando,
            recurrence = intent.recurrence,
            kind = ReminderKind.USER,
            createdAt = agoraMs,
            updatedAt = agoraMs
        )
        reminders.insert(r)
        alarms.agendar(r)
        routines.insert(rotina.copy(reminderId = r.id))
        audit.registrar("ROUTINE_CREATE", "routine", rotina.id, rotina.title)

        return AssistantReply(
            "Rotina criada, $USUARIO_PRINCIPAL: ${rotina.title}, ${intent.recurrence.describe()} às ${hhmm(quando)}.",
            intent = intent.type,
            createdReminderId = r.id
        )
    }

    private fun concluirTarefa(intent: ParsedIntent): AssistantReply {
        val achadas = resolverTarefas(intent)
        when {
            achadas.isEmpty() -> return AssistantReply(
                "Não achei essa tarefa, $USUARIO_PRINCIPAL. Pode dizer o nome de novo?",
                intent = intent.type
            )
            achadas.size > 1 -> return perguntarQual(achadas, intent)
        }
        val t = achadas.first()
        val agoraMs = clock.nowMillis()
        tasks.update(t.copy(status = TaskStatus.CONCLUIDA, completedAt = agoraMs, updatedAt = agoraMs))
        reminders.porTarefa(t.id).forEach {
            alarms.cancelar(it.id)
            reminders.update(it.copy(active = false, updatedAt = agoraMs))
        }
        audit.registrar("TASK_COMPLETE", "task", t.id, t.title)
        return AssistantReply("Feito, $USUARIO_PRINCIPAL. Concluí: ${t.title}.", intent = intent.type)
    }

    private fun adiarTarefa(intent: ParsedIntent, agora: LocalDateTime, agoraMs: Long): AssistantReply {
        val achadas = resolverTarefas(intent)
        when {
            achadas.isEmpty() -> return AssistantReply(
                "Não achei essa tarefa, $USUARIO_PRINCIPAL.", intent = intent.type
            )
            achadas.size > 1 -> return perguntarQual(achadas, intent)
        }
        val t = achadas.first()
        val novoPrazo = intent.whenAt
            ?: ((t.dueAt ?: agoraMs) + (intent.offsetMinutes ?: 60) * 60_000L)
        tasks.update(
            t.copy(
                dueAt = novoPrazo,
                hasTime = intent.hasTime || t.hasTime,
                status = TaskStatus.ADIADA,
                updatedAt = agoraMs
            )
        )
        reminders.porTarefa(t.id).filter { it.active }.forEach {
            val atualizado = it.copy(triggerAt = novoPrazo, updatedAt = agoraMs)
            reminders.update(atualizado)
            alarms.agendar(atualizado)
        }
        audit.registrar("TASK_POSTPONE", "task", t.id, "novo prazo $novoPrazo")
        return AssistantReply(
            "Adiado, $USUARIO_PRINCIPAL. ${t.title} agora fica para ${PtBrDateTime.formatFriendly(local(novoPrazo), agora)}.",
            intent = intent.type
        )
    }

    private fun adiarLembretePorTexto(intent: ParsedIntent, agora: LocalDateTime, agoraMs: Long): AssistantReply {
        val ativos = reminders.ativos().sortedBy { it.triggerAt }
        val alvo = when {
            intent.targetId != null -> reminders.byId(intent.targetId)
            intent.targetRef == RuleBasedInterpreter.REF_ULTIMO -> ativos.firstOrNull()
            else -> {
                val n = PtBrDateTime.normalize(intent.targetRef.orEmpty())
                ativos.maxByOrNull { pontuar(PtBrDateTime.normalize(it.title), n) }
                    ?.takeIf { pontuar(PtBrDateTime.normalize(it.title), n) > 0 }
                    ?: ativos.firstOrNull()
            }
        } ?: return AssistantReply("Não achei esse lembrete, $USUARIO_PRINCIPAL.", intent = intent.type)

        val novo = intent.whenAt ?: (alvo.triggerAt + (intent.offsetMinutes ?: 60) * 60_000L)
        val atualizado = alvo.copy(triggerAt = novo, snoozeCount = alvo.snoozeCount + 1, updatedAt = agoraMs)
        reminders.update(atualizado)
        alarms.agendar(atualizado)
        audit.registrar("REMINDER_POSTPONE", "reminder", alvo.id, "novo horário $novo")
        return AssistantReply(
            "Adiado, $USUARIO_PRINCIPAL. Te lembro ${PtBrDateTime.formatFriendly(local(novo), agora)}.",
            intent = intent.type
        )
    }

    private fun apagarTarefa(intent: ParsedIntent): AssistantReply {
        val achadas = resolverTarefas(intent)
        when {
            achadas.isEmpty() -> return AssistantReply("Não achei essa tarefa, $USUARIO_PRINCIPAL.", intent = intent.type)
            achadas.size > 1 -> return perguntarQual(achadas, intent)
        }
        val t = achadas.first()
        reminders.porTarefa(t.id).forEach { alarms.cancelar(it.id); reminders.delete(it.id) }
        tasks.delete(t.id)
        audit.registrar("TASK_DELETE", "task", t.id, t.title)
        return AssistantReply("Removido, $USUARIO_PRINCIPAL: ${t.title}.", intent = intent.type)
    }

    private fun apagarLembrete(intent: ParsedIntent): AssistantReply {
        val ativos = reminders.ativos().sortedBy { it.triggerAt }
        val n = PtBrDateTime.normalize(intent.targetRef.orEmpty())
        val alvo = when {
            intent.targetId != null -> reminders.byId(intent.targetId)
            intent.targetRef == RuleBasedInterpreter.REF_ULTIMO -> ativos.firstOrNull()
            else -> ativos.maxByOrNull { pontuar(PtBrDateTime.normalize(it.title), n) }
                ?.takeIf { pontuar(PtBrDateTime.normalize(it.title), n) > 0 }
        } ?: return AssistantReply("Não achei esse lembrete, $USUARIO_PRINCIPAL.", intent = intent.type)

        alarms.cancelar(alvo.id)
        reminders.delete(alvo.id)
        audit.registrar("REMINDER_DELETE", "reminder", alvo.id, alvo.title)
        return AssistantReply("Lembrete removido, $USUARIO_PRINCIPAL.", intent = intent.type)
    }

    private fun perguntarQual(candidatas: List<Task>, intent: ParsedIntent): AssistantReply {
        val opcoes = candidatas.take(4)
        val pergunta = "$USUARIO_PRINCIPAL, você está falando de qual? " +
            opcoes.mapIndexed { i, t -> "${i + 1}) ${t.title}" }.joinToString("  ")
        val p = PendingRequest(pergunta, Slot.ALVO, intent, opcoes.map { it.id })
        pendings.salvar(p)
        return AssistantReply(pergunta, pending = p, intent = intent.type)
    }

    // ==================================================================
    // Disparo de lembretes (chamado pelo AlarmManager)
    // ==================================================================

    data class Disparo(
        val titulo: String,
        val texto: String,
        val reminderId: String,
        val taskId: String?,
        val proximoEm: Long?
    )

    /**
     * Processa o disparo de um lembrete: monta o texto da notificação,
     * calcula a próxima ocorrência (se recorrente) e reagenda.
     */
    fun dispararLembrete(reminderId: String): Disparo? {
        val r = reminders.byId(reminderId) ?: return null
        if (!r.active) return null
        val agoraMs = clock.nowMillis()

        val texto = when (r.kind) {
            ReminderKind.DAILY_SUMMARY -> resumoDiario(local(agoraMs)).fala
            ReminderKind.NIGHT_SUMMARY -> resumoNoturno(local(agoraMs)).fala
            ReminderKind.EVENT -> "$USUARIO_PRINCIPAL, ${r.message ?: "compromisso chegando"}: ${r.title}."
            else -> "$USUARIO_PRINCIPAL, lembrete: ${r.title}."
        }

        val proximo = if (r.recurrence.isRecurring) {
            val base = local(maxOf(r.triggerAt, agoraMs))
            r.recurrence.next(base, LocalTime.of(local(r.triggerAt).hour, local(r.triggerAt).minute))
                ?.atZone(zone)?.toInstant()?.toEpochMilli()
        } else null

        val atualizado = r.copy(
            lastFiredAt = agoraMs,
            fireCount = r.fireCount + 1,
            triggerAt = proximo ?: r.triggerAt,
            active = proximo != null,
            updatedAt = agoraMs
        )
        reminders.update(atualizado)
        if (proximo != null) alarms.agendar(atualizado)

        audit.registrar("REMINDER_FIRE", "reminder", r.id, r.title)
        return Disparo("ALAN ASSISTANT", texto, r.id, r.taskId, proximo)
    }

    /** Ação "ADIAR 30 MIN" da notificação. */
    fun adiarLembrete(reminderId: String, minutos: Int): Boolean {
        val r = reminders.byId(reminderId) ?: return false
        val agoraMs = clock.nowMillis()
        val novo = r.copy(
            triggerAt = agoraMs + minutos * 60_000L,
            active = true,
            snoozeCount = r.snoozeCount + 1,
            updatedAt = agoraMs
        )
        reminders.update(novo)
        alarms.agendar(novo)
        audit.registrar("REMINDER_SNOOZE", "reminder", r.id, "+$minutos min")
        return true
    }

    /** Ação "CONCLUIR" da notificação. */
    fun concluirPorLembrete(reminderId: String): Boolean {
        val r = reminders.byId(reminderId) ?: return false
        val agoraMs = clock.nowMillis()
        r.taskId?.let { id ->
            tasks.byId(id)?.let {
                tasks.update(it.copy(status = TaskStatus.CONCLUIDA, completedAt = agoraMs, updatedAt = agoraMs))
                audit.registrar("TASK_COMPLETE", "task", it.id, "via notificação")
            }
        }
        if (!r.recurrence.isRecurring) {
            reminders.update(r.copy(active = false, updatedAt = agoraMs))
            alarms.cancelar(r.id)
        }
        return true
    }

    // ==================================================================
    // Boot / manutenção
    // ==================================================================

    /**
     * Reconstrói todos os agendamentos a partir do banco (item 18).
     * Lembretes cujo horário passou enquanto o aparelho estava desligado são
     * devolvidos como "perdidos" para notificação imediata.
     */
    fun reagendarTudo(): List<Reminder> {
        val agoraMs = clock.nowMillis()
        val ativos = reminders.ativos()
        val perdidos = ativos.filter { it.triggerAt <= agoraMs }
        val futuros = ativos.filter { it.triggerAt > agoraMs }
        alarms.reagendarTodos(futuros)
        audit.registrar(
            "RESCHEDULE_ALL", "system", null,
            "${futuros.size} reagendados, ${perdidos.size} atrasados"
        )
        return perdidos
    }

    /** Garante que os resumos diário/noturno estejam agendados. */
    fun garantirResumos(horaManha: Int?, horaNoite: Int?) {
        val agoraMs = clock.nowMillis()
        val agora = local(agoraMs)

        fun sincronizar(kind: ReminderKind, hora: Int?, titulo: String) {
            val existentes = reminders.porTipo(kind)
            if (hora == null) {
                existentes.forEach { alarms.cancelar(it.id); reminders.delete(it.id) }
                return
            }
            val rec = Recurrence(RecurrenceType.DAILY)
            val proximo = rec.next(agora, LocalTime.of(hora, 0))!!
                .atZone(zone).toInstant().toEpochMilli()
            val atual = existentes.firstOrNull()
            if (atual == null) {
                val r = Reminder(
                    id = Ids.novo(), title = titulo, triggerAt = proximo,
                    recurrence = rec, kind = kind, createdAt = agoraMs, updatedAt = agoraMs
                )
                reminders.insert(r)
                alarms.agendar(r)
            } else if (local(atual.triggerAt).hour != hora || !atual.active) {
                val r = atual.copy(triggerAt = proximo, active = true, recurrence = rec, updatedAt = agoraMs)
                reminders.update(r)
                alarms.agendar(r)
            }
            existentes.drop(1).forEach { alarms.cancelar(it.id); reminders.delete(it.id) }
        }

        sincronizar(ReminderKind.DAILY_SUMMARY, horaManha, "Resumo do dia")
        sincronizar(ReminderKind.NIGHT_SUMMARY, horaNoite, "Resumo da noite")
    }

    fun atualizarAtrasadas() {
        val agoraMs = clock.nowMillis()
        tasks.abertas()
            .filter { it.dueAt != null && it.dueAt < agoraMs }
            .filter { it.status == TaskStatus.PENDENTE || it.status == TaskStatus.ADIADA }
            .forEach { tasks.update(it.copy(status = TaskStatus.ATRASADA, updatedAt = agoraMs)) }
    }

    // ==================================================================
    // Resumos
    // ==================================================================

    fun resumoDiario(agora: LocalDateTime): SummaryText {
        atualizarAtrasadas()
        val inicio = agora.toLocalDate().atStartOfDay().atZone(zone).toInstant().toEpochMilli()
        val fim = agora.toLocalDate().plusDays(1).atStartOfDay().atZone(zone).toInstant().toEpochMilli()
        val hoje = tasks.comPrazoEntre(inicio, fim).filter { it.status.aberta }
        val atrasadas = tasks.abertas().filter { it.status == TaskStatus.ATRASADA && (it.dueAt ?: 0) < inicio }
        val lembretes = reminders.ativosEntre(maxOf(inicio, clock.nowMillis()), fim)
            .filter { it.kind == ReminderKind.USER || it.kind == ReminderKind.TASK }
        val eventos = events.entre(inicio, fim)
        return Summaries.diario(hoje, atrasadas, lembretes, eventos, agora)
    }

    fun resumoNoturno(agora: LocalDateTime): SummaryText {
        val inicio = agora.toLocalDate().atStartOfDay().atZone(zone).toInstant().toEpochMilli()
        val fim = agora.toLocalDate().plusDays(1).atStartOfDay().atZone(zone).toInstant().toEpochMilli()
        val fimAmanha = agora.toLocalDate().plusDays(2).atStartOfDay().atZone(zone).toInstant().toEpochMilli()
        val concluidas = tasks.concluidasEntre(inicio, fim)
        val abertas = tasks.abertas()
        val amanha = tasks.comPrazoEntre(fim, fimAmanha).filter { it.status.aberta }
        return Summaries.noturno(concluidas, abertas, amanha)
    }

    fun resumoSemanal(agora: LocalDateTime): SummaryText {
        val inicioSemana = agora.toLocalDate().minusDays((agora.dayOfWeek.value - 1).toLong())
            .atStartOfDay().atZone(zone).toInstant().toEpochMilli()
        val fimSemana = agora.toLocalDate().plusDays((8 - agora.dayOfWeek.value).toLong())
            .atStartOfDay().atZone(zone).toInstant().toEpochMilli()
        val concluidas = tasks.concluidasEntre(inicioSemana, fimSemana)
        val abertas = tasks.abertas()
        val atrasadas = abertas.filter { it.status == TaskStatus.ATRASADA }
        return Summaries.semanal(concluidas, abertas, atrasadas)
    }

    private fun tarefasPorEscopo(scope: QueryScope, agora: LocalDateTime): Pair<List<Task>, String> {
        val d0 = agora.toLocalDate().atStartOfDay().atZone(zone).toInstant().toEpochMilli()
        val d1 = agora.toLocalDate().plusDays(1).atStartOfDay().atZone(zone).toInstant().toEpochMilli()
        val d2 = agora.toLocalDate().plusDays(2).atStartOfDay().atZone(zone).toInstant().toEpochMilli()
        val d7 = agora.toLocalDate().plusDays(8).atStartOfDay().atZone(zone).toInstant().toEpochMilli()
        return when (scope) {
            QueryScope.HOJE -> tasks.comPrazoEntre(d0, d1).filter { it.status.aberta } to "Tarefas de hoje"
            QueryScope.AMANHA -> tasks.comPrazoEntre(d1, d2).filter { it.status.aberta } to "Tarefas de amanhã"
            QueryScope.SEMANA -> tasks.comPrazoEntre(d0, d7).filter { it.status.aberta } to "Tarefas da semana"
            QueryScope.ATRASADAS -> tasks.abertas().filter { it.status == TaskStatus.ATRASADA } to "Tarefas atrasadas"
            QueryScope.ABERTAS -> tasks.abertas() to "Tarefas em aberto"
            QueryScope.CONCLUIDAS -> tasks.concluidasEntre(d0 - 7L * 86_400_000, d1) to "Concluídas recentemente"
            QueryScope.TODAS -> tasks.todas() to "Todas as tarefas"
        }
    }

    // ==================================================================
    // Resolução de alvos
    // ==================================================================

    private fun resolverTarefas(intent: ParsedIntent): List<Task> {
        intent.targetId?.let { id -> return listOfNotNull(tasks.byId(id)) }
        val abertas = tasks.abertas().sortedByDescending { it.updatedAt }
        if (abertas.isEmpty()) return emptyList()
        val ref = intent.targetRef ?: return emptyList()
        if (ref == RuleBasedInterpreter.REF_ULTIMO) return listOf(abertas.first())

        val alvo = PtBrDateTime.normalize(ref)
        val pontuadas = abertas.map { it to pontuar(PtBrDateTime.normalize(it.title), alvo) }
            .filter { it.second > 0 }
        if (pontuadas.isEmpty()) return emptyList()
        val max = pontuadas.maxOf { it.second }
        return pontuadas.filter { it.second == max }.map { it.first }
    }

    private fun pontuar(titulo: String, termo: String): Int {
        if (termo.isBlank()) return 0
        var p = 0
        if (titulo.contains(termo)) p += 10
        val tokens = termo.split(Regex("""\s+""")).filter { it.length >= 3 }
        for (tk in tokens) if (titulo.contains(tk)) p += 3
        return p
    }

    // ==================================================================

    private fun local(ms: Long): LocalDateTime =
        LocalDateTime.ofInstant(Instant.ofEpochMilli(ms), zone)

    private fun hhmm(ms: Long): String {
        val d = local(ms)
        return String.format("%02d:%02d", d.hour, d.minute)
    }

    fun diasAte(ms: Long, agora: LocalDateTime): Long =
        ChronoUnit.DAYS.between(agora.toLocalDate(), local(ms).toLocalDate())

    companion object {
        const val AJUDA =
            "Posso criar tarefas, lembretes, rotinas e compromissos, e te avisar na hora certa.\n\n" +
                "Experimente:\n" +
                "• \"Me lembra amanhã às 10h de enviar o relatório\"\n" +
                "• \"Anota que preciso terminar o sistema até sexta\"\n" +
                "• \"Toda sexta às 16h me lembra do fechamento semanal\"\n" +
                "• \"O que eu tenho hoje?\"\n" +
                "• \"O que está atrasado?\""
    }
}
