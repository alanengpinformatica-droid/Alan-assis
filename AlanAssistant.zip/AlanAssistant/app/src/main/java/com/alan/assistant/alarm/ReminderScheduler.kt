package com.alan.assistant.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.alan.assistant.core.AlarmPort
import com.alan.assistant.core.Reminder
import kotlin.math.absoluteValue

/**
 * Implementação real da porta AlarmPort usando o AlarmManager (item 29).
 *
 * DECISÕES IMPORTANTES
 * --------------------
 * 1. `setExactAndAllowWhileIdle` — único método que dispara na hora certa
 *    mesmo com o celular em Doze (tela desligada, parado no bolso). É o que
 *    garante o requisito nº 1 do Alan: o lembrete não pode atrasar.
 *
 * 2. NÃO usamos `setRepeating`. Alarmes repetitivos do Android são inexatos
 *    e não entendem "toda sexta" ou "primeiro dia útil do mês". Em vez disso,
 *    cada disparo calcula a PRÓXIMA ocorrência (no core, testado na JVM) e
 *    agenda um novo alarme exato. Um alarme por vez, sempre correto.
 *
 * 3. Nenhum serviço em primeiro plano, nenhum loop: fora do instante do
 *    disparo o app não consome bateria.
 *
 * 4. Se a permissão de alarme exato estiver revogada (Android 12), caímos
 *    para `setAndAllowWhileIdle` (pode atrasar alguns minutos) em vez de
 *    perder o lembrete — e a tela de Configurações avisa o Alan.
 */
class ReminderScheduler(private val context: Context) : AlarmPort {

    private val am: AlarmManager? =
        context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager

    override fun agendar(reminder: Reminder) {
        val manager = am ?: return
        if (!reminder.active) {
            cancelar(reminder.id)
            return
        }
        val pi = pendingIntent(reminder.id, criar = true) ?: return

        try {
            if (podeAgendarExato()) {
                manager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP, reminder.triggerAt, pi
                )
            } else {
                Log.w(TAG, "Sem permissão de alarme exato — usando alarme aproximado")
                manager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP, reminder.triggerAt, pi
                )
            }
        } catch (e: SecurityException) {
            // Alguns fabricantes revogam a permissão em tempo de execução.
            Log.e(TAG, "Falha ao agendar alarme exato: ${e.message}", e)
            runCatching {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.triggerAt, pi)
            }
        }
    }

    override fun cancelar(reminderId: String) {
        val manager = am ?: return
        val pi = pendingIntent(reminderId, criar = false) ?: return
        manager.cancel(pi)
        pi.cancel()
    }

    override fun reagendarTodos(lembretes: List<Reminder>) {
        lembretes.forEach { agendar(it) }
    }

    fun podeAgendarExato(): Boolean {
        val manager = am ?: return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            manager.canScheduleExactAlarms()
        } else {
            true
        }
    }

    private fun pendingIntent(reminderId: String, criar: Boolean): PendingIntent? {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = ACAO_DISPARAR
            // O data URI único evita que o Android trate dois lembretes
            // diferentes como o mesmo PendingIntent.
            data = android.net.Uri.parse("alan://reminder/$reminderId")
            putExtra(EXTRA_REMINDER_ID, reminderId)
        }
        val flags = if (criar) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        }
        return PendingIntent.getBroadcast(
            context, reminderId.hashCode().absoluteValue, intent, flags
        )
    }

    companion object {
        private const val TAG = "AlanScheduler"
        const val ACAO_DISPARAR = "com.alan.assistant.DISPARAR_LEMBRETE"
        const val EXTRA_REMINDER_ID = "reminder_id"
    }
}
