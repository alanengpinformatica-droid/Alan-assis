package com.alan.assistant.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * DAOs.
 *
 * Duas famílias de métodos de propósito diferente:
 *  - métodos BLOQUEANTES: usados pelo motor de negócio e pelos receivers
 *    (que rodam em background, dentro de goAsync/Worker). Isso mantém as
 *    portas do core sem `suspend`, o que simplifica muito os testes.
 *  - métodos que devolvem `Flow`: usados só pela UI (Compose), para que as
 *    listas se atualizem sozinhas quando o banco muda.
 */

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun upsert(user: UserEntity)

    @Query("SELECT * FROM users LIMIT 1")
    fun primeiro(): UserEntity?
}

@Dao
interface TaskDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(task: TaskEntity)

    @Update
    fun update(task: TaskEntity)

    @Query("DELETE FROM tasks WHERE id = :id")
    fun delete(id: String)

    @Query("SELECT * FROM tasks WHERE id = :id")
    fun byId(id: String): TaskEntity?

    @Query(
        "SELECT * FROM tasks WHERE status IN ('PENDENTE','EM_ANDAMENTO','ATRASADA','ADIADA') " +
            "ORDER BY (dueAt IS NULL), dueAt ASC, createdAt DESC"
    )
    fun abertas(): List<TaskEntity>

    @Query("SELECT * FROM tasks ORDER BY createdAt DESC")
    fun todas(): List<TaskEntity>

    @Query(
        "SELECT * FROM tasks WHERE dueAt IS NOT NULL AND dueAt BETWEEN :inicio AND :fim " +
            "ORDER BY dueAt ASC"
    )
    fun comPrazoEntre(inicio: Long, fim: Long): List<TaskEntity>

    @Query(
        "SELECT * FROM tasks WHERE completedAt IS NOT NULL AND completedAt BETWEEN :inicio AND :fim " +
            "ORDER BY completedAt DESC"
    )
    fun concluidasEntre(inicio: Long, fim: Long): List<TaskEntity>

    // --- UI reativa ---
    @Query(
        "SELECT * FROM tasks ORDER BY " +
            "CASE WHEN status IN ('CONCLUIDA','CANCELADA') THEN 1 ELSE 0 END, " +
            "(dueAt IS NULL), dueAt ASC, createdAt DESC"
    )
    fun fluxoTodas(): Flow<List<TaskEntity>>

    @Query("SELECT COUNT(*) FROM tasks WHERE status IN ('PENDENTE','EM_ANDAMENTO','ADIADA')")
    fun fluxoAbertas(): Flow<Int>

    @Query("SELECT COUNT(*) FROM tasks WHERE status = 'ATRASADA'")
    fun fluxoAtrasadas(): Flow<Int>
}

@Dao
interface ReminderDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(reminder: ReminderEntity)

    @Update
    fun update(reminder: ReminderEntity)

    @Query("DELETE FROM reminders WHERE id = :id")
    fun delete(id: String)

    @Query("SELECT * FROM reminders WHERE id = :id")
    fun byId(id: String): ReminderEntity?

    @Query("SELECT * FROM reminders WHERE active = 1 ORDER BY triggerAt ASC")
    fun ativos(): List<ReminderEntity>

    @Query(
        "SELECT * FROM reminders WHERE active = 1 AND triggerAt BETWEEN :inicio AND :fim " +
            "ORDER BY triggerAt ASC"
    )
    fun ativosEntre(inicio: Long, fim: Long): List<ReminderEntity>

    @Query("SELECT * FROM reminders WHERE taskId = :taskId")
    fun porTarefa(taskId: String): List<ReminderEntity>

    @Query("SELECT * FROM reminders WHERE kind = :kind")
    fun porTipo(kind: String): List<ReminderEntity>

    @Query("SELECT * FROM reminders WHERE active = 1 ORDER BY triggerAt ASC")
    fun fluxoAtivos(): Flow<List<ReminderEntity>>

    @Query(
        "SELECT COUNT(*) FROM reminders WHERE active = 1 AND kind IN ('USER','TASK','EVENT') " +
            "AND triggerAt BETWEEN :inicio AND :fim"
    )
    fun fluxoNoIntervalo(inicio: Long, fim: Long): Flow<Int>
}

@Dao
interface MemoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(item: MemoryEntity)

    @Update
    fun update(item: MemoryEntity)

    @Query("DELETE FROM memories WHERE id = :id")
    fun delete(id: String)

    @Query("SELECT * FROM memories ORDER BY pinned DESC, createdAt DESC")
    fun todas(): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE content LIKE '%' || :termo || '%' ORDER BY createdAt DESC")
    fun buscar(termo: String): List<MemoryEntity>

    @Query("SELECT * FROM memories ORDER BY pinned DESC, createdAt DESC")
    fun fluxoTodas(): Flow<List<MemoryEntity>>
}

@Dao
interface EventDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(item: EventEntity)

    @Query("DELETE FROM events WHERE id = :id")
    fun delete(id: String)

    @Query("SELECT * FROM events WHERE startAt BETWEEN :inicio AND :fim ORDER BY startAt ASC")
    fun entre(inicio: Long, fim: Long): List<EventEntity>

    @Query("SELECT * FROM events ORDER BY startAt DESC")
    fun todos(): List<EventEntity>

    @Query("SELECT COUNT(*) FROM events WHERE startAt BETWEEN :inicio AND :fim")
    fun fluxoNoIntervalo(inicio: Long, fim: Long): Flow<Int>
}

@Dao
interface RoutineDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(item: RoutineEntity)

    @Update
    fun update(item: RoutineEntity)

    @Query("DELETE FROM routines WHERE id = :id")
    fun delete(id: String)

    @Query("SELECT * FROM routines WHERE active = 1 ORDER BY timeOfDayMinutes ASC")
    fun ativas(): List<RoutineEntity>

    @Query("SELECT * FROM routines ORDER BY active DESC, timeOfDayMinutes ASC")
    fun todas(): List<RoutineEntity>

    @Query("SELECT * FROM routines ORDER BY active DESC, timeOfDayMinutes ASC")
    fun fluxoTodas(): Flow<List<RoutineEntity>>
}

@Dao
interface ConversationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(turn: ConversationEntity)

    @Query("SELECT * FROM conversations ORDER BY at DESC LIMIT :limite")
    fun ultimas(limite: Int): List<ConversationEntity>

    @Query("SELECT * FROM conversations ORDER BY at ASC")
    fun todas(): List<ConversationEntity>

    @Query("SELECT * FROM conversations ORDER BY at DESC LIMIT 200")
    fun fluxoRecentes(): Flow<List<ConversationEntity>>

    /** Poda o histórico de conversas — evita o banco crescer sem limite. */
    @Query(
        "DELETE FROM conversations WHERE id NOT IN " +
            "(SELECT id FROM conversations ORDER BY at DESC LIMIT :manter)"
    )
    fun podar(manter: Int)
}

@Dao
interface NotificationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(item: NotificationEntity)

    @Query("SELECT * FROM notifications ORDER BY at DESC LIMIT :limite")
    fun ultimas(limite: Int): List<NotificationEntity>

    @Query("SELECT * FROM notifications ORDER BY at DESC")
    fun todas(): List<NotificationEntity>
}

@Dao
interface SettingDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun set(item: SettingEntity)

    @Query("SELECT value FROM settings WHERE `key` = :key")
    fun get(key: String): String?

    @Query("SELECT * FROM settings")
    fun todas(): List<SettingEntity>

    @Query("SELECT * FROM settings")
    fun fluxoTodas(): Flow<List<SettingEntity>>
}

@Dao
interface AuditDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(item: AuditEntity)

    @Query("SELECT * FROM audit_log ORDER BY at DESC LIMIT :limite")
    fun ultimos(limite: Int): List<AuditEntity>

    @Query("SELECT * FROM audit_log ORDER BY at DESC")
    fun todos(): List<AuditEntity>

    @Query("SELECT * FROM audit_log ORDER BY at DESC LIMIT 300")
    fun fluxoRecentes(): Flow<List<AuditEntity>>

    /** Mantém no máximo `manter` registros de auditoria. */
    @Query(
        "DELETE FROM audit_log WHERE id NOT IN " +
            "(SELECT id FROM audit_log ORDER BY at DESC LIMIT :manter)"
    )
    fun podar(manter: Int)
}
