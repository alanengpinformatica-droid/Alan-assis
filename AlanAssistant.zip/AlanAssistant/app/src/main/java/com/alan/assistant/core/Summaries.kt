package com.alan.assistant.core

import java.time.LocalDateTime
import java.time.ZoneId

/** Texto do resumo em duas versões: para ler na tela e para falar em voz alta. */
data class SummaryText(val texto: String, val fala: String)

object Summaries {

    fun diario(
        tarefasHoje: List<Task>,
        atrasadas: List<Task>,
        lembretesHoje: List<Reminder>,
        eventosHoje: List<EventItem>,
        agora: LocalDateTime,
        saudacao: String = saudacaoPor(agora)
    ): SummaryText {
        val sb = StringBuilder()
        sb.append("$saudacao, $USUARIO_PRINCIPAL.\n\n")

        if (tarefasHoje.isEmpty() && atrasadas.isEmpty() &&
            lembretesHoje.isEmpty() && eventosHoje.isEmpty()
        ) {
            val t = sb.append("Sua agenda de hoje está livre. Nada pendente até agora.").toString()
            return SummaryText(t, "$saudacao, $USUARIO_PRINCIPAL. Hoje você não tem nada pendente.")
        }

        sb.append("Hoje você tem:\n")
        if (tarefasHoje.isNotEmpty()) sb.append("📌 ${plural(tarefasHoje.size, "tarefa", "tarefas")}\n")
        if (lembretesHoje.isNotEmpty()) sb.append("⏰ ${plural(lembretesHoje.size, "lembrete", "lembretes")}\n")
        if (atrasadas.isNotEmpty()) sb.append("⚠️ ${plural(atrasadas.size, "tarefa atrasada", "tarefas atrasadas")}\n")
        if (eventosHoje.isNotEmpty()) sb.append("📅 ${plural(eventosHoje.size, "compromisso", "compromissos")}\n")

        val prioridades = (atrasadas + tarefasHoje)
            .distinctBy { it.id }
            .sortedWith(compareByDescending<Task> { it.priority.peso }.thenBy { it.dueAt ?: Long.MAX_VALUE })
            .take(3)

        if (prioridades.isNotEmpty()) {
            sb.append("\nPrioridades:\n")
            prioridades.forEachIndexed { i, t -> sb.append("${i + 1}. ${t.title}\n") }
        }

        if (eventosHoje.isNotEmpty()) {
            sb.append("\nAgenda:\n")
            eventosHoje.take(4).forEach { sb.append("• ${it.title}\n") }
        }

        val fala = buildString {
            append("$saudacao, $USUARIO_PRINCIPAL. Hoje você tem ")
            val partes = mutableListOf<String>()
            if (tarefasHoje.isNotEmpty()) partes += plural(tarefasHoje.size, "tarefa", "tarefas")
            if (lembretesHoje.isNotEmpty()) partes += plural(lembretesHoje.size, "lembrete", "lembretes")
            if (eventosHoje.isNotEmpty()) partes += plural(eventosHoje.size, "compromisso", "compromissos")
            append(partes.joinToString(", "))
            if (atrasadas.isNotEmpty()) {
                if (partes.isNotEmpty()) append(". ")
                append("${plural(atrasadas.size, "tarefa está atrasada", "tarefas estão atrasadas")}")
            }
            append(".")
            if (prioridades.isNotEmpty()) append(" A prioridade é ${prioridades.first().title}.")
        }

        return SummaryText(sb.toString().trimEnd(), fala)
    }

    fun noturno(
        concluidasHoje: List<Task>,
        aindaAbertas: List<Task>,
        amanha: List<Task>
    ): SummaryText {
        val texto = buildString {
            append("$USUARIO_PRINCIPAL, encerrando o dia:\n\n")
            append("✅ ${plural(concluidasHoje.size, "tarefa concluída", "tarefas concluídas")}\n")
            append("📌 ${plural(aindaAbertas.size, "ainda pendente", "ainda pendentes")}\n")
            append("➡️ ${plural(amanha.size, "tarefa para amanhã", "tarefas para amanhã")}")
            if (amanha.isNotEmpty()) {
                append("\n\nAmanhã:\n")
                amanha.take(4).forEach { append("• ${it.title}\n") }
            }
        }.trimEnd()

        val fala = "$USUARIO_PRINCIPAL, encerrando o dia: você concluiu " +
            "${plural(concluidasHoje.size, "tarefa", "tarefas")}, deixou " +
            "${plural(aindaAbertas.size, "pendente", "pendentes")} e tem " +
            "${plural(amanha.size, "tarefa", "tarefas")} para amanhã."

        return SummaryText(texto, fala)
    }

    fun semanal(
        concluidas: List<Task>,
        abertas: List<Task>,
        atrasadas: List<Task>
    ): SummaryText {
        val texto = buildString {
            append("Resumo da semana, $USUARIO_PRINCIPAL:\n\n")
            append("✅ ${plural(concluidas.size, "tarefa concluída", "tarefas concluídas")}\n")
            append("📌 ${plural(abertas.size, "tarefa em aberto", "tarefas em aberto")}\n")
            append("⚠️ ${plural(atrasadas.size, "atrasada", "atrasadas")}")
            if (atrasadas.isNotEmpty()) {
                append("\n\nEm atraso:\n")
                atrasadas.take(5).forEach { append("• ${it.title}\n") }
            }
        }.trimEnd()
        val fala = "Na semana você concluiu ${plural(concluidas.size, "tarefa", "tarefas")} e tem " +
            "${plural(abertas.size, "em aberto", "em aberto")}."
        return SummaryText(texto, fala)
    }

    fun listaTarefas(
        tarefas: List<Task>,
        titulo: String,
        agora: LocalDateTime,
        zone: ZoneId
    ): SummaryText {
        if (tarefas.isEmpty()) {
            val t = "$titulo: nada por aqui, $USUARIO_PRINCIPAL."
            return SummaryText(t, t)
        }
        val texto = buildString {
            append("$titulo (${tarefas.size}):\n\n")
            tarefas.take(15).forEach { t ->
                append("• ${t.title}")
                val marcas = mutableListOf<String>()
                t.dueAt?.let { marcas += PtBrDateTime.formatFriendly(msParaLocal(it, zone), agora, t.hasTime) }
                if (t.priority != Priority.NORMAL) marcas += t.priority.label
                if (t.status == TaskStatus.ATRASADA) marcas += "atrasada"
                if (marcas.isNotEmpty()) append(" — ${marcas.joinToString(", ")}")
                append("\n")
            }
        }.trimEnd()
        val fala = "$titulo: ${plural(tarefas.size, "item", "itens")}. " +
            tarefas.take(3).joinToString(". ") { it.title } + "."
        return SummaryText(texto, fala)
    }

    fun listaLembretes(
        lembretes: List<Reminder>,
        agora: LocalDateTime,
        zone: ZoneId
    ): SummaryText {
        if (lembretes.isEmpty()) {
            val t = "Você não tem lembretes ativos, $USUARIO_PRINCIPAL."
            return SummaryText(t, t)
        }
        val texto = buildString {
            append("Seus lembretes (${lembretes.size}):\n\n")
            lembretes.take(15).forEach { r ->
                append("⏰ ${r.title} — ${PtBrDateTime.formatFriendly(msParaLocal(r.triggerAt, zone), agora)}")
                if (r.recurrence.isRecurring) append(" (${r.recurrence.describe()})")
                append("\n")
            }
        }.trimEnd()
        val fala = "Você tem ${plural(lembretes.size, "lembrete", "lembretes")}. " +
            "O próximo é ${lembretes.first().title}."
        return SummaryText(texto, fala)
    }

    fun listaMemoria(itens: List<MemoryItem>): SummaryText {
        if (itens.isEmpty()) {
            val t = "Ainda não guardei nada na memória, $USUARIO_PRINCIPAL."
            return SummaryText(t, t)
        }
        val texto = buildString {
            append("O que eu guardei sobre você:\n\n")
            itens.take(20).forEach { append("• ${it.content}\n") }
        }.trimEnd()
        val fala = "Eu guardei ${plural(itens.size, "informação", "informações")}. " +
            itens.take(3).joinToString(". ") { it.content }
        return SummaryText(texto, fala)
    }

    fun listaRotinas(rotinas: List<RoutineItem>): SummaryText {
        if (rotinas.isEmpty()) {
            val t = "Você não tem rotinas cadastradas, $USUARIO_PRINCIPAL."
            return SummaryText(t, t)
        }
        val texto = buildString {
            append("Suas rotinas (${rotinas.size}):\n\n")
            rotinas.forEach { r ->
                val h = String.format("%02d:%02d", r.timeOfDayMinutes / 60, r.timeOfDayMinutes % 60)
                append("🔁 ${r.title} — ${r.recurrence.describe()} às $h\n")
            }
        }.trimEnd()
        return SummaryText(texto, "Você tem ${plural(rotinas.size, "rotina", "rotinas")}.")
    }

    // ------------------------------------------------------------------

    fun saudacaoPor(agora: LocalDateTime): String = when (agora.hour) {
        in 0..11 -> "Bom dia"
        in 12..17 -> "Boa tarde"
        else -> "Boa noite"
    }

    fun plural(n: Int, singular: String, plural: String): String =
        if (n == 1) "1 $singular" else "$n $plural"

    private fun msParaLocal(ms: Long, zone: ZoneId): LocalDateTime =
        LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(ms), zone)
}
