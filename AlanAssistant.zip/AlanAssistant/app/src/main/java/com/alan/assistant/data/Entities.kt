package com.alan.assistant.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.alan.assistant.core.EventItem
import com.alan.assistant.core.MemoryItem
import com.alan.assistant.core.Priority
import com.alan.assistant.core.Recurrence
import com.alan.assistant.core.Reminder
import com.alan.assistant.core.ReminderKind
import com.alan.assistant.core.RoutineItem
import com.alan.assistant.core.Task
import com.alan.assistant.core.TaskStatus

/**
 * Tabelas do banco local (SQLite via Room), conforme o item 11 do escopo.
 *
 * Todos os enums e a recorrência são gravados como TEXTO. Isso mantém o
 * esquema estável: adicionar um novo tipo de recorrência no futuro não exige
 * migração de banco.
 */

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val language: String,
    val timezone: String,
    val createdAt: Long
)

@Entity(
    tableName = "tasks",
    indices = [Index("status"), Index("dueAt"), Index("createdAt")]
)
data class TaskEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val dueAt: Long?,
    val hasTime: Boolean,
    val priority: String,
    val category: String?,
    val status: String,
    val notes: String?,
    val recurrence: String,
    val completedAt: Long?,
    val reminderId: String?
)

@Entity(
    tableName = "reminders",
    indices = [Index("triggerAt"), Index("active"), Index("taskId"), Index("kind")]
)
data class ReminderEntity(
    @PrimaryKey val id: String,
    val title: String,
    val message: String?,
    val triggerAt: Long,
    val active: Boolean,
    val recurrence: String,
    val kind: String,
    val taskId: String?,
    val eventId: String?,
    val lastFiredAt: Long?,
    val fireCount: Int,
    val snoozeCount: Int,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "memories", indices = [Index("createdAt")])
data class MemoryEntity(
    @PrimaryKey val id: String,
    val content: String,
    val topic: String?,
    val pinned: Boolean,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "events", indices = [Index("startAt")])
data class EventEntity(
    @PrimaryKey val id: String,
    val title: String,
    val startAt: Long,
    val endAt: Long?,
    val location: String?,
    val notes: String?,
    val reminderId: String?,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "routines", indices = [Index("active")])
data class RoutineEntity(
    @PrimaryKey val id: String,
    val title: String,
    val recurrence: String,
    val timeOfDayMinutes: Int,
    val active: Boolean,
    val reminderId: String?,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "conversations", indices = [Index("at")])
data class ConversationEntity(
    @PrimaryKey val id: String,
    val at: Long,
    val role: String,
    val text: String,
    val intent: String?,
    val viaVoice: Boolean
)

@Entity(tableName = "notifications", indices = [Index("at")])
data class NotificationEntity(
    @PrimaryKey val id: String,
    val at: Long,
    val reminderId: String?,
    val title: String,
    val body: String,
    val delivered: Boolean
)

@Entity(tableName = "settings")
data class SettingEntity(
    @PrimaryKey val key: String,
    val value: String
)

@Entity(tableName = "audit_log", indices = [Index("at"), Index("entityType")])
data class AuditEntity(
    @PrimaryKey val id: String,
    val at: Long,
    val actor: String,
    val action: String,
    val entityType: String,
    val entityId: String?,
    val detail: String?
)

// ======================================================================
// Conversões entidade <-> domínio
// ======================================================================

fun TaskEntity.toDomain() = Task(
    id = id,
    title = title,
    description = description,
    createdAt = createdAt,
    updatedAt = updatedAt,
    dueAt = dueAt,
    hasTime = hasTime,
    priority = Priority.from(priority),
    category = category,
    status = TaskStatus.from(status),
    notes = notes,
    recurrence = Recurrence.decode(recurrence),
    completedAt = completedAt,
    reminderId = reminderId
)

fun Task.toEntity() = TaskEntity(
    id = id,
    title = title,
    description = description,
    createdAt = createdAt,
    updatedAt = updatedAt,
    dueAt = dueAt,
    hasTime = hasTime,
    priority = priority.name,
    category = category,
    status = status.name,
    notes = notes,
    recurrence = recurrence.encode(),
    completedAt = completedAt,
    reminderId = reminderId
)

fun ReminderEntity.toDomain() = Reminder(
    id = id,
    title = title,
    message = message,
    triggerAt = triggerAt,
    active = active,
    recurrence = Recurrence.decode(recurrence),
    kind = ReminderKind.from(kind),
    taskId = taskId,
    eventId = eventId,
    lastFiredAt = lastFiredAt,
    fireCount = fireCount,
    snoozeCount = snoozeCount,
    createdAt = createdAt,
    updatedAt = updatedAt
)

fun Reminder.toEntity() = ReminderEntity(
    id = id,
    title = title,
    message = message,
    triggerAt = triggerAt,
    active = active,
    recurrence = recurrence.encode(),
    kind = kind.name,
    taskId = taskId,
    eventId = eventId,
    lastFiredAt = lastFiredAt,
    fireCount = fireCount,
    snoozeCount = snoozeCount,
    createdAt = createdAt,
    updatedAt = updatedAt
)

fun MemoryEntity.toDomain() = MemoryItem(id, content, topic, pinned, createdAt, updatedAt)

fun MemoryItem.toEntity() = MemoryEntity(id, content, topic, pinned, createdAt, updatedAt)

fun EventEntity.toDomain() =
    EventItem(id, title, startAt, endAt, location, notes, reminderId, createdAt, updatedAt)

fun EventItem.toEntity() =
    EventEntity(id, title, startAt, endAt, location, notes, reminderId, createdAt, updatedAt)

fun RoutineEntity.toDomain() = RoutineItem(
    id = id,
    title = title,
    recurrence = Recurrence.decode(recurrence),
    timeOfDayMinutes = timeOfDayMinutes,
    active = active,
    reminderId = reminderId,
    createdAt = createdAt,
    updatedAt = updatedAt
)

fun RoutineItem.toEntity() = RoutineEntity(
    id = id,
    title = title,
    recurrence = recurrence.encode(),
    timeOfDayMinutes = timeOfDayMinutes,
    active = active,
    reminderId = reminderId,
    createdAt = createdAt,
    updatedAt = updatedAt
)
