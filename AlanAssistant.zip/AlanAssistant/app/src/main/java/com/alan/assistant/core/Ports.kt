package com.alan.assistant.core

/**
 * Portas do motor de negócio (arquitetura hexagonal simplificada).
 *
 * O motor só conhece estas interfaces. No app real elas são implementadas por
 * Room (banco) e AlarmManager (alarmes); nos testes, por implementações
 * em memória — por isso conseguimos testar TODA a lógica na JVM, sem emulador.
 *
 * Todas as chamadas são bloqueantes e devem rodar fora da main thread
 * (a ViewModel já faz isso com Dispatchers.IO).
 */

interface TaskStore {
    fun insert(task: Task)
    fun update(task: Task)
    fun delete(id: String)
    fun byId(id: String): Task?
    fun abertas(): List<Task>
    fun todas(): List<Task>
    fun comPrazoEntre(inicioMillis: Long, fimMillis: Long): List<Task>
    fun concluidasEntre(inicioMillis: Long, fimMillis: Long): List<Task>
}

interface ReminderStore {
    fun insert(reminder: Reminder)
    fun update(reminder: Reminder)
    fun delete(id: String)
    fun byId(id: String): Reminder?
    fun ativos(): List<Reminder>
    fun ativosEntre(inicioMillis: Long, fimMillis: Long): List<Reminder>
    fun porTarefa(taskId: String): List<Reminder>
    fun porTipo(kind: ReminderKind): List<Reminder>
}

interface MemoryStore {
    fun insert(item: MemoryItem)
    fun update(item: MemoryItem)
    fun delete(id: String)
    fun todas(): List<MemoryItem>
    fun buscar(termo: String): List<MemoryItem>
}

interface EventStore {
    fun insert(item: EventItem)
    fun delete(id: String)
    fun entre(inicioMillis: Long, fimMillis: Long): List<EventItem>
}

interface RoutineStore {
    fun insert(item: RoutineItem)
    fun update(item: RoutineItem)
    fun delete(id: String)
    fun ativas(): List<RoutineItem>
}

interface AuditPort {
    fun registrar(
        action: String,
        entityType: String,
        entityId: String?,
        detail: String?
    )
}

interface ConversationPort {
    fun registrar(role: String, text: String, intent: String?, viaVoice: Boolean)
}

/** Agendamento real de alarmes (AlarmManager no Android). */
interface AlarmPort {
    fun agendar(reminder: Reminder)
    fun cancelar(reminderId: String)
    fun reagendarTodos(lembretes: List<Reminder>)
}

interface ClockPort {
    fun nowMillis(): Long
}

/** Guarda o estado de desambiguação entre execuções do app. */
interface PendingStore {
    fun salvar(pending: PendingRequest?)
    fun carregar(): PendingRequest?
}

class SystemClockPort : ClockPort {
    override fun nowMillis(): Long = System.currentTimeMillis()
}

object Ids {
    fun novo(): String = java.util.UUID.randomUUID().toString()
}
