package com.alan.assistant.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Identidade visual.
 *
 * A cor não é enfeite: ela carrega significado e é usada com parcimônia.
 *  - azul profundo = o assistente e as ações principais;
 *  - âmbar = tempo (lembretes, compromissos);
 *  - vermelho = atraso, e nada mais.
 * O resto da tela é neutro, para a informação do dia aparecer sozinha.
 *
 * Dynamic color (Material You) está desligado de propósito: as cores acima
 * têm significado e não podem mudar conforme o papel de parede.
 */

val AzulProfundo = Color(0xFF27405F)
val AzulClaro = Color(0xFF6E92BF)
val Ambar = Color(0xFFB8761C)
val AmbarClaro = Color(0xFFE0A550)
val VermelhoAtraso = Color(0xFF9E3B30)
val VerdeConcluido = Color(0xFF2E6B4F)

private val Claro = lightColorScheme(
    primary = AzulProfundo,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD8E3F2),
    onPrimaryContainer = Color(0xFF0E2237),
    secondary = Ambar,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF7E6CB),
    onSecondaryContainer = Color(0xFF3A2606),
    error = VermelhoAtraso,
    onError = Color.White,
    background = Color(0xFFF4F5F7),
    onBackground = Color(0xFF14181D),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF14181D),
    surfaceVariant = Color(0xFFE6E9ED),
    onSurfaceVariant = Color(0xFF474D55),
    outline = Color(0xFFB4BAC2)
)

private val Escuro = darkColorScheme(
    primary = AzulClaro,
    onPrimary = Color(0xFF0B1725),
    primaryContainer = Color(0xFF1E3550),
    onPrimaryContainer = Color(0xFFD8E3F2),
    secondary = AmbarClaro,
    onSecondary = Color(0xFF2A1B04),
    secondaryContainer = Color(0xFF4A3410),
    onSecondaryContainer = Color(0xFFF7E6CB),
    error = Color(0xFFE8897C),
    onError = Color(0xFF3A0E09),
    background = Color(0xFF11151A),
    onBackground = Color(0xFFE3E6EA),
    surface = Color(0xFF181D24),
    onSurface = Color(0xFFE3E6EA),
    surfaceVariant = Color(0xFF262C35),
    onSurfaceVariant = Color(0xFFB7BEC7),
    outline = Color(0xFF4C545E)
)

private val TipografiaAlan = Typography(
    displaySmall = TextStyle(fontSize = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.5).sp),
    headlineSmall = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.SemiBold),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Medium)
)

@Composable
fun AlanTheme(
    escuro: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (escuro) Escuro else Claro,
        typography = TipografiaAlan,
        content = content
    )
}
