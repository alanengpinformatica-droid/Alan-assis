package com.alan.assistant.notify

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.alan.assistant.R
import com.alan.assistant.alarm.ActionReceiver
import com.alan.assistant.core.Ids
import com.alan.assistant.core.ReminderKind
import com.alan.assistant.data.NotificationEntity
import com.alan.assistant.data.NotificationDao
import kotlin.math.absoluteValue

/**
 * Notificações do ALAN ASSISTANT (item 17 do escopo).
 *
 * Dois canais:
 *  - "lembretes": importância ALTA, com som e vibração — é o que acorda o Alan
 *    para uma tarefa. Vem com os botões CONCLUIR e ADIAR 30 MIN.
 *  - "resumos": importância padrão, silencioso, para o resumo diário/noturno.
 *
 * Toda notificação entregue também é gravada na tabela `notifications`,
 * o que permite auditar depois se uma notificação foi ou não entregue.
 */
class Notifier(
    private val context: Context,
    private val dao: NotificationDao
) {

    fun criarCanais() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(NotificationManager::class.java) ?: return

        val lembretes = NotificationChannel(
            CANAL_LEMBRETES,
            context.getString(R.string.canal_lembretes),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = context.getString(R.string.canal_lembretes_desc)
            enableVibration(true)
            setShowBadge(true)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }

        val resumos = NotificationChannel(
            CANAL_RESUMOS,
            context.getString(R.string.canal_resumos),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = context.getString(R.string.canal_resumos_desc)
            enableVibration(false)
            setShowBadge(false)
        }

        nm.createNotificationChannel(lembretes)
        nm.createNotificationChannel(resumos)
    }

    fun podeNotificar(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            return NotificationManagerCompat.from(context).areNotificationsEnabled()
        }
        return ContextCompat.checkSelfPermission(
            context, Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Mostra o lembrete. `taskId` != null habilita o botão CONCLUIR.
     */
    fun mostrarLembrete(
        reminderId: String,
        titulo: String,
        corpo: String,
        taskId: String?,
        kind: ReminderKind
    ) {
        val resumo = kind == ReminderKind.DAILY_SUMMARY || kind == ReminderKind.NIGHT_SUMMARY
        val canal = if (resumo) CANAL_RESUMOS else CANAL_LEMBRETES
        val idNotificacao = reminderId.hashCode().absoluteValue

        val abrir = PendingIntent.getActivity(
            context,
            idNotificacao,
            Intent().apply {
                setClassName(context, "com.alan.assistant.ui.MainActivity")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(EXTRA_ABRIR_REMINDER, reminderId)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, canal)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(titulo)
            .setContentText(corpo)
            .setStyle(NotificationCompat.BigTextStyle().bigText(corpo))
            .setPriority(if (resumo) NotificationCompat.PRIORITY_DEFAULT else NotificationCompat.PRIORITY_HIGH)
            .setCategory(if (resumo) NotificationCompat.CATEGORY_STATUS else NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(abrir)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)

        if (!resumo) {
            builder.addAction(
                0,
                "ADIAR 30 MIN",
                acao(ActionReceiver.ACAO_ADIAR, reminderId, idNotificacao, minutos = 30)
            )
            if (taskId != null) {
                builder.addAction(
                    0,
                    "CONCLUIR",
                    acao(ActionReceiver.ACAO_CONCLUIR, reminderId, idNotificacao)
                )
            }
        }

        var entregue = false
        try {
            if (podeNotificar()) {
                NotificationManagerCompat.from(context).notify(idNotificacao, builder.build())
                entregue = true
            } else {
                Log.w(TAG, "Sem permissão de notificação — lembrete $reminderId não exibido")
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "Falha ao notificar: ${e.message}", e)
        }

        registrar(reminderId, titulo, corpo, entregue)
    }

    /** Aviso simples, sem lembrete associado (erros, avisos do próprio app). */
    fun mostrarAviso(titulo: String, corpo: String) {
        if (!podeNotificar()) return
        val id = (titulo + corpo).hashCode().absoluteValue
        val n = NotificationCompat.Builder(context, CANAL_RESUMOS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(titulo)
            .setContentText(corpo)
            .setStyle(NotificationCompat.BigTextStyle().bigText(corpo))
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(id, n)
        } catch (e: SecurityException) {
            Log.e(TAG, "Falha ao avisar: ${e.message}", e)
        }
        registrar(null, titulo, corpo, true)
    }

    fun cancelar(reminderId: String) {
        NotificationManagerCompat.from(context).cancel(reminderId.hashCode().absoluteValue)
    }

    private fun acao(
        acao: String,
        reminderId: String,
        idNotificacao: Int,
        minutos: Int = 0
    ): PendingIntent {
        val intent = Intent(context, ActionReceiver::class.java).apply {
            action = acao
            putExtra(ActionReceiver.EXTRA_REMINDER_ID, reminderId)
            putExtra(ActionReceiver.EXTRA_NOTIF_ID, idNotificacao)
            putExtra(ActionReceiver.EXTRA_MINUTOS, minutos)
        }
        // requestCode distinto por ação para os PendingIntents não se sobrescreverem.
        val request = (reminderId + acao).hashCode().absoluteValue
        return PendingIntent.getBroadcast(
            context,
            request,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun registrar(reminderId: String?, titulo: String, corpo: String, entregue: Boolean) {
        try {
            dao.insert(
                NotificationEntity(
                    id = Ids.novo(),
                    at = System.currentTimeMillis(),
                    reminderId = reminderId,
                    title = titulo,
                    body = corpo,
                    delivered = entregue
                )
            )
        } catch (e: Throwable) {
            Log.e(TAG, "Falha ao registrar notificação: ${e.message}", e)
        }
    }

    companion object {
        private const val TAG = "AlanNotifier"
        const val CANAL_LEMBRETES = "lembretes"
        const val CANAL_RESUMOS = "resumos"
        const val EXTRA_ABRIR_REMINDER = "abrir_reminder"
    }
}
