package com.alan.assistant.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.alan.assistant.core.MemoryItem
import com.alan.assistant.core.Reminder
import com.alan.assistant.core.RoutineItem
import com.alan.assistant.core.Task
import com.alan.assistant.core.TaskStatus
import com.alan.assistant.data.AuditEntity
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Listas (item 12 do escopo).
 *
 * Cada tela mostra o mesmo dado que o assistente usa — nada aqui é
 * calculado por fora do motor. As telas vazias dizem o que fazer em vez
 * de só informar que não há nada.
 */

// ======================================================================
// Tarefas
// ======================================================================

@Composable
fun TarefasScreen(vm: AssistantViewModel) {
    val tarefas by vm.tarefas.collectAsState()
    val abertas = tarefas.filter { it.status.aberta }
    val fechadas = tarefas.filterNot { it.status.aberta }

    if (tarefas.isEmpty()) {
        TelaVazia(
            "Nenhuma tarefa por aqui.",
            "Diga \"anota que preciso enviar o relatório até sexta\" na tela inicial."
        )
        return
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 12.dp)
    ) {
        if (abertas.isNotEmpty()) {
            item { Cabecalho("Em aberto (${abertas.size})") }
            items(abertas, key = { it.id }) { t -> CartaoTarefa(t, vm) }
        }
        if (fechadas.isNotEmpty()) {
            item { Spacer(Modifier.height(8.dp)); Cabecalho("Encerradas (${fechadas.size})") }
            items(fechadas, key = { it.id }) { t -> CartaoTarefa(t, vm) }
        }
    }
}

@Composable
private fun CartaoTarefa(t: Task, vm: AssistantViewModel) {
    val concluida = t.status == TaskStatus.CONCLUIDA
    val atrasada = t.status == TaskStatus.ATRASADA

    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (atrasada) MaterialTheme.colorScheme.errorContainer
            else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            Modifier.padding(start = 6.dp, end = 12.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = concluida,
                onCheckedChange = { marcado -> if (marcado) vm.concluir(t) else vm.reabrir(t) }
            )
            Column(Modifier.weight(1f).padding(vertical = 6.dp)) {
                Text(
                    t.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    textDecoration = if (concluida) TextDecoration.LineThrough else null
                )
                val detalhes = buildList {
                    t.dueAt?.let { add(formatar(it, t.hasTime, vm.zone)) }
                    if (atrasada) add("atrasada")
                    if (t.recurrence.isRecurring) add(t.recurrence.describe())
                    if (t.priority != com.alan.assistant.core.Priority.NORMAL) add(t.priority.label)
                }
                if (detalhes.isNotEmpty()) {
                    Text(
                        detalhes.joinToString(" • "),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            TextButton(onClick = { vm.apagar(t) }) { Text("Excluir") }
        }
    }
}

// ======================================================================
// Lembretes
// ======================================================================

@Composable
fun LembretesScreen(vm: AssistantViewModel) {
    val lembretes by vm.lembretes.collectAsState()

    if (lembretes.isEmpty()) {
        TelaVazia(
            "Nenhum lembrete ativo.",
            "Diga \"me lembra amanhã às 10h de ligar para o fornecedor\"."
        )
        return
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 12.dp)
    ) {
        items(lembretes, key = { it.id }) { r -> CartaoLembrete(r, vm) }
    }
}

@Composable
private fun CartaoLembrete(r: Reminder, vm: AssistantViewModel) {
    val automatico = r.kind == com.alan.assistant.core.ReminderKind.DAILY_SUMMARY ||
        r.kind == com.alan.assistant.core.ReminderKind.NIGHT_SUMMARY

    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(r.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                val detalhes = buildList {
                    add(formatar(r.triggerAt, true, vm.zone))
                    if (r.recurrence.isRecurring) add(r.recurrence.describe())
                    if (r.snoozeCount > 0) add("adiado ${r.snoozeCount}x")
                }
                Text(
                    detalhes.joinToString(" • "),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (!automatico) {
                TextButton(onClick = { vm.apagar(r) }) { Text("Excluir") }
            } else {
                Text(
                    "automático",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// ======================================================================
// Rotinas
// ======================================================================

@Composable
fun RotinasScreen(vm: AssistantViewModel) {
    val rotinas by vm.rotinas.collectAsState()

    if (rotinas.isEmpty()) {
        TelaVazia(
            "Nenhuma rotina cadastrada.",
            "Diga \"toda segunda às 9h tenho reunião de equipe\"."
        )
        return
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 12.dp)
    ) {
        items(rotinas, key = { it.id }) { r -> CartaoRotina(r, vm) }
    }
}

@Composable
private fun CartaoRotina(r: RoutineItem, vm: AssistantViewModel) {
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(start = 14.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(r.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                Text(
                    "%s às %02d:%02d".format(
                        r.recurrence.describe(),
                        r.timeOfDayMinutes / 60,
                        r.timeOfDayMinutes % 60
                    ),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(checked = r.active, onCheckedChange = { vm.alternarRotina(r) })
            TextButton(onClick = { vm.apagar(r) }) { Text("Excluir") }
        }
    }
}

// ======================================================================
// Memória
// ======================================================================

@Composable
fun MemoriaScreen(vm: AssistantViewModel) {
    val itens by vm.memorias.collectAsState()

    if (itens.isEmpty()) {
        TelaVazia(
            "A memória está vazia.",
            "Diga \"lembra que a senha do sistema vence todo dia 10\" e eu guardo para sempre."
        )
        return
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 12.dp)
    ) {
        items(itens, key = { it.id }) { m -> CartaoMemoria(m, vm) }
    }
}

@Composable
private fun CartaoMemoria(m: MemoryItem, vm: AssistantViewModel) {
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(start = 14.dp, end = 6.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(m.content, style = MaterialTheme.typography.bodyLarge)
                Text(
                    formatar(m.createdAt, true, vm.zone),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            TextButton(onClick = { vm.apagar(m) }) { Text("Esquecer") }
        }
    }
}

// ======================================================================
// Histórico (auditoria)
// ======================================================================

@Composable
fun HistoricoScreen(vm: AssistantViewModel) {
    val itens by vm.historico.collectAsState()

    if (itens.isEmpty()) {
        TelaVazia("Ainda não há histórico.", "Tudo o que eu criar, concluir ou apagar aparece aqui.")
        return
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 12.dp)
    ) {
        items(itens, key = { it.id }) { a -> LinhaHistorico(a, vm) }
    }
}

@Composable
private fun LinhaHistorico(a: AuditEntity, vm: AssistantViewModel) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(
            descreverAcao(a.action),
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Medium
        )
        a.detail?.takeIf { it.isNotBlank() }?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium)
        }
        Text(
            formatar(a.at, true, vm.zone),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun descreverAcao(acao: String): String = when (acao) {
    "TASK_CREATE" -> "Tarefa criada"
    "TASK_COMPLETE" -> "Tarefa concluída"
    "TASK_REOPEN" -> "Tarefa reaberta"
    "TASK_DELETE" -> "Tarefa excluída"
    "TASK_POSTPONE" -> "Tarefa adiada"
    "REMINDER_CREATE" -> "Lembrete criado"
    "REMINDER_FIRE" -> "Lembrete disparado"
    "REMINDER_SNOOZE" -> "Lembrete adiado"
    "REMINDER_DELETE" -> "Lembrete excluído"
    "MEMORY_SAVE" -> "Memória guardada"
    "MEMORY_DELETE" -> "Memória apagada"
    "EVENT_CREATE" -> "Compromisso criado"
    "ROUTINE_CREATE" -> "Rotina criada"
    "ROUTINE_ENABLE" -> "Rotina ativada"
    "ROUTINE_DISABLE" -> "Rotina desativada"
    "ROUTINE_DELETE" -> "Rotina excluída"
    "APP_FIRST_RUN" -> "Primeira execução"
    else -> acao.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }
}

// ======================================================================
// Comuns
// ======================================================================

@Composable
internal fun Cabecalho(texto: String) {
    Text(
        texto,
        Modifier.padding(vertical = 6.dp),
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
internal fun TelaVazia(titulo: String, convite: String) {
    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(titulo, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Text(
                convite,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

internal fun formatar(ms: Long, comHora: Boolean, zone: ZoneId): String {
    val t = LocalDateTime.ofInstant(Instant.ofEpochMilli(ms), zone)
    val hoje = LocalDateTime.now(zone).toLocalDate()
    val dia = t.toLocalDate()
    val prefixo = when (dia) {
        hoje -> "hoje"
        hoje.plusDays(1) -> "amanhã"
        hoje.minusDays(1) -> "ontem"
        else -> "%02d/%02d".format(dia.dayOfMonth, dia.monthValue)
    }
    return if (comHora) "$prefixo às %02d:%02d".format(t.hour, t.minute) else prefixo
}
