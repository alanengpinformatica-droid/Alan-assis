package com.alan.assistant.data

import android.content.Context
import android.util.Log
import com.alan.assistant.core.AuditPort
import com.alan.assistant.core.ConversationPort
import com.alan.assistant.core.EventItem
import com.alan.assistant.core.EventStore
import com.alan.assistant.core.Ids
import com.alan.assistant.core.IntentType
import com.alan.assistant.core.MemoryItem
import com.alan.assistant.core.MemoryStore
import com.alan.assistant.core.ParsedIntent
import com.alan.assistant.core.PendingRequest
import com.alan.assistant.core.PendingStore
import com.alan.assistant.core.Priority
import com.alan.assistant.core.QueryScope
import com.alan.assistant.core.Recurrence
import com.alan.assistant.core.Reminder
import com.alan.assistant.core.ReminderKind
import com.alan.assistant.core.ReminderStore
import com.alan.assistant.core.RoutineItem
import com.alan.assistant.core.RoutineStore
import com.alan.assistant.core.Slot
import com.alan.assistant.core.Task
import com.alan.assistant.core.TaskStore
import com.alan.assistant.core.USUARIO_PRINCIPAL
import org.json.JSONArray
import org.json.JSONObject

/**
 * Implementações reais das portas do core usando Room.
 *
 * Os métodos são bloqueantes de propósito (ver comentário em Daos.kt).
 * Todas as leituras/escritas ficam envolvidas em try/catch: se o banco
 * estiver indisponível (item 19), o app degrada em vez de fechar.
 */

private const val TAG = "AlanStore"

private inline fun <T> seguro(padrao: T, bloco: () -> T): T =
    try {
        bloco()
    } catch (e: Throwable) {
        Log.e(TAG, "Falha de banco: ${e.message}", e)
        padrao
    }

class RoomTaskStore(private val dao: TaskDao) : TaskStore {
    override fun insert(task: Task) = seguro(Unit) { dao.insert(task.toEntity()) }
    override fun update(task: Task) = seguro(Unit) { dao.update(task.toEntity()) }
    override fun delete(id: String) = seguro(Unit) { dao.delete(id) }
    override fun byId(id: String): Task? = seguro(null) { dao.byId(id)?.toDomain() }
    override fun abertas(): List<Task> = seguro(emptyList()) { dao.abertas().map { it.toDomain() } }
    override fun todas(): List<Task> = seguro(emptyList()) { dao.todas().map { it.toDomain() } }
    override fun comPrazoEntre(inicioMillis: Long, fimMillis: Long): List<Task> =
        seguro(emptyList()) { dao.comPrazoEntre(inicioMillis, fimMillis).map { it.toDomain() } }
    override fun concluidasEntre(inicioMillis: Long, fimMillis: Long): List<Task> =
        seguro(emptyList()) { dao.concluidasEntre(inicioMillis, fimMillis).map { it.toDomain() } }
}

class RoomReminderStore(private val dao: ReminderDao) : ReminderStore {
    override fun insert(reminder: Reminder) = seguro(Unit) { dao.insert(reminder.toEntity()) }
    override fun update(reminder: Reminder) = seguro(Unit) { dao.update(reminder.toEntity()) }
    override fun delete(id: String) = seguro(Unit) { dao.delete(id) }
    override fun byId(id: String): Reminder? = seguro(null) { dao.byId(id)?.toDomain() }
    override fun ativos(): List<Reminder> = seguro(emptyList()) { dao.ativos().map { it.toDomain() } }
    override fun ativosEntre(inicioMillis: Long, fimMillis: Long): List<Reminder> =
        seguro(emptyList()) { dao.ativosEntre(inicioMillis, fimMillis).map { it.toDomain() } }
    override fun porTarefa(taskId: String): List<Reminder> =
        seguro(emptyList()) { dao.porTarefa(taskId).map { it.toDomain() } }
    override fun porTipo(kind: ReminderKind): List<Reminder> =
        seguro(emptyList()) { dao.porTipo(kind.name).map { it.toDomain() } }
}

class RoomMemoryStore(private val dao: MemoryDao) : MemoryStore {
    override fun insert(item: MemoryItem) = seguro(Unit) { dao.insert(item.toEntity()) }
    override fun update(item: MemoryItem) = seguro(Unit) { dao.update(item.toEntity()) }
    override fun delete(id: String) = seguro(Unit) { dao.delete(id) }
    override fun todas(): List<MemoryItem> = seguro(emptyList()) { dao.todas().map { it.toDomain() } }
    override fun buscar(termo: String): List<MemoryItem> =
        seguro(emptyList()) { dao.buscar(termo).map { it.toDomain() } }
}

class RoomEventStore(private val dao: EventDao) : EventStore {
    override fun insert(item: EventItem) = seguro(Unit) { dao.insert(item.toEntity()) }
    override fun delete(id: String) = seguro(Unit) { dao.delete(id) }
    override fun entre(inicioMillis: Long, fimMillis: Long): List<EventItem> =
        seguro(emptyList()) { dao.entre(inicioMillis, fimMillis).map { it.toDomain() } }
}

class RoomRoutineStore(private val dao: RoutineDao) : RoutineStore {
    override fun insert(item: RoutineItem) = seguro(Unit) { dao.insert(item.toEntity()) }
    override fun update(item: RoutineItem) = seguro(Unit) { dao.update(item.toEntity()) }
    override fun delete(id: String) = seguro(Unit) { dao.delete(id) }
    override fun ativas(): List<RoutineItem> = seguro(emptyList()) { dao.ativas().map { it.toDomain() } }
}

/** Histórico de ações (item 27 do escopo). */
class RoomAudit(private val dao: AuditDao) : AuditPort {
    override fun registrar(action: String, entityType: String, entityId: String?, detail: String?) =
        seguro(Unit) {
            dao.insert(
                AuditEntity(
                    id = Ids.novo(),
                    at = System.currentTimeMillis(),
                    actor = USUARIO_PRINCIPAL,
                    action = action,
                    entityType = entityType,
                    entityId = entityId,
                    detail = detail
                )
            )
        }
}

class RoomConversations(private val dao: ConversationDao) : ConversationPort {
    override fun registrar(role: String, text: String, intent: String?, viaVoice: Boolean) =
        seguro(Unit) {
            dao.insert(
                ConversationEntity(
                    id = Ids.novo(),
                    at = System.currentTimeMillis(),
                    role = role,
                    text = text,
                    intent = intent,
                    viaVoice = viaVoice
                )
            )
        }
}

/**
 * Estado de desambiguação persistido em SharedPreferences.
 *
 * Fica fora do Room porque é um único objeto volátil ("estou esperando o
 * Alan responder 'qual delas?'") e precisa ser lido/gravado de forma
 * síncrona e barata, inclusive a partir de um BroadcastReceiver.
 */
class PrefsPendingStore(context: Context) : PendingStore {

    private val prefs = context.applicationContext
        .getSharedPreferences("alan_prefs", Context.MODE_PRIVATE)

    override fun salvar(pending: PendingRequest?) {
        try {
            if (pending == null) {
                prefs.edit().remove(CHAVE).apply()
            } else {
                prefs.edit().putString(CHAVE, serializar(pending)).apply()
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Falha ao salvar pendência: ${e.message}", e)
        }
    }

    override fun carregar(): PendingRequest? = try {
        prefs.getString(CHAVE, null)?.let { desserializar(it) }
    } catch (e: Throwable) {
        Log.e(TAG, "Falha ao ler pendência: ${e.message}", e)
        prefs.edit().remove(CHAVE).apply() // dado corrompido não trava o app
        null
    }

    private fun serializar(p: PendingRequest): String {
        val i = p.partial
        val intent = JSONObject()
            .put("type", i.type.name)
            .put("title", i.title ?: JSONObject.NULL)
            .put("whenAt", i.whenAt ?: JSONObject.NULL)
            .put("hasTime", i.hasTime)
            .put("recurrence", i.recurrence.encode())
            .put("priority", i.priority?.name ?: JSONObject.NULL)
            .put("category", i.category ?: JSONObject.NULL)
            .put("targetRef", i.targetRef ?: JSONObject.NULL)
            .put("targetId", i.targetId ?: JSONObject.NULL)
            .put("offsetMinutes", i.offsetMinutes ?: JSONObject.NULL)
            .put("content", i.content ?: JSONObject.NULL)
            .put("scope", i.scope.name)
            .put("confidence", i.confidence)
            .put("rawText", i.rawText)
            .put("source", i.source)

        val opcoes = JSONArray().apply { p.options.forEach { put(it) } }

        return JSONObject()
            .put("question", p.question)
            .put("missingSlot", p.missingSlot.name)
            .put("options", opcoes)
            .put("executarSeNegativa", p.executarSeNegativa)
            .put("partial", intent)
            .toString()
    }

    private fun desserializar(s: String): PendingRequest {
        val o = JSONObject(s)
        val i = o.getJSONObject("partial")
        val parsed = ParsedIntent(
            type = runCatching { IntentType.valueOf(i.getString("type")) }.getOrDefault(IntentType.UNKNOWN),
            title = i.optStringOrNull("title"),
            whenAt = if (i.isNull("whenAt")) null else i.getLong("whenAt"),
            hasTime = i.optBoolean("hasTime", false),
            recurrence = Recurrence.decode(i.optStringOrNull("recurrence")),
            priority = i.optStringOrNull("priority")?.let { Priority.from(it) },
            category = i.optStringOrNull("category"),
            targetRef = i.optStringOrNull("targetRef"),
            targetId = i.optStringOrNull("targetId"),
            offsetMinutes = if (i.isNull("offsetMinutes")) null else i.getInt("offsetMinutes"),
            content = i.optStringOrNull("content"),
            scope = runCatching { QueryScope.valueOf(i.optString("scope")) }.getOrDefault(QueryScope.HOJE),
            confidence = i.optDouble("confidence", 0.0),
            rawText = i.optString("rawText", ""),
            source = i.optString("source", "regras")
        )
        val opcoesJson = o.optJSONArray("options") ?: JSONArray()
        val opcoes = (0 until opcoesJson.length()).map { opcoesJson.getString(it) }

        return PendingRequest(
            question = o.getString("question"),
            missingSlot = runCatching { Slot.valueOf(o.getString("missingSlot")) }
                .getOrDefault(Slot.TITULO),
            partial = parsed,
            options = opcoes,
            executarSeNegativa = o.optBoolean("executarSeNegativa", false)
        )
    }

    private fun JSONObject.optStringOrNull(key: String): String? =
        if (isNull(key)) null else optString(key).ifBlank { null }

    companion object {
        private const val CHAVE = "pendencia_atual"
    }
}

/** Preferências simples do app (fala ligada, horários dos resumos, etc.). */
class Settings(private val dao: SettingDao) {

    fun getString(key: String, padrao: String?): String? =
        seguro(padrao) { dao.get(key) ?: padrao }

    fun setString(key: String, value: String) =
        seguro(Unit) { dao.set(SettingEntity(key, value)) }

    fun getBool(key: String, padrao: Boolean): Boolean =
        getString(key, null)?.toBooleanStrictOrNull() ?: padrao

    fun setBool(key: String, value: Boolean) = setString(key, value.toString())

    /** Hora (0..23) ou null quando o resumo está desligado. */
    fun getHora(key: String, padrao: Int?): Int? {
        val v = getString(key, null) ?: return padrao
        if (v == DESLIGADO) return null
        return v.toIntOrNull() ?: padrao
    }

    fun setHora(key: String, hora: Int?) = setString(key, hora?.toString() ?: DESLIGADO)

    companion object {
        const val FALA_ATIVA = "fala_ativa"
        const val RESUMO_MANHA = "resumo_manha"
        const val RESUMO_NOITE = "resumo_noite"
        const val BLOQUEIO_ATIVO = "bloqueio_ativo"
        const val IA_ATIVA = "ia_ativa"
        const val MODELO_IA = "modelo_ia"
        const val PRIMEIRA_EXECUCAO = "primeira_execucao_feita"
        const val DESLIGADO = "off"
    }
}
