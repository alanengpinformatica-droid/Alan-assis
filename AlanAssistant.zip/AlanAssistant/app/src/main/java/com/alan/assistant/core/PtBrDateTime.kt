package com.alan.assistant.core

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

/**
 * Interpretador de datas, horários e recorrências em português do Brasil.
 *
 * Funciona 100% OFFLINE e é determinístico — é a primeira linha de
 * interpretação do assistente. A IA (opcional, item 15) só é acionada quando
 * esta camada não consegue resolver.
 *
 * Trabalha sobre uma cópia "normalizada" do texto (minúsculas, sem acentos)
 * que preserva o COMPRIMENTO original, de modo que os índices casados aqui
 * continuam válidos no texto original — é assim que conseguimos remover as
 * expressões de tempo e sobrar apenas o título da tarefa/lembrete.
 */
object PtBrDateTime {

    /** Horário padrão quando o Alan informa só a data. */
    val HORA_PADRAO: LocalTime = LocalTime.of(9, 0)
    val HORA_MANHA: LocalTime = LocalTime.of(8, 0)
    val HORA_TARDE: LocalTime = LocalTime.of(14, 0)
    val HORA_NOITE: LocalTime = LocalTime.of(20, 0)

    data class Result(
        val dateTime: LocalDateTime? = null,
        /** true quando o Alan disse um horário/offset preciso (não inventamos). */
        val hasExplicitTime: Boolean = false,
        val recurrence: Recurrence = Recurrence.NONE,
        /** Trechos do texto consumidos pela interpretação temporal. */
        val consumed: List<IntRange> = emptyList(),
        /** Minutos, quando a frase é puramente um deslocamento ("adia 30 minutos"). */
        val offsetMinutes: Int? = null,
        /** true quando o texto trouxe um DIA (e não apenas um horário). */
        val hasDate: Boolean = false
    ) {
        val hasDateTime: Boolean get() = dateTime != null
    }

    private const val ACENTOS = "áàâãäéèêëíìîïóòôõöúùûüçñÁÀÂÃÄÉÈÊËÍÌÎÏÓÒÔÕÖÚÙÛÜÇÑ"
    private const val PLANOS = "aaaaaeeeeiiiiooooouuuucnaaaaaeeeeiiiiooooouuuucn"

    /** Minúsculas + sem acentos, preservando o comprimento (1 char -> 1 char). */
    fun normalize(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            val i = ACENTOS.indexOf(c)
            val base = if (i >= 0) PLANOS[i] else c
            sb.append(base.lowercaseChar())
        }
        return sb.toString()
    }

    private val NUMEROS = mapOf(
        "um" to 1, "uma" to 1, "dois" to 2, "duas" to 2, "tres" to 3, "quatro" to 4,
        "cinco" to 5, "seis" to 6, "sete" to 7, "oito" to 8, "nove" to 9, "dez" to 10,
        "onze" to 11, "doze" to 12, "quinze" to 15, "vinte" to 20, "trinta" to 30,
        "quarenta" to 40, "cinquenta" to 50, "sessenta" to 60
    )

    private val DIAS_SEMANA = mapOf(
        "segunda" to DayOfWeek.MONDAY,
        "terca" to DayOfWeek.TUESDAY,
        "quarta" to DayOfWeek.WEDNESDAY,
        "quinta" to DayOfWeek.THURSDAY,
        "sexta" to DayOfWeek.FRIDAY,
        "sabado" to DayOfWeek.SATURDAY,
        "domingo" to DayOfWeek.SUNDAY
    )

    private val MESES = mapOf(
        "janeiro" to 1, "fevereiro" to 2, "marco" to 3, "abril" to 4, "maio" to 5,
        "junho" to 6, "julho" to 7, "agosto" to 8, "setembro" to 9, "outubro" to 10,
        "novembro" to 11, "dezembro" to 12
    )

    private enum class FonteData { NENHUMA, RELATIVA, DIA_SEMANA, DIA_MES, DATA_EXPLICITA, PALAVRA, SO_HORA }

    // ------------------------------------------------------------------
    // API principal
    // ------------------------------------------------------------------

    fun parse(texto: String, agora: LocalDateTime): Result {
        val n = normalize(texto)
        val consumed = mutableListOf<IntRange>()

        val rec = matchRecurrence(n, consumed, agora)
        val relativo = matchRelative(n, consumed, agora)

        var data: LocalDate? = null
        var fonte = if (relativo != null) FonteData.RELATIVA else FonteData.NENHUMA
        if (relativo == null) {
            val d = matchData(n, consumed, agora)
            if (d != null) { data = d.first; fonte = d.second }
        }

        val periodo = matchPeriodo(n, consumed)
        var hora = matchHora(n, consumed)
        var horaExplicita = hora != null

        if (hora != null && periodo != null) hora = ajustaPeriodo(hora, periodo)
        if (hora == null && periodo != null) {
            hora = when (periodo) {
                Periodo.MANHA -> HORA_MANHA
                Periodo.TARDE -> HORA_TARDE
                Periodo.NOITE -> HORA_NOITE
            }
            horaExplicita = true // o Alan indicou o turno; confirmamos o horário na resposta
        }

        var resultado: LocalDateTime? = when {
            relativo != null && hora != null && horaExplicita && !relativoEhPreciso(n, consumed) ->
                relativo.toLocalDate().atTime(hora)
            relativo != null -> relativo
            rec.isRecurring -> rec.next(agora, hora ?: HORA_PADRAO)
            data != null && hora != null -> data.atTime(hora)
            data != null -> data.atTime(HORA_PADRAO)
            hora != null -> {
                fonte = FonteData.SO_HORA
                agora.toLocalDate().atTime(hora)
            }
            else -> null
        }

        // Correção anti-passado: nunca agendar para trás por engano.
        if (resultado != null && !resultado.isAfter(agora)) {
            resultado = when (fonte) {
                FonteData.SO_HORA -> resultado.plusDays(1)
                FonteData.DIA_SEMANA -> resultado.plusWeeks(1)
                FonteData.DIA_MES -> resultado.plusMonths(1)
                else -> resultado
            }
        }

        val offset = if (relativo != null && relativoEhPreciso(n, consumed))
            java.time.Duration.between(agora, relativo).toMinutes().toInt() else null

        return Result(
            dateTime = resultado,
            hasExplicitTime = horaExplicita || (relativo != null && relativoEhPreciso(n, consumed)),
            recurrence = rec,
            consumed = consumed.toList(),
            offsetMinutes = offset,
            hasDate = relativo != null || data != null || rec.isRecurring
        )
    }

    /** Usado por "adia 30 minutos" / "adia uma hora" — só o deslocamento. */
    fun parseOffsetMinutes(texto: String): Int? {
        val n = normalize(texto)
        val rx = Regex("""\b(\d{1,4}|${NUMEROS.keys.joinToString("|")})\s*(minutos?|mins?|horas?|hrs?|h|dias?|semanas?)\b""")
        val m = rx.find(n) ?: return null
        val valor = valorNumerico(m.groupValues[1]) ?: return null
        return when {
            m.groupValues[2].startsWith("min") -> valor
            m.groupValues[2].startsWith("h") -> valor * 60
            m.groupValues[2].startsWith("dia") -> valor * 60 * 24
            m.groupValues[2].startsWith("semana") -> valor * 60 * 24 * 7
            else -> null
        }
    }

    // ------------------------------------------------------------------
    // Recorrência
    // ------------------------------------------------------------------

    private fun matchRecurrence(
        n: String,
        consumed: MutableList<IntRange>,
        agora: LocalDateTime
    ): Recurrence {
        // 1) "todo dia 30" (dia fixo do mês) — antes de "todo dia"
        regexFind(n, Regex("""\btodo\s+dia\s+(\d{1,2})\b"""), consumed)?.let { m ->
            consume(consumed, m.range)
            val dia = m.groupValues[1].toInt().coerceIn(1, 31)
            return Recurrence(RecurrenceType.MONTHLY_DAY, dayOfMonth = dia)
        }

        // 2) primeiro dia útil do mês
        regexFind(n, Regex("""\b(primeiro|1o|1)\s*dia\s+util\s+(do|de cada)\s+mes\b"""), consumed)?.let { m ->
            consume(consumed, m.range)
            return Recurrence(RecurrenceType.FIRST_BUSINESS_DAY)
        }

        // 3) "a cada X minutos/horas"
        regexFind(
            n,
            Regex("""\ba\s+cada\s+(\d{1,4}|${NUMEROS.keys.joinToString("|")})\s*(minutos?|mins?|horas?|hrs?|h|dias?|semanas?)\b"""),
            consumed
        )?.let { m ->
            consume(consumed, m.range)
            val v = valorNumerico(m.groupValues[1]) ?: 1
            val u = m.groupValues[2]
            return when {
                u.startsWith("min") -> Recurrence(RecurrenceType.INTERVAL_MINUTES, intervalMinutes = v)
                u.startsWith("h") -> Recurrence(RecurrenceType.INTERVAL_MINUTES, intervalMinutes = v * 60)
                u.startsWith("dia") -> if (v == 1) Recurrence(RecurrenceType.DAILY)
                else Recurrence(RecurrenceType.INTERVAL_MINUTES, intervalMinutes = v * 1440)
                else -> Recurrence(RecurrenceType.WEEKLY, daysOfWeek = setOf(agora.dayOfWeek))
            }
        }

        // 4) "toda sexta", "todas as segundas", "toda segunda-feira"
        val diasRx = DIAS_SEMANA.keys.joinToString("|")
        val achados = linkedSetOf<DayOfWeek>()
        var casouDiaSemana = false
        Regex("""\btod[oa]s?\s+(?:os\s+|as\s+)?($diasRx)s?(?:-?\s?feiras?)?\b""")
            .findAll(n)
            .filter { m -> consumed.none { sobrepoe(it, m.range) } }
            .forEach { m ->
                consume(consumed, m.range)
                DIAS_SEMANA[m.groupValues[1]]?.let { achados.add(it) }
                casouDiaSemana = true
            }
        if (casouDiaSemana && achados.isNotEmpty()) {
            return Recurrence(RecurrenceType.WEEKLY, daysOfWeek = achados)
        }

        // 5) diário
        regexFind(n, Regex("""\b(todo\s+dia|todos\s+os\s+dias|diariamente|diario)\b"""), consumed)?.let { m ->
            consume(consumed, m.range)
            return Recurrence(RecurrenceType.DAILY)
        }

        // 6) semanal genérico
        regexFind(n, Regex("""\b(toda\s+semana|todas\s+as\s+semanas|semanalmente)\b"""), consumed)?.let { m ->
            consume(consumed, m.range)
            return Recurrence(RecurrenceType.WEEKLY, daysOfWeek = setOf(agora.dayOfWeek))
        }

        // 7) mensal / anual
        regexFind(n, Regex("""\b(todo\s+mes|todos\s+os\s+meses|mensalmente)\b"""), consumed)?.let { m ->
            consume(consumed, m.range)
            return Recurrence(RecurrenceType.MONTHLY_DAY, dayOfMonth = agora.dayOfMonth)
        }
        regexFind(n, Regex("""\b(todo\s+ano|anualmente)\b"""), consumed)?.let { m ->
            consume(consumed, m.range)
            return Recurrence(
                RecurrenceType.YEARLY,
                month = agora.monthValue,
                dayOfMonth = agora.dayOfMonth
            )
        }

        return Recurrence.NONE
    }

    // ------------------------------------------------------------------
    // Expressões relativas
    // ------------------------------------------------------------------

    private fun matchRelative(
        n: String,
        consumed: MutableList<IntRange>,
        agora: LocalDateTime
    ): LocalDateTime? {
        regexFind(n, Regex("""\bdaqui\s+a\s+meia\s+hora\b"""), consumed)?.let { m ->
            consume(consumed, m.range)
            return agora.plusMinutes(30)
        }
        val nums = NUMEROS.keys.joinToString("|")
        val rx = Regex(
            """\b(?:daqui\s+a|daqui|dentro\s+de|em|apos|passados?)\s+(\d{1,4}|$nums)\s*(minutos?|mins?|horas?|hrs?|h|dias?|semanas?|meses?|mes)\b"""
        )
        val m = regexFind(n, rx, consumed) ?: return null
        val v = valorNumerico(m.groupValues[1]) ?: return null
        consume(consumed, m.range)
        val u = m.groupValues[2]
        return when {
            u.startsWith("min") -> agora.plusMinutes(v.toLong())
            u.startsWith("h") -> agora.plusHours(v.toLong())
            u.startsWith("dia") -> agora.plusDays(v.toLong())
            u.startsWith("semana") -> agora.plusWeeks(v.toLong())
            u.startsWith("mes") -> agora.plusMonths(v.toLong())
            else -> null
        }
    }

    /** "daqui a 30 minutos" / "daqui a 2 horas" definem um instante exato. */
    private fun relativoEhPreciso(n: String, consumed: List<IntRange>): Boolean {
        val nums = NUMEROS.keys.joinToString("|")
        return Regex("""\b(?:daqui\s+a|daqui|dentro\s+de|em|apos)\s+(?:\d{1,4}|$nums|meia)\s*(minutos?|mins?|horas?|hrs?|h)\b""")
            .containsMatchIn(n)
    }

    // ------------------------------------------------------------------
    // Datas
    // ------------------------------------------------------------------

    private fun matchData(
        n: String,
        consumed: MutableList<IntRange>,
        agora: LocalDateTime
    ): Pair<LocalDate, FonteData>? {
        val hoje = agora.toLocalDate()

        regexFind(n, Regex("""\bdepois\s+de\s+amanha\b"""), consumed)?.let {
            consume(consumed, it.range); return hoje.plusDays(2) to FonteData.PALAVRA
        }
        regexFind(n, Regex("""\bamanha\b"""), consumed)?.let {
            consume(consumed, it.range); return hoje.plusDays(1) to FonteData.PALAVRA
        }
        regexFind(n, Regex("""\bhoje\b"""), consumed)?.let {
            consume(consumed, it.range); return hoje to FonteData.PALAVRA
        }
        regexFind(n, Regex("""\b(proxima\s+semana|semana\s+que\s+vem)\b"""), consumed)?.let {
            consume(consumed, it.range); return hoje.plusWeeks(1) to FonteData.PALAVRA
        }
        regexFind(n, Regex("""\b(proximo\s+mes|mes\s+que\s+vem)\b"""), consumed)?.let {
            consume(consumed, it.range); return hoje.plusMonths(1) to FonteData.PALAVRA
        }

        // dd/mm[/aaaa]
        regexFind(n, Regex("""\b(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?\b"""), consumed)?.let { m ->
            val d = m.groupValues[1].toIntOrNull() ?: return@let
            val mes = m.groupValues[2].toIntOrNull() ?: return@let
            if (d !in 1..31 || mes !in 1..12) return@let
            val anoTxt = m.groupValues[3]
            val ano = when {
                anoTxt.isEmpty() -> hoje.year
                anoTxt.length == 2 -> 2000 + anoTxt.toInt()
                else -> anoTxt.toInt()
            }
            consume(consumed, m.range)
            val base = LocalDate.of(ano, mes, minOf(d, LocalDate.of(ano, mes, 1).lengthOfMonth()))
            val ajust = if (anoTxt.isEmpty() && base.isBefore(hoje)) base.plusYears(1) else base
            return ajust to FonteData.DATA_EXPLICITA
        }

        // "dia 30 de setembro" / "dia 30"
        val mesesRx = MESES.keys.joinToString("|")
        regexFind(n, Regex("""\bdia\s+(\d{1,2})(?:\s+de\s+($mesesRx))?\b"""), consumed)?.let { m ->
            val d = m.groupValues[1].toIntOrNull() ?: return@let
            if (d !in 1..31) return@let
            consume(consumed, m.range)
            val mesNome = m.groupValues[2]
            return if (mesNome.isNotEmpty()) {
                val mes = MESES.getValue(mesNome)
                var base = LocalDate.of(hoje.year, mes, 1)
                base = base.withDayOfMonth(minOf(d, base.lengthOfMonth()))
                if (base.isBefore(hoje)) base = base.plusYears(1)
                base to FonteData.DATA_EXPLICITA
            } else {
                var base = hoje.withDayOfMonth(minOf(d, hoje.lengthOfMonth()))
                if (base.isBefore(hoje)) {
                    val prox = hoje.withDayOfMonth(1).plusMonths(1)
                    base = prox.withDayOfMonth(minOf(d, prox.lengthOfMonth()))
                }
                base to FonteData.DIA_MES
            }
        }

        // dia da semana
        val diasRx = DIAS_SEMANA.keys.joinToString("|")
        regexFind(
            n,
            Regex("""\b(?:na\s+|no\s+|nesta\s+|neste\s+|proxima\s+|proximo\s+|ate\s+|essa\s+|esse\s+)?($diasRx)(?:-?\s?feira)?\b"""),
            consumed
        )?.let { m ->
            val alvo = DIAS_SEMANA[m.groupValues[1]] ?: return@let
            consume(consumed, m.range)
            var d = hoje
            var passos = 0
            while (d.dayOfWeek != alvo && passos < 7) { d = d.plusDays(1); passos++ }
            val proxima = m.value.contains("proxim")
            if (proxima && passos == 0) d = d.plusWeeks(1)
            return d to FonteData.DIA_SEMANA
        }

        return null
    }

    // ------------------------------------------------------------------
    // Horários
    // ------------------------------------------------------------------

    private enum class Periodo { MANHA, TARDE, NOITE }

    private fun matchPeriodo(n: String, consumed: MutableList<IntRange>): Periodo? {
        regexFind(n, Regex("""\b(?:de|da|pela|a|ao|as)\s+(manha|tarde|noite)\b"""), consumed)?.let { m ->
            consume(consumed, m.range)
            return when (m.groupValues[1]) {
                "manha" -> Periodo.MANHA
                "tarde" -> Periodo.TARDE
                else -> Periodo.NOITE
            }
        }
        return null
    }

    private fun ajustaPeriodo(h: LocalTime, p: Periodo): LocalTime = when {
        p == Periodo.TARDE && h.hour in 1..11 -> h.plusHours(12)
        p == Periodo.NOITE && h.hour in 1..11 -> h.plusHours(12)
        p == Periodo.MANHA && h.hour == 12 -> h.minusHours(12)
        else -> h
    }

    private fun matchHora(n: String, consumed: MutableList<IntRange>): LocalTime? {
        regexFind(n, Regex("""\bmeio[\s-]?dia\b"""), consumed)?.let {
            consume(consumed, it.range); return LocalTime.of(12, 0)
        }
        regexFind(n, Regex("""\bmeia[\s-]?noite\b"""), consumed)?.let {
            consume(consumed, it.range); return LocalTime.of(0, 0)
        }
        // "às 14:30", "as 14h30", "14:30"
        regexFind(n, Regex("""\b(?:as|ate\s+as|para\s+as|para\s+o)?\s*(\d{1,2})\s*[:h]\s*(\d{2})\b"""), consumed)?.let { m ->
            val h = m.groupValues[1].toIntOrNull() ?: return@let
            val mi = m.groupValues[2].toIntOrNull() ?: return@let
            if (h !in 0..23 || mi !in 0..59) return@let
            consume(consumed, m.range)
            return LocalTime.of(h, mi)
        }
        // "às 16h", "às 7 horas", "às 10"
        regexFind(n, Regex("""\b(?:as|ate\s+as|para\s+as)\s*(\d{1,2})\s*(?:h|horas|hrs)?\b"""), consumed)?.let { m ->
            val h = m.groupValues[1].toIntOrNull() ?: return@let
            if (h !in 0..23) return@let
            consume(consumed, m.range)
            return LocalTime.of(h, 0)
        }
        // "16h"
        regexFind(n, Regex("""\b(\d{1,2})\s*(?:h|horas)\b"""), consumed)?.let { m ->
            val h = m.groupValues[1].toIntOrNull() ?: return@let
            if (h !in 0..23) return@let
            consume(consumed, m.range)
            return LocalTime.of(h, 0)
        }
        return null
    }

    // ------------------------------------------------------------------
    // Formatação amigável (usada nas confirmações e nas notificações)
    // ------------------------------------------------------------------

    fun formatFriendly(dt: LocalDateTime, agora: LocalDateTime, comHora: Boolean = true): String {
        val hoje = agora.toLocalDate()
        val dias = java.time.temporal.ChronoUnit.DAYS.between(hoje, dt.toLocalDate())
        val hora = String.format("%02d:%02d", dt.hour, dt.minute)
        val dataTxt = when {
            dias == 0L -> "hoje"
            dias == 1L -> "amanhã"
            dias == 2L -> "depois de amanhã"
            dias in 3..6 -> Recurrence.nomeDiaSemana(dt.dayOfWeek) +
                " (" + String.format("%02d/%02d", dt.dayOfMonth, dt.monthValue) + ")"
            else -> String.format("%02d/%02d/%04d", dt.dayOfMonth, dt.monthValue, dt.year)
        }
        return if (comHora) "$dataTxt às $hora" else dataTxt
    }

    // ------------------------------------------------------------------
    // Utilitários
    // ------------------------------------------------------------------

    private fun valorNumerico(token: String): Int? =
        token.toIntOrNull() ?: NUMEROS[token]

    private fun sobrepoe(a: IntRange, b: IntRange): Boolean =
        a.first <= b.last && b.first <= a.last

    private fun regexFind(n: String, rx: Regex, consumed: List<IntRange>): MatchResult? =
        rx.findAll(n).firstOrNull { m -> consumed.none { sobrepoe(it, m.range) } }

    private fun consume(consumed: MutableList<IntRange>, r: IntRange) {
        consumed.add(r)
    }

    /** Remove do texto original os trechos consumidos pela interpretação temporal. */
    fun removeConsumed(original: String, consumed: List<IntRange>): String {
        if (consumed.isEmpty()) return original
        val sb = StringBuilder()
        val ordenados = consumed.sortedBy { it.first }
        var pos = 0
        for (r in ordenados) {
            val ini = r.first.coerceIn(0, original.length)
            val fim = (r.last + 1).coerceIn(0, original.length)
            if (ini > pos) sb.append(original, pos, ini)
            if (fim > pos) pos = fim
        }
        if (pos < original.length) sb.append(original, pos, original.length)
        return sb.toString()
    }
}
