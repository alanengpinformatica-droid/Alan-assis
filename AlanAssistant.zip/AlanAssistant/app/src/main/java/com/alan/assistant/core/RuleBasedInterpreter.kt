package com.alan.assistant.core

import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Interpretador por regras — offline, determinístico, sem custo e sem rede.
 *
 * É SEMPRE a primeira tentativa. A IA só entra quando a confiança fica baixa
 * (ver CompositeInterpreter). Isso garante que os comandos do dia a dia
 * funcionem mesmo sem internet — requisito de confiabilidade do item 37.
 */
class RuleBasedInterpreter(private val zone: ZoneId) : Interpreter {

    override fun interpret(texto: String, ctx: InterpreterContext): ParsedIntent {
        val original = texto.trim()
        if (original.isEmpty()) {
            return ParsedIntent(IntentType.UNKNOWN, rawText = texto, confidence = 0.0)
        }

        val n = PtBrDateTime.normalize(original)
        val agora = LocalDateTime.ofInstant(Instant.ofEpochMilli(ctx.nowMillis), zone)
        val tempo = PtBrDateTime.parse(original, agora)
        val whenAt = tempo.dateTime?.atZone(zone)?.toInstant()?.toEpochMilli()

        // Marcadores calculados cedo: impedem que "me lembra de concluir o
        // relatório" seja lido como "concluir tarefa" e que
        // "me lembra de revisar minhas tarefas" vire uma consulta.
        val pedeLembrete = has(n, """\bme\s+lembr(a|e|ar)\b""") ||
            has(n, """\b(nao me deixa esquecer|nao me deixe esquecer|nao posso esquecer|nao deixa eu esquecer|nao esquece[r]? de|me avisa|me avise|me alerta|cria um lembrete|criar lembrete|novo lembrete|poe um lembrete|coloca um lembrete)\b""")
        val temMarcadorTarefa = has(n, MARCADORES_TAREFA)
        val criandoAlgo = pedeLembrete || temMarcadorTarefa

        // ---------- 1. Consultas e resumos ----------
        if (!criandoAlgo) consultaOuResumo(n, original, tempo, whenAt)?.let { return it }

        // ---------- 2. Ações sobre itens existentes ----------
        if (!criandoAlgo && has(n, """\b(conclu(a|i|ir|ida|ido|o)|terminei|finalizei|ja fiz|fiz a|marca como (feita|concluida|pronta)|pode marcar como feita|esta pronta|ta pronto|feito)\b""")) {
            return ParsedIntent(
                type = IntentType.COMPLETE_TASK,
                targetRef = alvo(original, tempo, ALVO_CONCLUIR),
                rawText = original,
                confidence = 0.85
            )
        }

        if (!criandoAlgo && has(n, """\b(adia|adie|adiar|joga para|jogue para|empurra|empurre|remarca|remarque|deixa para|deixe para|passa para|transfere)\b""")) {
            val offset = PtBrDateTime.parseOffsetMinutes(original)
            val ehLembrete = has(n, """\blembrete\b""")
            return ParsedIntent(
                type = if (ehLembrete) IntentType.POSTPONE_REMINDER else IntentType.POSTPONE_TASK,
                targetRef = alvo(original, tempo, ALVO_ADIAR),
                whenAt = whenAt,
                hasTime = tempo.hasExplicitTime,
                offsetMinutes = tempo.offsetMinutes ?: offset,
                rawText = original,
                confidence = 0.8
            )
        }

        if (!criandoAlgo && has(n, """\b(apaga|apague|exclui|exclua|remove|remova|deleta|delete|cancela|cancele)\b""")) {
            val tipo = when {
                has(n, """\blembrete""") -> IntentType.DELETE_REMINDER
                has(n, """\b(memoria|anotacao)""") -> IntentType.DELETE_MEMORY
                else -> IntentType.DELETE_TASK
            }
            return ParsedIntent(
                type = tipo,
                targetRef = alvo(original, tempo, ALVO_APAGAR),
                rawText = original,
                confidence = 0.8
            )
        }

        // ---------- 3. Memória permanente ----------
        // "Lembre que meu nome é Alan" / "Guarde que toda sexta faço o fechamento"
        // Diferente de "me lembra..." (que é lembrete com hora).
        val ehMemoria = has(n, """^\s*(alan[\s,]+)?(lembre|lembra|guarde|guarda|memorize|memoriza|registre|registra|anote|anota|salve|salva)\s+(que|o seguinte|isto|isso)\b""") &&
            !has(n, """\bme\s+lembr""")
        if (ehMemoria && !temMarcadorTarefa) {
            val conteudo = conteudoMemoria(original)
            return ParsedIntent(
                type = IntentType.SAVE_MEMORY,
                content = conteudo,
                title = conteudo,
                rawText = original,
                confidence = if (conteudo.isNullOrBlank()) 0.4 else 0.9
            )
        }

        // ---------- 4. Lembretes ----------
        if (pedeLembrete) {
            val titulo = limparTitulo(original, tempo.consumed)
            val tipo = if (tempo.recurrence.isRecurring)
                IntentType.CREATE_RECURRING_REMINDER else IntentType.CREATE_REMINDER
            val conf = when {
                titulo.isNullOrBlank() -> 0.45
                whenAt == null && !tempo.recurrence.isRecurring -> 0.6
                else -> 0.95
            }
            return ParsedIntent(
                type = tipo,
                title = titulo,
                whenAt = whenAt,
                hasTime = tempo.hasExplicitTime,
                recurrence = tempo.recurrence,
                priority = prioridade(n),
                rawText = original,
                confidence = conf
            )
        }

        // ---------- 5. Rotinas ----------
        // "Toda sexta-feira eu faço o fechamento semanal"
        if (tempo.recurrence.isRecurring &&
            has(n, """\b(eu\s+)?(faco|costumo|tenho o habito|sempre faco|realizo)\b""")
        ) {
            return ParsedIntent(
                type = IntentType.CREATE_ROUTINE,
                title = limparTitulo(original, tempo.consumed),
                whenAt = whenAt,
                hasTime = tempo.hasExplicitTime,
                recurrence = tempo.recurrence,
                rawText = original,
                confidence = 0.85
            )
        }

        // ---------- 6. Compromissos ----------
        if (has(n, """\b(reuniao|compromisso|encontro|consulta|entrevista|conversar com|falar com|call com|almoco com|jantar com|visita|apresentacao para)\b""") &&
            tempo.dateTime != null
        ) {
            return ParsedIntent(
                type = IntentType.CREATE_EVENT,
                title = limparTitulo(original, tempo.consumed),
                whenAt = whenAt,
                hasTime = tempo.hasExplicitTime,
                rawText = original,
                confidence = 0.85
            )
        }

        // ---------- 7. Tarefas ----------
        val pedeTarefa = temMarcadorTarefa ||
            has(n, """\b(anota|anote|registra|registre|guarda|guarde)\b""") ||
            has(n, """\b(cria|criar|crie|adiciona|adicione|nova)\s+(uma\s+)?tarefa\b""") ||
            has(n, """\b(coloca|poe|bota|adiciona)\s+(isso\s+)?(na|em)\s+(minha\s+)?(lista|tarefas)\b""")

        if (pedeTarefa) {
            val titulo = limparTitulo(original, tempo.consumed)
            val conf = if (titulo.isNullOrBlank()) 0.45 else 0.9
            return ParsedIntent(
                type = if (tempo.recurrence.isRecurring) IntentType.CREATE_ROUTINE else IntentType.CREATE_TASK,
                title = titulo,
                whenAt = whenAt,
                hasTime = tempo.hasExplicitTime,
                recurrence = tempo.recurrence,
                priority = prioridade(n),
                rawText = original,
                confidence = conf
            )
        }

        // ---------- 8. Frase com hora, sem verbo claro ----------
        // Ex.: "relatório do CIP às 15h" — trata como lembrete de baixa confiança.
        if (tempo.dateTime != null && tempo.hasExplicitTime) {
            val titulo = limparTitulo(original, tempo.consumed)
            if (!titulo.isNullOrBlank()) {
                return ParsedIntent(
                    type = IntentType.CREATE_REMINDER,
                    title = titulo,
                    whenAt = whenAt,
                    hasTime = true,
                    recurrence = tempo.recurrence,
                    rawText = original,
                    confidence = 0.55
                )
            }
        }

        return ParsedIntent(
            type = IntentType.GENERAL_CONVERSATION,
            rawText = original,
            confidence = 0.2
        )
    }

    // ------------------------------------------------------------------
    // Consultas
    // ------------------------------------------------------------------

    private fun consultaOuResumo(
        n: String,
        original: String,
        tempo: PtBrDateTime.Result,
        whenAt: Long?
    ): ParsedIntent? {
        if (has(n, """^\s*(bom dia|bomdia)\b""") ||
            has(n, """\b(resumo do dia|resumo de hoje|meu resumo|me da o resumo|resumo diario)\b""")
        ) {
            return ParsedIntent(IntentType.DAILY_SUMMARY, rawText = original, confidence = 0.95)
        }

        if (has(n, """^\s*(boa noite)\b""") ||
            has(n, """\b(resumo da noite|encerrando o dia|fechar o dia|resumo noturno)\b""")
        ) {
            return ParsedIntent(IntentType.NIGHT_SUMMARY, rawText = original, confidence = 0.9)
        }

        if (has(n, """\b(resumo da semana|resumo semanal|como foi minha semana|o que tenho na semana)\b""")) {
            return ParsedIntent(IntentType.WEEKLY_SUMMARY, rawText = original, confidence = 0.9)
        }

        if (has(n, """\b(o que (voce|vc) (lembra|sabe) sobre mim|o que (voce|vc) lembra de mim|minhas anotacoes|minha memoria|o que esta na memoria)\b""")) {
            return ParsedIntent(IntentType.QUERY_MEMORY, rawText = original, confidence = 0.9)
        }

        if (has(n, """\b(quais (sao )?(os )?meus lembretes|meus lembretes|o que eu pedi (pra|para) (voce |vc )?lembrar|lembretes de hoje|quais lembretes)\b""")) {
            return ParsedIntent(
                IntentType.QUERY_REMINDERS,
                scope = escopo(n),
                whenAt = whenAt,
                rawText = original,
                confidence = 0.9
            )
        }

        if (has(n, """\b(minhas rotinas|quais rotinas|o que (e|eh) recorrente)\b""")) {
            return ParsedIntent(IntentType.QUERY_ROUTINES, rawText = original, confidence = 0.9)
        }

        val perguntaTarefas = has(n, """\b(o que (eu )?tenho|o que (esta|ta) |quais (as )?tarefas|quais tarefas|minhas tarefas|tenho alguma coisa|o que falta|o que sobrou|tem alguma tarefa)\b""")
        if (perguntaTarefas) {
            val esc = escopo(n)
            // "O que eu tenho hoje?" merece o resumo completo (tarefas + lembretes + agenda)
            if (esc == QueryScope.HOJE && !has(n, """\batrasad""")) {
                return ParsedIntent(IntentType.DAILY_SUMMARY, rawText = original, confidence = 0.9)
            }
            return ParsedIntent(
                IntentType.QUERY_TASKS,
                scope = esc,
                whenAt = whenAt,
                rawText = original,
                confidence = 0.9
            )
        }

        return null
    }

    private fun escopo(n: String): QueryScope = when {
        has(n, """\batrasad""") || has(n, """\bvencid""") || has(n, """\bem atraso\b""") -> QueryScope.ATRASADAS
        has(n, """\bamanha\b""") -> QueryScope.AMANHA
        has(n, """\b(semana|nessa semana|desta semana|proximos dias)\b""") -> QueryScope.SEMANA
        has(n, """\b(pendente|pendentes|aberto|abertas|em aberto|falta|fazer)\b""") -> QueryScope.ABERTAS
        has(n, """\b(conclui|concluidas|feitas|prontas)\b""") -> QueryScope.CONCLUIDAS
        has(n, """\bhoje\b""") -> QueryScope.HOJE
        has(n, """\b(tudo|todas|geral)\b""") -> QueryScope.TODAS
        else -> QueryScope.HOJE
    }

    private fun prioridade(n: String): Priority? = when {
        has(n, """\b(urgente|urgentissimo|pra ontem|imediato)\b""") -> Priority.URGENTE
        has(n, """\b(importante|prioridade alta|alta prioridade|critico|prioritario)\b""") -> Priority.ALTA
        has(n, """\b(quando der|sem pressa|baixa prioridade|se sobrar tempo)\b""") -> Priority.BAIXA
        else -> null
    }

    // ------------------------------------------------------------------
    // Extração de texto
    // ------------------------------------------------------------------

    private fun conteudoMemoria(original: String): String? {
        val n = PtBrDateTime.normalize(original)
        val m = Regex("""^\s*(alan[\s,]+)?(lembre|lembra|guarde|guarda|memorize|memoriza|registre|registra|anote|anota|salve|salva)\s+(que|o seguinte|isto|isso)[\s:,]*""")
            .find(n) ?: return limpaBordas(original)
        val corte = m.range.last + 1
        return limpaBordas(original.substring(corte.coerceAtMost(original.length)))
    }

    private fun alvo(original: String, tempo: PtBrDateTime.Result, prefixos: List<Regex>): String? {
        var txt = PtBrDateTime.removeConsumed(original, tempo.consumed)
        txt = aplicaPrefixos(txt, prefixos)
        txt = aplicaPrefixos(txt, PREFIXOS_GENERICOS)
        val limpo = limpaBordas(txt)
        if (limpo.isNullOrBlank()) return null
        val nn = PtBrDateTime.normalize(limpo)
        // Demonstrativos ("esse lembrete", "essa tarefa", "isso") = último item citado
        if (Regex("""^(esse|essa|este|esta|isso|aquele|aquela|o mesmo|a mesma)?\s*(lembrete|tarefa|item)?\s*$""").matches(nn)) {
            return REF_ULTIMO
        }
        return limpo
    }

    fun limparTitulo(original: String, consumed: List<IntRange>): String? {
        var txt = PtBrDateTime.removeConsumed(original, consumed)
        var anterior: String
        var voltas = 0
        do {
            anterior = txt
            txt = aplicaPrefixos(txt, PREFIXOS_COMANDO)
            txt = aplicaPrefixos(txt, PREFIXOS_GENERICOS)
            voltas++
        } while (txt != anterior && voltas < 8)
        return limpaBordas(txt)
    }

    private fun aplicaPrefixos(texto: String, prefixos: List<Regex>): String {
        var t = texto.trimStart()
        for (rx in prefixos) {
            val n = PtBrDateTime.normalize(t)
            val m = rx.find(n)
            if (m != null && m.range.first == 0) {
                t = t.substring((m.range.last + 1).coerceAtMost(t.length)).trimStart()
            }
        }
        return t
    }

    private fun limpaBordas(texto: String?): String? {
        if (texto == null) return null
        var t = texto.replace(Regex("""\s+"""), " ").trim()
        var anterior: String
        var voltas = 0
        do {
            anterior = t
            t = t.trim().trim(',', ';', ':', '.', '!', '?', '-', '"', '\'', '(', ')')
            val n = PtBrDateTime.normalize(t)
            val cauda = Regex("""\s+(de|do|da|para|pra|ate|as|ao|a|o|e|em|no|na|que|com)$""").find(n)
            if (cauda != null) t = t.substring(0, cauda.range.first).trim()
            val cabeca = Regex("""^(de|do|da|para|pra|ate|as|ao|a|o|e|em|no|na|que)\s+""").find(n)
            if (cabeca != null) t = t.substring((cabeca.range.last + 1).coerceAtMost(t.length)).trim()
            voltas++
        } while (t != anterior && voltas < 8)
        t = t.trim()
        if (t.isEmpty()) return null
        return t.replaceFirstChar { it.uppercaseChar() }
    }

    private fun has(n: String, padrao: String): Boolean = Regex(padrao).containsMatchIn(n)

    companion object {
        const val REF_ULTIMO = "__ULTIMO__"

        private const val MARCADORES_TAREFA =
            """\b(preciso|tenho que|tenho de|devo|nao posso esquecer|nao pode passar|tem que ficar pronto|entregar|terminar|finalizar|fazer ate|prazo)\b"""

        private val PREFIXOS_COMANDO = listOf(
            Regex("""^(alan)\b[\s,:.-]*"""),
            Regex("""^(por favor|pfv|pf)\b[\s,:.-]*"""),
            Regex("""^(entao|ai|olha|escuta|ok|beleza|hey|ei)\b[\s,:.-]+"""),
            Regex("""^(nao me deixa esquecer|nao me deixe esquecer|nao deixa eu esquecer|nao posso esquecer|nao esquece|nao esquecer)\b[\s,:.-]*"""),
            Regex("""^(me lembra|me lembre|me lembrar|lembra me|lembre me|me avisa|me avise|me alerta)\b[\s,:.-]*"""),
            Regex("""^(cria|criar|crie|adiciona|adicione|nova|novo|poe|poem|bota|coloca|coloque|agenda|agendar|marca|marcar)\s+(uma\s+|um\s+)?(tarefa|lembrete|compromisso|evento|rotina)\b[\s,:.-]*"""),
            Regex("""^(coloca|poe|bota|adiciona)\s+(isso\s+)?(na|em)\s+(minha\s+)?(lista|tarefas)\b[\s,:.-]*"""),
            Regex("""^(anota|anote|anotar|guarda|guarde|guardar|registra|registre|memoriza|memorize|salva|salve)\b[\s,:.-]*"""),
            Regex("""^(eu\s+)?(preciso|tenho que|tenho de|devo|quero|vou|pretendo|tenho)\b[\s,:.-]*"""),
            Regex("""^(que|isso|isto|o seguinte)\b[\s,:.-]*""")
        )

        private val PREFIXOS_GENERICOS = listOf(
            Regex("""^(de|do|da|para|pra|que|a|o|as|os|ao|em|no|na)\b[\s,:.-]*""")
        )

        private val ALVO_CONCLUIR = listOf(
            Regex("""^(alan)\b[\s,:.-]*"""),
            Regex("""^(pode\s+)?(conclua|conclui|concluir|concluida|concluido|concluo|terminei|finalizei|ja fiz|fiz|marca como feita|marca como concluida|marcar como concluida|marque como concluida|feito|pronto)\b[\s,:.-]*"""),
            Regex("""^(a|o)\s+(tarefa|lembrete)\b[\s,:.-]*""")
        )

        private val ALVO_ADIAR = listOf(
            Regex("""^(alan)\b[\s,:.-]*"""),
            Regex("""^(adia|adie|adiar|joga para|jogue para|empurra|empurre|remarca|remarque|deixa para|deixe para|passa para|transfere)\b[\s,:.-]*"""),
            Regex("""^(a|o)\s+(tarefa|lembrete)\b[\s,:.-]*""")
        )

        private val ALVO_APAGAR = listOf(
            Regex("""^(alan)\b[\s,:.-]*"""),
            Regex("""^(apaga|apague|exclui|exclua|remove|remova|deleta|delete|cancela|cancele)\b[\s,:.-]*"""),
            Regex("""^(a|o)\s+(tarefa|lembrete|memoria|anotacao)\b[\s,:.-]*""")
        )
    }
}
