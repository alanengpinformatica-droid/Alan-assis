package com.alan.assistant.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.alan.assistant.AppContainer
import com.alan.assistant.core.AssistantEngine
import com.alan.assistant.core.EventItem
import com.alan.assistant.core.MemoryItem
import com.alan.assistant.core.Reminder
import com.alan.assistant.core.RoutineItem
import com.alan.assistant.core.Task
import com.alan.assistant.core.TaskStatus
import com.alan.assistant.data.AuditEntity
import com.alan.assistant.data.Settings
import com.alan.assistant.data.toDomain
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.LocalDateTime

/** Uma fala da conversa, do jeito que aparece na tela. */
data class Bolha(val doAlan: Boolean, val texto: String, val hora: String)

data class EstadoTela(
    val conversa: List<Bolha> = emptyList(),
    val ouvindo: Boolean = false,
    val nivelVoz: Float = 0f,
    val processando: Boolean = false,
    val aguardandoResposta: Boolean = false,
    val erro: String? = null,
    val alarmeExatoOk: Boolean = true
)

data class ContadoresHoje(
    val tarefas: Int = 0,
    val lembretes: Int = 0,
    val atrasadas: Int = 0,
    val compromissos: Int = 0
)

class AssistantViewModel(private val c: AppContainer) : ViewModel() {

    private val _estado = MutableStateFlow(EstadoTela())
    val estado: StateFlow<EstadoTela> = _estado.asStateFlow()

    private val _contadores = MutableStateFlow(ContadoresHoje())
    val contadores: StateFlow<ContadoresHoje> = _contadores.asStateFlow()

    // ---------- Listas reativas para as telas ----------

    val tarefas: StateFlow<List<Task>> = c.db.taskDao().fluxoTodas()
        .map { lista -> lista.map { it.toDomain() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val lembretes: StateFlow<List<Reminder>> = c.db.reminderDao().fluxoAtivos()
        .map { lista -> lista.map { it.toDomain() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val rotinas: StateFlow<List<RoutineItem>> = c.db.routineDao().fluxoTodas()
        .map { lista -> lista.map { it.toDomain() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val memorias: StateFlow<List<MemoryItem>> = c.db.memoryDao().fluxoTodas()
        .map { lista -> lista.map { it.toDomain() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val historico: StateFlow<List<AuditEntity>> = c.db.auditDao().fluxoRecentes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val zone = c.zone

    init {
        atualizarContadores()
        viewModelScope.launch(Dispatchers.IO) {
            val ok = c.scheduler.podeAgendarExato()
            _estado.value = _estado.value.copy(alarmeExatoOk = ok)
        }
        saudacaoInicial()
    }

    // ==================================================================
    // Conversa
    // ==================================================================

    private fun saudacaoInicial() {
        viewModelScope.launch(Dispatchers.IO) {
            val agora = LocalDateTime.now(c.zone)
            val saudacao = com.alan.assistant.core.Summaries.saudacaoPor(agora)
            adicionar(Bolha(false, "$saudacao, Alan. O que posso fazer por você?", hora(System.currentTimeMillis())))
        }
    }

    fun enviar(texto: String, viaVoice: Boolean = false) {
        val entrada = texto.trim()
        if (entrada.isEmpty()) return

        adicionar(Bolha(true, entrada, hora(System.currentTimeMillis())))
        _estado.value = _estado.value.copy(processando = true, erro = null)

        viewModelScope.launch {
            val resposta = withContext(Dispatchers.IO) {
                try {
                    c.conversations.registrar("alan", entrada, null, viaVoice)
                    val r = c.engine.handle(entrada, viaVoice)
                    c.conversations.registrar("assistente", r.text, r.intent.name, false)
                    r
                } catch (e: Throwable) {
                    com.alan.assistant.core.AssistantReply(
                        text = "Algo falhou aqui no meu banco de dados. Já registrei o erro; " +
                            "tente de novo em alguns segundos.",
                        speak = true
                    )
                }
            }

            adicionar(Bolha(false, resposta.text, hora(System.currentTimeMillis())))
            _estado.value = _estado.value.copy(
                processando = false,
                aguardandoResposta = resposta.pending != null
            )
            if (resposta.speak) c.speaker.falar(resposta.text)
            atualizarContadores()
        }
    }

    fun ouvir() {
        if (_estado.value.ouvindo) {
            c.listener.parar()
            _estado.value = _estado.value.copy(ouvindo = false)
            return
        }
        c.speaker.parar()
        _estado.value = _estado.value.copy(ouvindo = true, erro = null, nivelVoz = 0f)
        c.listener.ouvir(
            aoTexto = { texto -> enviar(texto, viaVoice = true) },
            aoErro = { msg -> _estado.value = _estado.value.copy(erro = msg, ouvindo = false) },
            aoNivel = { nivel -> _estado.value = _estado.value.copy(nivelVoz = nivel) },
            aoFim = { _estado.value = _estado.value.copy(ouvindo = false, nivelVoz = 0f) }
        )
    }

    fun limparErro() {
        _estado.value = _estado.value.copy(erro = null)
    }

    private fun adicionar(b: Bolha) {
        _estado.value = _estado.value.copy(conversa = (_estado.value.conversa + b).takeLast(200))
    }

    // ==================================================================
    // Ações diretas da interface (sem passar por linguagem natural)
    // ==================================================================

    fun concluir(task: Task) = emIo {
        val agora = System.currentTimeMillis()
        c.tasks.update(
            task.copy(status = TaskStatus.CONCLUIDA, completedAt = agora, updatedAt = agora)
        )
        task.reminderId?.let { id ->
            c.reminders.byId(id)?.let { r ->
                if (!r.recurrence.isRecurring) {
                    c.reminders.update(r.copy(active = false, updatedAt = agora))
                    c.scheduler.cancelar(id)
                }
            }
        }
        c.audit.registrar("TASK_COMPLETE", "task", task.id, task.title)
        atualizarContadores()
    }

    fun reabrir(task: Task) = emIo {
        val agora = System.currentTimeMillis()
        c.tasks.update(task.copy(status = TaskStatus.PENDENTE, completedAt = null, updatedAt = agora))
        c.audit.registrar("TASK_REOPEN", "task", task.id, task.title)
        atualizarContadores()
    }

    fun apagar(task: Task) = emIo {
        task.reminderId?.let { c.scheduler.cancelar(it); c.reminders.delete(it) }
        c.tasks.delete(task.id)
        c.audit.registrar("TASK_DELETE", "task", task.id, task.title)
        atualizarContadores()
    }

    fun apagar(reminder: Reminder) = emIo {
        c.scheduler.cancelar(reminder.id)
        c.reminders.delete(reminder.id)
        c.audit.registrar("REMINDER_DELETE", "reminder", reminder.id, reminder.title)
        atualizarContadores()
    }

    fun apagar(item: MemoryItem) = emIo {
        c.memories.delete(item.id)
        c.audit.registrar("MEMORY_DELETE", "memory", item.id, item.content.take(60))
    }

    fun alternarRotina(rotina: RoutineItem) = emIo {
        val agora = System.currentTimeMillis()
        val nova = rotina.copy(active = !rotina.active, updatedAt = agora)
        c.routines.update(nova)
        rotina.reminderId?.let { id ->
            c.reminders.byId(id)?.let { r ->
                c.reminders.update(r.copy(active = nova.active, updatedAt = agora))
                if (nova.active) c.scheduler.agendar(r.copy(active = true)) else c.scheduler.cancelar(id)
            }
        }
        c.audit.registrar(
            if (nova.active) "ROUTINE_ENABLE" else "ROUTINE_DISABLE", "routine", rotina.id, rotina.title
        )
    }

    fun apagar(rotina: RoutineItem) = emIo {
        rotina.reminderId?.let { c.scheduler.cancelar(it); c.reminders.delete(it) }
        c.routines.delete(rotina.id)
        c.audit.registrar("ROUTINE_DELETE", "routine", rotina.id, rotina.title)
    }

    // ==================================================================
    // Contadores do dia (tela inicial)
    // ==================================================================

    fun atualizarContadores() = emIo {
        c.engine.atualizarAtrasadas()
        val agora = LocalDateTime.now(c.zone)
        val inicio = agora.toLocalDate().atStartOfDay().atZone(c.zone).toInstant().toEpochMilli()
        val fim = agora.toLocalDate().atTime(23, 59, 59).atZone(c.zone).toInstant().toEpochMilli()

        val tarefasHoje = c.tasks.comPrazoEntre(inicio, fim).filter { it.status.aberta }
        val atrasadas = c.tasks.abertas().filter {
            it.dueAt != null && it.dueAt!! < System.currentTimeMillis() && it.status != TaskStatus.CONCLUIDA
        }
        val lembretesHoje = c.reminders.ativosEntre(inicio, fim).filter {
            it.kind == com.alan.assistant.core.ReminderKind.USER ||
                it.kind == com.alan.assistant.core.ReminderKind.TASK ||
                it.kind == com.alan.assistant.core.ReminderKind.EVENT
        }
        val eventosHoje: List<EventItem> = c.events.entre(inicio, fim)

        _contadores.value = ContadoresHoje(
            tarefas = tarefasHoje.size,
            lembretes = lembretesHoje.size,
            atrasadas = atrasadas.size,
            compromissos = eventosHoje.size
        )
    }

    // ==================================================================
    // Configurações
    // ==================================================================

    fun falaAtiva(): Boolean = c.settings.getBool(Settings.FALA_ATIVA, true)

    fun definirFala(ativa: Boolean) = emIo {
        c.settings.setBool(Settings.FALA_ATIVA, ativa)
        c.speaker.ativo = ativa
    }

    fun horaResumo(manha: Boolean): Int? =
        c.settings.getHora(if (manha) Settings.RESUMO_MANHA else Settings.RESUMO_NOITE, if (manha) 7 else 21)

    fun definirResumo(manha: Boolean, hora: Int?) = emIo {
        c.settings.setHora(if (manha) Settings.RESUMO_MANHA else Settings.RESUMO_NOITE, hora)
        c.engine.garantirResumos(
            horaManha = c.settings.getHora(Settings.RESUMO_MANHA, 7),
            horaNoite = c.settings.getHora(Settings.RESUMO_NOITE, 21)
        )
    }

    fun iaAtiva(): Boolean = c.settings.getBool(Settings.IA_ATIVA, true)
    fun definirIa(ativa: Boolean) = emIo { c.settings.setBool(Settings.IA_ATIVA, ativa) }

    fun temChaveIa(): Boolean = c.secrets.temApiKey()
    fun salvarChaveIa(chave: String?) = emIo { c.secrets.salvarApiKey(chave) }

    fun bloqueioAtivo(): Boolean = c.settings.getBool(Settings.BLOQUEIO_ATIVO, false)
    fun definirBloqueio(ativo: Boolean) = emIo { c.settings.setBool(Settings.BLOQUEIO_ATIVO, ativo) }

    fun definirPin(pin: String) = emIo { c.secrets.definirPin(pin) }
    fun temPin(): Boolean = c.secrets.temPin()

    fun exportar(aoTerminar: (String) -> Unit) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { c.backup.exportarTudo() }
            aoTerminar(r.mensagem)
        }
    }

    fun exportarPara(uri: android.net.Uri, aoTerminar: (String) -> Unit) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { c.backup.exportarJsonPara(uri) }
            aoTerminar(r.mensagem)
        }
    }

    fun restaurarDe(uri: android.net.Uri, aoTerminar: (String) -> Unit) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { c.backup.restaurarDe(uri) }
            aoTerminar(r.mensagem)
        }
    }

    fun ajuda(): String = AssistantEngine.AJUDA

    fun podeAgendarExato(): Boolean = c.scheduler.podeAgendarExato()

    override fun onCleared() {
        c.listener.liberar()
        super.onCleared()
    }

    private fun emIo(bloco: suspend () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { bloco() }
        }
    }

    private fun hora(ms: Long): String {
        val t = LocalDateTime.ofInstant(Instant.ofEpochMilli(ms), c.zone)
        return "%02d:%02d".format(t.hour, t.minute)
    }

    class Factory(private val c: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            AssistantViewModel(c) as T
    }
}
