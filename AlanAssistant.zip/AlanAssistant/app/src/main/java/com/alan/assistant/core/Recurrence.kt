package com.alan.assistant.core

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

enum class RecurrenceType {
    NONE,
    DAILY,
    WEEKLY,
    MONTHLY_DAY,
    YEARLY,
    INTERVAL_MINUTES,
    FIRST_BUSINESS_DAY
}

/**
 * Regra de recorrência.
 *
 * Decisão de projeto: NÃO usamos AlarmManager.setRepeating (que é inexato no
 * Android moderno). Cada disparo calcula a PRÓXIMA ocorrência e reagenda um
 * alarme exato. Toda essa matemática vive aqui, em Kotlin puro e testável.
 */
data class Recurrence(
    val type: RecurrenceType = RecurrenceType.NONE,
    val daysOfWeek: Set<DayOfWeek> = emptySet(),
    val dayOfMonth: Int? = null,
    val month: Int? = null,
    val intervalMinutes: Int? = null
) {

    val isRecurring: Boolean get() = type != RecurrenceType.NONE

    fun encode(): String = when (type) {
        RecurrenceType.NONE -> "NONE"
        RecurrenceType.DAILY -> "DAILY"
        RecurrenceType.WEEKLY -> "WEEKLY:" + daysOfWeek.map { it.value }.sorted().joinToString(",")
        RecurrenceType.MONTHLY_DAY -> "MONTHLY_DAY:${dayOfMonth ?: 1}"
        RecurrenceType.YEARLY -> "YEARLY:${month ?: 1}-${dayOfMonth ?: 1}"
        RecurrenceType.INTERVAL_MINUTES -> "INTERVAL_MINUTES:${intervalMinutes ?: 60}"
        RecurrenceType.FIRST_BUSINESS_DAY -> "FIRST_BUSINESS_DAY"
    }

    /**
     * Próxima ocorrência estritamente DEPOIS de [after], no horário [time].
     * Retorna null se a regra não produz ocorrências (não deve acontecer).
     */
    fun next(after: LocalDateTime, time: LocalTime): LocalDateTime? {
        return when (type) {
            RecurrenceType.NONE -> null

            RecurrenceType.DAILY -> {
                var c = after.toLocalDate().atTime(time)
                if (!c.isAfter(after)) c = c.plusDays(1)
                c
            }

            RecurrenceType.WEEKLY -> {
                val dias = if (daysOfWeek.isEmpty()) setOf(after.dayOfWeek) else daysOfWeek
                var found: LocalDateTime? = null
                for (i in 0..14) {
                    val d = after.toLocalDate().plusDays(i.toLong())
                    if (d.dayOfWeek in dias) {
                        val c = d.atTime(time)
                        if (c.isAfter(after)) { found = c; break }
                    }
                }
                found
            }

            RecurrenceType.MONTHLY_DAY -> {
                val alvo = dayOfMonth ?: after.dayOfMonth
                var found: LocalDateTime? = null
                for (i in 0..24) {
                    val base = after.toLocalDate().withDayOfMonth(1).plusMonths(i.toLong())
                    val dia = minOf(alvo, base.lengthOfMonth())
                    val c = base.withDayOfMonth(dia).atTime(time)
                    if (c.isAfter(after)) { found = c; break }
                }
                found
            }

            RecurrenceType.YEARLY -> {
                val m = month ?: after.monthValue
                val alvo = dayOfMonth ?: after.dayOfMonth
                var found: LocalDateTime? = null
                for (i in 0..5) {
                    val ano = after.year + i
                    val base = LocalDate.of(ano, m, 1)
                    val dia = minOf(alvo, base.lengthOfMonth())
                    val c = base.withDayOfMonth(dia).atTime(time)
                    if (c.isAfter(after)) { found = c; break }
                }
                found
            }

            RecurrenceType.INTERVAL_MINUTES -> {
                val min = (intervalMinutes ?: 60).coerceAtLeast(1)
                after.plusMinutes(min.toLong())
            }

            RecurrenceType.FIRST_BUSINESS_DAY -> {
                var found: LocalDateTime? = null
                for (i in 0..24) {
                    val base = after.toLocalDate().withDayOfMonth(1).plusMonths(i.toLong())
                    var d = base
                    while (d.dayOfWeek == DayOfWeek.SATURDAY || d.dayOfWeek == DayOfWeek.SUNDAY) {
                        d = d.plusDays(1)
                    }
                    val c = d.atTime(time)
                    if (c.isAfter(after)) { found = c; break }
                }
                found
            }
        }
    }

    /** Texto em português para confirmar ao Alan o que foi entendido. */
    fun describe(): String = when (type) {
        RecurrenceType.NONE -> ""
        RecurrenceType.DAILY -> "todos os dias"
        RecurrenceType.WEEKLY -> {
            if (daysOfWeek.size == 7) "todos os dias"
            else "toda " + daysOfWeek.sortedBy { it.value }.joinToString(" e ") { nomeDiaSemana(it) }
        }
        RecurrenceType.MONTHLY_DAY -> "todo dia ${dayOfMonth ?: 1}"
        RecurrenceType.YEARLY -> "todo ano em ${dayOfMonth ?: 1}/${month ?: 1}"
        RecurrenceType.INTERVAL_MINUTES -> {
            val m = intervalMinutes ?: 60
            if (m % 60 == 0) "a cada ${m / 60} hora(s)" else "a cada $m minutos"
        }
        RecurrenceType.FIRST_BUSINESS_DAY -> "no primeiro dia útil de cada mês"
    }

    companion object {
        val NONE = Recurrence()

        fun decode(s: String?): Recurrence {
            if (s.isNullOrBlank() || s == "NONE") return NONE
            val parts = s.split(":", limit = 2)
            val head = parts[0]
            val arg = parts.getOrNull(1).orEmpty()
            return when (head) {
                "DAILY" -> Recurrence(RecurrenceType.DAILY)
                "WEEKLY" -> Recurrence(
                    RecurrenceType.WEEKLY,
                    daysOfWeek = arg.split(",")
                        .mapNotNull { it.trim().toIntOrNull() }
                        .filter { it in 1..7 }
                        .map { DayOfWeek.of(it) }
                        .toSet()
                )
                "MONTHLY_DAY" -> Recurrence(
                    RecurrenceType.MONTHLY_DAY,
                    dayOfMonth = arg.toIntOrNull()?.coerceIn(1, 31) ?: 1
                )
                "YEARLY" -> {
                    val md = arg.split("-")
                    Recurrence(
                        RecurrenceType.YEARLY,
                        month = md.getOrNull(0)?.toIntOrNull()?.coerceIn(1, 12) ?: 1,
                        dayOfMonth = md.getOrNull(1)?.toIntOrNull()?.coerceIn(1, 31) ?: 1
                    )
                }
                "INTERVAL_MINUTES" -> Recurrence(
                    RecurrenceType.INTERVAL_MINUTES,
                    intervalMinutes = arg.toIntOrNull()?.coerceAtLeast(1) ?: 60
                )
                "FIRST_BUSINESS_DAY" -> Recurrence(RecurrenceType.FIRST_BUSINESS_DAY)
                else -> NONE
            }
        }

        fun nomeDiaSemana(d: DayOfWeek): String = when (d) {
            DayOfWeek.MONDAY -> "segunda-feira"
            DayOfWeek.TUESDAY -> "terça-feira"
            DayOfWeek.WEDNESDAY -> "quarta-feira"
            DayOfWeek.THURSDAY -> "quinta-feira"
            DayOfWeek.FRIDAY -> "sexta-feira"
            DayOfWeek.SATURDAY -> "sábado"
            DayOfWeek.SUNDAY -> "domingo"
        }
    }
}
