package com.alan.assistant.ai

import android.util.Log
import com.alan.assistant.core.IntentType
import com.alan.assistant.core.IntentValidator
import com.alan.assistant.core.Interpreter
import com.alan.assistant.core.InterpreterContext
import com.alan.assistant.core.ParsedIntent
import com.alan.assistant.core.Priority
import com.alan.assistant.core.QueryScope
import com.alan.assistant.core.Recurrence
import com.alan.assistant.core.RecurrenceType
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL
import java.time.DayOfWeek
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/**
 * CAMADA DE IA — TOTALMENTE ISOLADA (itens 15 e 20 do escopo).
 *
 * Regras que esta camada respeita, sem exceção:
 *  - ela NÃO conhece o banco, o AlarmManager nem o motor de negócio;
 *  - ela só devolve um `ParsedIntent`, que ainda passa pelo IntentValidator;
 *  - se a chave não estiver configurada, se não houver internet, se a API
 *    falhar ou se o JSON vier malformado, ela devolve UNKNOWN e o app segue
 *    funcionando com o interpretador de regras (offline);
 *  - a chave nunca fica no código: vem do SecretsStore (EncryptedSharedPreferences).
 */
class AiInterpreter(
    private val chaveProvider: () -> String?,
    private val modeloProvider: () -> String = { MODELO_PADRAO },
    private val zone: ZoneId = ZoneId.of("America/Sao_Paulo"),
    private val timeoutMs: Int = 12_000
) : Interpreter {

    override fun interpret(texto: String, ctx: InterpreterContext): ParsedIntent {
        val chave = chaveProvider()?.trim().orEmpty()
        if (chave.isEmpty()) return vazio(texto)

        return try {
            val corpo = montarRequisicao(texto, ctx)
            val resposta = chamar(chave, corpo) ?: return vazio(texto)
            val json = extrairJson(resposta) ?: return vazio(texto)
            val intent = mapear(json, texto)
            // Sanitização obrigatória antes de devolver ao motor.
            IntentValidator.sanitizeFromAi(intent, ctx.nowMillis)
        } catch (e: Throwable) {
            Log.w(TAG, "IA indisponível (${e.javaClass.simpleName}): ${e.message}")
            vazio(texto)
        }
    }

    private fun vazio(texto: String) =
        ParsedIntent(type = IntentType.UNKNOWN, rawText = texto, confidence = 0.0, source = "ia")

    // ==================================================================
    // Requisição
    // ==================================================================

    private fun montarRequisicao(texto: String, ctx: InterpreterContext): String {
        val agora = Instant.ofEpochMilli(ctx.nowMillis).atZone(zone)
        val agoraIso = agora.format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"))
        val diaSemana = when (agora.dayOfWeek) {
            DayOfWeek.MONDAY -> "segunda-feira"
            DayOfWeek.TUESDAY -> "terça-feira"
            DayOfWeek.WEDNESDAY -> "quarta-feira"
            DayOfWeek.THURSDAY -> "quinta-feira"
            DayOfWeek.FRIDAY -> "sexta-feira"
            DayOfWeek.SATURDAY -> "sábado"
            DayOfWeek.SUNDAY -> "domingo"
        }

        val recentes = (ctx.tarefasRecentes + ctx.lembretesRecentes)
            .take(12)
            .joinToString("; ") { it.second }

        val system = buildString {
            append("Você converte pedidos em português do Brasil em UMA intenção estruturada ")
            append("para um assistente pessoal. Responda SOMENTE com um objeto JSON válido, ")
            append("sem texto antes ou depois, sem markdown, sem crases.\n\n")
            append("Agora é $agoraIso ($diaSemana), fuso America/Sao_Paulo.\n")
            if (recentes.isNotBlank()) append("Itens recentes do usuário: $recentes\n")
            append("\nCampos do JSON:\n")
            append("type: um de ").append(IntentType.entries.joinToString(",") { it.name }).append("\n")
            append("title: string curta no infinitivo, sem a parte de data/hora (ou null)\n")
            append("datetime: \"yyyy-MM-ddTHH:mm\" no fuso local, ou null se o usuário não disse quando\n")
            append("has_time: true se o usuário disse um horário explícito\n")
            append("recurrence: null ou {kind:\"DAILY|WEEKLY|MONTHLY_DAY|YEARLY|INTERVAL_MINUTES|FIRST_BUSINESS_DAY\",")
            append("days:[1..7 seg=1],day_of_month:int,interval_minutes:int}\n")
            append("priority: BAIXA|NORMAL|ALTA|URGENTE ou null\n")
            append("target_ref: texto que aponta para um item existente, ou null\n")
            append("offset_minutes: inteiro para adiamentos (\"adia uma hora\" = 60), ou null\n")
            append("content: texto a memorizar em SAVE_MEMORY, ou null\n")
            append("scope: HOJE|AMANHA|SEMANA|ATRASADAS|ABERTAS|CONCLUIDAS|TODAS\n")
            append("confidence: 0.0 a 1.0\n\n")
            append("NUNCA invente data ou horário que o usuário não disse: nesse caso use null. ")
            append("Se não entender, use type UNKNOWN.")
        }

        val messages = JSONArray().put(
            JSONObject()
                .put("role", "user")
                .put("content", texto)
        )

        return JSONObject()
            .put("model", modeloProvider())
            .put("max_tokens", 500)
            .put("temperature", 0)
            .put("system", system)
            .put("messages", messages)
            .toString()
    }

    private fun chamar(chave: String, corpo: String): String? {
        val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            doOutput = true
            setRequestProperty("content-type", "application/json")
            setRequestProperty("x-api-key", chave)
            setRequestProperty("anthropic-version", "2023-06-01")
        }
        return try {
            conn.outputStream.use { it.write(corpo.toByteArray(Charsets.UTF_8)) }
            val codigo = conn.responseCode
            val stream = if (codigo in 200..299) conn.inputStream else conn.errorStream
            val resposta = stream?.bufferedReader()?.use(BufferedReader::readText).orEmpty()
            if (codigo !in 200..299) {
                Log.w(TAG, "API respondeu $codigo: ${resposta.take(200)}")
                null
            } else {
                resposta
            }
        } finally {
            conn.disconnect()
        }
    }

    /** Junta os blocos de texto da resposta e extrai o primeiro objeto JSON. */
    private fun extrairJson(resposta: String): JSONObject? {
        val raiz = JSONObject(resposta)
        val content = raiz.optJSONArray("content") ?: return null
        val texto = buildString {
            for (i in 0 until content.length()) {
                val bloco = content.optJSONObject(i) ?: continue
                if (bloco.optString("type") == "text") append(bloco.optString("text"))
            }
        }.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()

        val inicio = texto.indexOf('{')
        val fim = texto.lastIndexOf('}')
        if (inicio < 0 || fim <= inicio) return null
        return JSONObject(texto.substring(inicio, fim + 1))
    }

    // ==================================================================
    // Mapeamento JSON -> ParsedIntent
    // ==================================================================

    private fun mapear(o: JSONObject, textoOriginal: String): ParsedIntent {
        val tipo = runCatching { IntentType.valueOf(o.optString("type").uppercase()) }
            .getOrDefault(IntentType.UNKNOWN)

        val quando = o.optStringOrNull("datetime")?.let { iso ->
            runCatching {
                java.time.LocalDateTime.parse(iso).atZone(zone).toInstant().toEpochMilli()
            }.getOrNull()
        }

        return ParsedIntent(
            type = tipo,
            title = o.optStringOrNull("title"),
            whenAt = quando,
            hasTime = o.optBoolean("has_time", false),
            recurrence = lerRecorrencia(o.optJSONObject("recurrence")),
            priority = o.optStringOrNull("priority")?.let { Priority.from(it) },
            category = o.optStringOrNull("category"),
            targetRef = o.optStringOrNull("target_ref"),
            offsetMinutes = if (o.isNull("offset_minutes")) null else o.optInt("offset_minutes").takeIf { it != 0 },
            content = o.optStringOrNull("content"),
            scope = runCatching { QueryScope.valueOf(o.optString("scope").uppercase()) }
                .getOrDefault(QueryScope.HOJE),
            confidence = o.optDouble("confidence", 0.6).coerceIn(0.0, 1.0),
            rawText = textoOriginal,
            source = "ia"
        )
    }

    private fun lerRecorrencia(o: JSONObject?): Recurrence {
        if (o == null) return Recurrence.NONE
        val kind = o.optString("kind").uppercase()
        val tipo = runCatching { RecurrenceType.valueOf(kind) }.getOrNull() ?: return Recurrence.NONE

        val dias = o.optJSONArray("days")?.let { arr ->
            (0 until arr.length()).mapNotNull { idx ->
                when (arr.optInt(idx)) {
                    1 -> DayOfWeek.MONDAY
                    2 -> DayOfWeek.TUESDAY
                    3 -> DayOfWeek.WEDNESDAY
                    4 -> DayOfWeek.THURSDAY
                    5 -> DayOfWeek.FRIDAY
                    6 -> DayOfWeek.SATURDAY
                    7 -> DayOfWeek.SUNDAY
                    else -> null
                }
            }.toSet()
        } ?: emptySet()

        return Recurrence(
            type = tipo,
            daysOfWeek = dias,
            dayOfMonth = if (o.isNull("day_of_month")) null else o.optInt("day_of_month").takeIf { it in 1..31 },
            intervalMinutes = if (o.isNull("interval_minutes")) null
            else o.optInt("interval_minutes").takeIf { it > 0 }
        )
    }

    private fun JSONObject.optStringOrNull(key: String): String? =
        if (isNull(key)) null else optString(key).trim().ifBlank { null }

    companion object {
        private const val TAG = "AlanIA"
        private const val ENDPOINT = "https://api.anthropic.com/v1/messages"
        const val MODELO_PADRAO = "claude-haiku-4-5-20251001"
    }
}

/**
 * Combina regras + IA.
 *
 * Ordem deliberada (item 37 — confiabilidade acima de inteligência):
 *  1. as REGRAS rodam sempre, são offline, instantâneas e determinísticas;
 *  2. a IA só é consultada quando as regras não entenderam bem
 *     (confiança baixa) E existe chave configurada;
 *  3. se a IA falhar ou responder pior, prevalece o resultado das regras.
 *
 * Resultado: o app nunca fica pior por causa da IA, e funciona 100% offline.
 */
class CompositeInterpreter(
    private val regras: Interpreter,
    private val ia: Interpreter,
    private val iaHabilitada: () -> Boolean,
    private val limiarConfianca: Double = 0.5
) : Interpreter {

    override fun interpret(texto: String, ctx: InterpreterContext): ParsedIntent {
        val porRegras = regras.interpret(texto, ctx)

        val precisaDeAjuda =
            porRegras.type == IntentType.UNKNOWN ||
                porRegras.type == IntentType.GENERAL_CONVERSATION ||
                porRegras.confidence < limiarConfianca

        if (!precisaDeAjuda || !iaHabilitada()) return porRegras

        val porIa = ia.interpret(texto, ctx)
        val iaMelhor = porIa.type != IntentType.UNKNOWN && porIa.confidence > porRegras.confidence
        return if (iaMelhor) porIa else porRegras
    }
}
