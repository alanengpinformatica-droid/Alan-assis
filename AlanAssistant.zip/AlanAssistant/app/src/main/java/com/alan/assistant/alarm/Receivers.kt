package com.alan.assistant.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.alan.assistant.AlanApp
import com.alan.assistant.work.MaintenanceWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

private const val TAG = "AlanReceiver"

/**
 * Escopo próprio dos receivers. Como usamos `goAsync()`, o processo fica vivo
 * por alguns segundos enquanto o trabalho termina — tempo mais que suficiente
 * para ler o banco e postar a notificação.
 */
private val escopo = CoroutineScope(SupervisorJob() + Dispatchers.IO)

/**
 * Recebe o disparo do AlarmManager (item 6).
 *
 * Fluxo: alarme -> motor (calcula texto, reagenda recorrência) -> notificação.
 * Se qualquer etapa falhar, o erro é registrado e o app continua de pé.
 */
class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getStringExtra(ReminderScheduler.EXTRA_REMINDER_ID)
            ?: intent.data?.lastPathSegment
            ?: return

        val pending = goAsync()
        val app = context.applicationContext as? AlanApp
        if (app == null) {
            pending.finish()
            return
        }

        escopo.launch {
            try {
                val c = app.container
                val lembrete = c.reminders.byId(reminderId)
                val disparo = c.engine.dispararLembrete(reminderId)
                if (disparo != null) {
                    c.notifier.mostrarLembrete(
                        reminderId = disparo.reminderId,
                        titulo = disparo.titulo,
                        corpo = disparo.texto,
                        taskId = disparo.taskId,
                        kind = lembrete?.kind ?: com.alan.assistant.core.ReminderKind.USER
                    )
                } else {
                    Log.w(TAG, "Lembrete $reminderId não encontrado ou inativo")
                }
            } catch (e: Throwable) {
                Log.e(TAG, "Falha ao disparar lembrete: ${e.message}", e)
            } finally {
                pending.finish()
            }
        }
    }
}

/**
 * Reconstrói TUDO depois de reinicializar o celular (item 18 — obrigatório).
 *
 * Também roda quando o app é atualizado (MY_PACKAGE_REPLACED) e quando a hora
 * ou o fuso do aparelho muda — nesses casos os alarmes agendados são perdidos
 * ou ficam deslocados e precisam ser recalculados a partir do banco.
 *
 * O trabalho real é delegado ao WorkManager: um BroadcastReceiver tem poucos
 * segundos de vida, e logo após o boot o sistema está sobrecarregado.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val acao = intent.action ?: return
        Log.i(TAG, "BootReceiver: $acao")

        val pedido = OneTimeWorkRequestBuilder<MaintenanceWorker>()
            .setInputData(MaintenanceWorker.dadosDeBoot())
            .build()

        WorkManager.getInstance(context.applicationContext)
            .enqueueUniqueWork(
                MaintenanceWorker.TRABALHO_BOOT,
                ExistingWorkPolicy.REPLACE,
                pedido
            )
    }
}

/**
 * Botões da notificação: CONCLUIR e ADIAR 30 MIN (item 17).
 */
class ActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val acao = intent.action ?: return
        val reminderId = intent.getStringExtra(EXTRA_REMINDER_ID) ?: return
        val minutos = intent.getIntExtra(EXTRA_MINUTOS, 30)

        val pending = goAsync()
        val app = context.applicationContext as? AlanApp
        if (app == null) {
            pending.finish()
            return
        }

        escopo.launch {
            try {
                val c = app.container
                when (acao) {
                    ACAO_CONCLUIR -> {
                        val ok = c.engine.concluirPorLembrete(reminderId)
                        c.notifier.cancelar(reminderId)
                        if (!ok) Log.w(TAG, "Nada para concluir em $reminderId")
                    }
                    ACAO_ADIAR -> {
                        val ok = c.engine.adiarLembrete(reminderId, minutos)
                        c.notifier.cancelar(reminderId)
                        if (!ok) Log.w(TAG, "Nada para adiar em $reminderId")
                    }
                    else -> Log.w(TAG, "Ação desconhecida: $acao")
                }
            } catch (e: Throwable) {
                Log.e(TAG, "Falha na ação da notificação: ${e.message}", e)
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        const val ACAO_CONCLUIR = "com.alan.assistant.CONCLUIR"
        const val ACAO_ADIAR = "com.alan.assistant.ADIAR"
        const val EXTRA_REMINDER_ID = "reminder_id"
        const val EXTRA_NOTIF_ID = "notif_id"
        const val EXTRA_MINUTOS = "minutos"
    }
}
