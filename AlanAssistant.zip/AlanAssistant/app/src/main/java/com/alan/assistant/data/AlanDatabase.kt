package com.alan.assistant.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Banco local do ALAN ASSISTANT (SQLite via Room).
 *
 * REGRA DE OURO (item 28 do escopo): NUNCA usar
 * `fallbackToDestructiveMigration()`. Se o esquema mudar sem migração, o app
 * prefere falhar ao abrir o banco a apagar os dados do Alan.
 *
 * COMO ADICIONAR UMA MIGRAÇÃO NO FUTURO
 * -------------------------------------
 * 1. Suba `version` abaixo (1 -> 2).
 * 2. Escreva a migração:
 *
 *        val MIGRATION_1_2 = object : Migration(1, 2) {
 *            override fun migrate(db: SupportSQLiteDatabase) {
 *                db.execSQL("ALTER TABLE tasks ADD COLUMN projeto TEXT")
 *            }
 *        }
 *
 * 3. Acrescente-a ao array MIGRATIONS.
 * 4. O esquema da versão anterior já está versionado em `app/schemas/` —
 *    é ele que permite escrever a migração com segurança e testá-la.
 */
@Database(
    entities = [
        UserEntity::class,
        TaskEntity::class,
        ReminderEntity::class,
        MemoryEntity::class,
        EventEntity::class,
        RoutineEntity::class,
        ConversationEntity::class,
        NotificationEntity::class,
        SettingEntity::class,
        AuditEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AlanDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun taskDao(): TaskDao
    abstract fun reminderDao(): ReminderDao
    abstract fun memoryDao(): MemoryDao
    abstract fun eventDao(): EventDao
    abstract fun routineDao(): RoutineDao
    abstract fun conversationDao(): ConversationDao
    abstract fun notificationDao(): NotificationDao
    abstract fun settingDao(): SettingDao
    abstract fun auditDao(): AuditDao

    companion object {
        const val NOME_ARQUIVO = "alan_assistant.db"

        /** Vazio na v1. Ver instruções no cabeçalho desta classe. */
        val MIGRATIONS: Array<Migration> = arrayOf()

        @Volatile
        private var instancia: AlanDatabase? = null

        fun get(context: Context): AlanDatabase =
            instancia ?: synchronized(this) {
                instancia ?: construir(context.applicationContext).also { instancia = it }
            }

        private fun construir(context: Context): AlanDatabase =
            Room.databaseBuilder(context, AlanDatabase::class.java, NOME_ARQUIVO)
                .addMigrations(*MIGRATIONS)
                // Sem fallbackToDestructiveMigration: dados do Alan são sagrados.
                .build()

        /** Usado pelo backup/restauração para reabrir o banco depois de trocar o arquivo. */
        fun fechar() {
            synchronized(this) {
                instancia?.let { if (it.isOpen) it.close() }
                instancia = null
            }
        }

        @Suppress("unused")
        private fun exemploDeMigracao() = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Exemplo real (não utilizado na v1):
                // db.execSQL("ALTER TABLE tasks ADD COLUMN projeto TEXT")
            }
        }
    }
}
