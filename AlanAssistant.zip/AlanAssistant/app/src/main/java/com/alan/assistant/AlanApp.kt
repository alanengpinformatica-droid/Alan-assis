package com.alan.assistant

import android.app.Application
import android.util.Log
import com.alan.assistant.ai.AiInterpreter
import com.alan.assistant.ai.CompositeInterpreter
import com.alan.assistant.alarm.ReminderScheduler
import com.alan.assistant.backup.BackupManager
import com.alan.assistant.core.AssistantEngine
import com.alan.assistant.core.ConversationPort
import com.alan.assistant.core.Interpreter
import com.alan.assistant.core.RuleBasedInterpreter
import com.alan.assistant.core.SystemClockPort
import com.alan.assistant.core.USUARIO_PRINCIPAL
import com.alan.assistant.data.AlanDatabase
import com.alan.assistant.data.PrefsPendingStore
import com.alan.assistant.data.RoomAudit
import com.alan.assistant.data.RoomConversations
import com.alan.assistant.data.RoomEventStore
import com.alan.assistant.data.RoomMemoryStore
import com.alan.assistant.data.RoomReminderStore
import com.alan.assistant.data.RoomRoutineStore
import com.alan.assistant.data.RoomTaskStore
import com.alan.assistant.data.Settings
import com.alan.assistant.data.UserEntity
import com.alan.assistant.notify.Notifier
import com.alan.assistant.security.SecretsStore
import com.alan.assistant.voice.Listener
import com.alan.assistant.voice.Speaker
import com.alan.assistant.work.MaintenanceWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.time.ZoneId

/**
 * Injeção de dependências manual.
 *
 * Um app pessoal de um usuário só não precisa de Hilt/Dagger: um container
 * explícito é mais fácil de ler, não gera código e não tem custo de build.
 */
class AppContainer(private val app: Application) {

    val zone: ZoneId = ZoneId.of("America/Sao_Paulo")

    val db: AlanDatabase by lazy { AlanDatabase.get(app) }

    val settings by lazy { Settings(db.settingDao()) }
    val secrets by lazy { SecretsStore(app) }

    val tasks by lazy { RoomTaskStore(db.taskDao()) }
    val reminders by lazy { RoomReminderStore(db.reminderDao()) }
    val memories by lazy { RoomMemoryStore(db.memoryDao()) }
    val events by lazy { RoomEventStore(db.eventDao()) }
    val routines by lazy { RoomRoutineStore(db.routineDao()) }
    val audit by lazy { RoomAudit(db.auditDao()) }
    val conversations: ConversationPort by lazy { RoomConversations(db.conversationDao()) }

    val scheduler by lazy { ReminderScheduler(app) }
    val notifier by lazy { Notifier(app, db.notificationDao()) }
    val pendings by lazy { PrefsPendingStore(app) }
    val clock = SystemClockPort()

    val speaker by lazy { Speaker(app) }
    val listener by lazy { Listener(app) }
    val backup by lazy { BackupManager(app, db) }

    /** Regras offline + IA opcional (a IA só entra quando as regras falham). */
    val interpreter: Interpreter by lazy {
        CompositeInterpreter(
            regras = RuleBasedInterpreter(zone),
            ia = AiInterpreter(
                chaveProvider = { secrets.apiKey() },
                modeloProvider = {
                    settings.getString(Settings.MODELO_IA, AiInterpreter.MODELO_PADRAO)
                        ?: AiInterpreter.MODELO_PADRAO
                },
                zone = zone
            ),
            iaHabilitada = { settings.getBool(Settings.IA_ATIVA, true) && secrets.temApiKey() }
        )
    }

    val engine: AssistantEngine by lazy {
        AssistantEngine(
            interpreter = interpreter,
            tasks = tasks,
            reminders = reminders,
            memories = memories,
            events = events,
            routines = routines,
            audit = audit,
            alarms = scheduler,
            clock = clock,
            pendings = pendings,
            zone = zone
        )
    }
}

class AlanApp : Application() {

    lateinit var container: AppContainer
        private set

    private val escopo = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)

        // Canais de notificação: baratos e idempotentes, podem ser criados já.
        container.notifier.criarCanais()

        escopo.launch {
            try {
                primeiraExecucao()
                container.speaker.ativo = container.settings.getBool(Settings.FALA_ATIVA, true)
                MaintenanceWorker.agendarPeriodico(this@AlanApp)
                MaintenanceWorker.agendarAgora(this@AlanApp)
            } catch (e: Throwable) {
                Log.e(TAG, "Falha na inicialização: ${e.message}", e)
            }
        }
    }

    /**
     * Item 34 do escopo. O nome do Alan já vem configurado — o app nunca
     * pergunta quem é o usuário.
     */
    private fun primeiraExecucao() {
        val c = container
        if (c.settings.getBool(Settings.PRIMEIRA_EXECUCAO, false)) return

        c.db.userDao().upsert(
            UserEntity(
                id = "alan",
                name = USUARIO_PRINCIPAL,
                language = "pt-BR",
                timezone = c.zone.id,
                createdAt = System.currentTimeMillis()
            )
        )

        c.settings.setBool(Settings.FALA_ATIVA, true)
        c.settings.setBool(Settings.IA_ATIVA, true)
        c.settings.setBool(Settings.BLOQUEIO_ATIVO, false)
        c.settings.setHora(Settings.RESUMO_MANHA, 7)
        c.settings.setHora(Settings.RESUMO_NOITE, 21)
        c.settings.setString(Settings.MODELO_IA, AiInterpreter.MODELO_PADRAO)

        c.engine.garantirResumos(horaManha = 7, horaNoite = 21)
        c.audit.registrar("APP_FIRST_RUN", "app", null, "Configuração inicial de $USUARIO_PRINCIPAL")

        c.settings.setBool(Settings.PRIMEIRA_EXECUCAO, true)
    }

    companion object { private const val TAG = "AlanApp" }
}
