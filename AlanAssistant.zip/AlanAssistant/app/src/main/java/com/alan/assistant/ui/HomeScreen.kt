package com.alan.assistant.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp

/**
 * Tela inicial (item 12 do escopo).
 *
 * A conversa ocupa a tela toda; os contadores do dia ficam no topo, num
 * bloco que responde à pergunta "o que eu tenho hoje?" antes mesmo de
 * o Alan perguntar. O botão de falar é o elemento mais pesado da tela —
 * é a ação principal do app e tudo em volta fica discreto de propósito.
 */
@Composable
fun HomeScreen(
    vm: AssistantViewModel,
    aoPedirMicrofone: () -> Unit,
    microfoneLiberado: Boolean
) {
    val estado by vm.estado.collectAsState()
    val contadores by vm.contadores.collectAsState()
    val listState = rememberLazyListState()
    var entrada by remember { mutableStateOf("") }

    LaunchedEffect(estado.conversa.size) {
        if (estado.conversa.isNotEmpty()) {
            listState.animateScrollToItem(estado.conversa.lastIndex)
        }
    }

    Column(Modifier.fillMaxSize()) {

        PainelDoDia(contadores)

        if (!estado.alarmeExatoOk) {
            AvisoAlarme()
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(estado.conversa) { bolha -> BolhaConversa(bolha) }
            if (estado.processando) {
                item {
                    Row(
                        Modifier.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(10.dp))
                        Text("Pensando…", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        estado.erro?.let { msg ->
            Surface(
                color = MaterialTheme.colorScheme.errorContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        msg,
                        Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    TextButton(onClick = { vm.limparErro() }) { Text("Fechar") }
                }
            }
        }

        BarraDeEntrada(
            texto = entrada,
            aoMudar = { entrada = it },
            aoEnviar = {
                vm.enviar(entrada)
                entrada = ""
            },
            ouvindo = estado.ouvindo,
            nivelVoz = estado.nivelVoz,
            aoFalar = {
                if (microfoneLiberado) vm.ouvir() else aoPedirMicrofone()
            }
        )
    }
}

@Composable
private fun PainelDoDia(c: ContadoresHoje) {
    Surface(
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            Text(
                "Hoje",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onPrimary
            )
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Contador("Tarefas", c.tarefas, Modifier.weight(1f))
                Contador("Lembretes", c.lembretes, Modifier.weight(1f))
                Contador("Compromissos", c.compromissos, Modifier.weight(1f))
                Contador(
                    "Atrasadas", c.atrasadas, Modifier.weight(1f),
                    destaque = c.atrasadas > 0
                )
            }
        }
    }
}

@Composable
private fun Contador(rotulo: String, valor: Int, modifier: Modifier, destaque: Boolean = false) {
    Surface(
        color = if (destaque) MaterialTheme.colorScheme.error
        else MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.12f),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
    ) {
        Column(
            Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                valor.toString(),
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onPrimary
            )
            Text(
                rotulo,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
            )
        }
    }
}

@Composable
private fun AvisoAlarme() {
    Surface(color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.fillMaxWidth()) {
        Text(
            "Os alarmes exatos estão desativados para este app. Os lembretes podem atrasar " +
                "alguns minutos. Ajuste em Configurações > Alarmes e lembretes.",
            Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSecondaryContainer
        )
    }
}

@Composable
private fun BolhaConversa(b: Bolha) {
    val corFundo = if (b.doAlan) MaterialTheme.colorScheme.primaryContainer
    else MaterialTheme.colorScheme.surfaceVariant
    val corTexto = if (b.doAlan) MaterialTheme.colorScheme.onPrimaryContainer
    else MaterialTheme.colorScheme.onSurfaceVariant

    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (b.doAlan) Arrangement.End else Arrangement.Start
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = corFundo),
            shape = RoundedCornerShape(
                topStart = 14.dp, topEnd = 14.dp,
                bottomStart = if (b.doAlan) 14.dp else 3.dp,
                bottomEnd = if (b.doAlan) 3.dp else 14.dp
            ),
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text(b.texto, style = MaterialTheme.typography.bodyLarge, color = corTexto)
                Spacer(Modifier.height(4.dp))
                Text(
                    b.hora,
                    style = MaterialTheme.typography.bodyMedium,
                    color = corTexto.copy(alpha = 0.6f)
                )
            }
        }
    }
}

@Composable
private fun BarraDeEntrada(
    texto: String,
    aoMudar: (String) -> Unit,
    aoEnviar: () -> Unit,
    ouvindo: Boolean,
    nivelVoz: Float,
    aoFalar: () -> Unit
) {
    val escala by animateFloatAsState(
        targetValue = if (ouvindo) 1f + (nivelVoz / 40f) else 1f,
        label = "pulso"
    )

    Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {

            Button(
                onClick = aoFalar,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .scale(escala),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (ouvindo) MaterialTheme.colorScheme.secondary
                    else MaterialTheme.colorScheme.primary
                )
            ) {
                Text(
                    if (ouvindo) "Ouvindo… toque para parar" else "Falar com o Alan Assistant",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = texto,
                    onValueChange = aoMudar,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Ou escreva aqui") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                        imeAction = ImeAction.Send
                    ),
                    keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                        onSend = { if (texto.isNotBlank()) aoEnviar() }
                    )
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = aoEnviar,
                    enabled = texto.isNotBlank(),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.height(56.dp)
                ) {
                    Text("Enviar")
                }
            }
        }
    }
}
