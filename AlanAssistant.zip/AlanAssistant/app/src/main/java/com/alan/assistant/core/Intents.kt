package com.alan.assistant.core

/**
 * Intenção estruturada — o contrato entre a camada de interpretação
 * (regras ou IA) e o motor de negócio.
 *
 * A IA NUNCA fala com o banco: ela só produz um ParsedIntent, que passa
 * obrigatoriamente pelo IntentValidator antes de virar ação (item 15).
 */
data class ParsedIntent(
    val type: IntentType,
    val title: String? = null,
    /** Momento alvo em epoch millis (já no fuso do usuário). */
    val whenAt: Long? = null,
    val hasTime: Boolean = false,
    val recurrence: Recurrence = Recurrence.NONE,
    val priority: Priority? = null,
    val category: String? = null,
    /** Texto que aponta para um item existente ("o relatório", "essa tarefa"). */
    val targetRef: String? = null,
    val targetId: String? = null,
    val offsetMinutes: Int? = null,
    val content: String? = null,
    val scope: QueryScope = QueryScope.HOJE,
    val confidence: Double = 0.0,
    val rawText: String = "",
    val source: String = "regras"
) {
    fun mergeTitle(t: String) = copy(title = t)
}

data class InterpreterContext(
    /** Títulos de tarefas/lembretes recentes, para desambiguação. */
    val tarefasRecentes: List<Pair<String, String>> = emptyList(), // id to título
    val lembretesRecentes: List<Pair<String, String>> = emptyList(),
    val nowMillis: Long = System.currentTimeMillis()
)

/** Porta de interpretação. Implementada por regras (offline) e por IA (opcional). */
interface Interpreter {
    fun interpret(texto: String, ctx: InterpreterContext): ParsedIntent
}
