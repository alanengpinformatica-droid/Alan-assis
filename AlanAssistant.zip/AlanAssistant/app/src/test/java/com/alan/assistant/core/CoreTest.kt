package com.alan.assistant.core

import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * TESTES DO NÚCLEO (item 30 do escopo).
 *
 * São 107 verificações cobrindo parser de datas em português, recorrência,
 * classificação de intenção, fluxo completo do motor com banco em memória,
 * desambiguação, disparo e reagendamento de lembretes, recuperação após
 * reinicialização do celular, resumos e validação de entradas inválidas.
 *
 * Rodam na JVM, sem emulador:  ./gradlew testDebugUnitTest
 *
 * A data-base de todos os testes é quarta-feira, 23/09/2026 às 08:30,
 * no fuso America/Sao_Paulo — assim "amanhã", "sexta" e "todo dia 30"
 * têm resultados previsíveis e o teste nunca quebra por passar do tempo.
 */
class CoreTest {

    private val ZONE: ZoneId = ZoneId.of("America/Sao_Paulo")
    private val agora: LocalDateTime = LocalDateTime.of(2026, 9, 23, 8, 30)
    private val agoraMs: Long = ms(agora)

    private fun ms(dt: LocalDateTime): Long = dt.atZone(ZONE).toInstant().toEpochMilli()
    private fun ldt(m: Long): LocalDateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(m), ZONE)
    private fun p(txt: String) = PtBrDateTime.parse(txt, agora)

    private fun check(nome: String, cond: Boolean, extra: String = "") {
        assertTrue(if (extra.isBlank()) nome else "$nome -> $extra", cond)
    }

    @Test
    fun parserDeDataEHoraEmPortugues() {

        p("me lembra daqui a 30 minutos de verificar o relatorio").let {
            check("daqui a 30 minutos", it.dateTime == agora.plusMinutes(30), "${it.dateTime}")
            check("offset preciso", it.offsetMinutes == 30, "${it.offsetMinutes}")
        }
        check("daqui a 1 hora", p("me lembra daqui a 1 hora").dateTime == agora.plusHours(1))
        check("daqui a 3 horas", p("daqui a 3 horas").dateTime == agora.plusHours(3))
        check("daqui a meia hora", p("daqui a meia hora").dateTime == agora.plusMinutes(30))
        check("daqui a 15 dias", p("daqui a 15 dias").dateTime?.toLocalDate() == agora.plusDays(15).toLocalDate())

        p("me lembra amanhã às 14h de enviar o relatório").let {
            check("amanhã às 14h", it.dateTime == LocalDateTime.of(2026, 9, 24, 14, 0), "${it.dateTime}")
            check("hora explícita", it.hasExplicitTime)
        }
        check("amanhã de manhã", p("amanhã de manhã").dateTime == LocalDateTime.of(2026, 9, 24, 8, 0))
        check("amanhã à tarde", p("amanhã à tarde").dateTime == LocalDateTime.of(2026, 9, 24, 14, 0))
        check("amanhã à noite", p("amanhã à noite").dateTime == LocalDateTime.of(2026, 9, 24, 20, 0))
        check("às 10 da manhã (amanhã)", p("amanhã às 10 da manhã").dateTime == LocalDateTime.of(2026, 9, 24, 10, 0))
        check("às 2 da tarde", p("me lembra às 2 da tarde").dateTime == LocalDateTime.of(2026, 9, 23, 14, 0),
            "${p("me lembra às 2 da tarde").dateTime}")
        check("meio-dia", p("me lembra ao meio-dia").dateTime == LocalDateTime.of(2026, 9, 23, 12, 0))
        check("hora já passada vai p/ amanhã", p("me lembra às 7h").dateTime == LocalDateTime.of(2026, 9, 24, 7, 0),
            "${p("me lembra às 7h").dateTime}")
        check("16h hoje", p("me lembra às 16h de enviar o relatório").dateTime == LocalDateTime.of(2026, 9, 23, 16, 0))
        check("14:30", p("me lembra às 14:30").dateTime == LocalDateTime.of(2026, 9, 23, 14, 30))
        check("depois de amanhã", p("depois de amanhã").dateTime?.toLocalDate() == agora.plusDays(2).toLocalDate())
        check("segunda-feira", p("segunda-feira às 9h").dateTime == LocalDateTime.of(2026, 9, 28, 9, 0),
            "${p("segunda-feira às 9h").dateTime}")
        check("sexta (até sexta)", p("até sexta").dateTime?.toLocalDate() == java.time.LocalDate.of(2026, 9, 25),
            "${p("até sexta").dateTime}")
        check("próxima semana", p("próxima semana").dateTime?.toLocalDate() == agora.plusWeeks(1).toLocalDate())
        check("dia 30", p("dia 30 às 10h").dateTime == LocalDateTime.of(2026, 9, 30, 10, 0),
            "${p("dia 30 às 10h").dateTime}")
        check("dia 5 (mês que vem)", p("dia 5 às 10h").dateTime == LocalDateTime.of(2026, 10, 5, 10, 0),
            "${p("dia 5 às 10h").dateTime}")
        check("data 15/12", p("15/12 às 8h").dateTime == LocalDateTime.of(2026, 12, 15, 8, 0))
    }

    @Test
    fun recorrencia() {
        p("todo dia às 7 horas me lembra de revisar minhas tarefas").let {
            check("todo dia", it.recurrence.type == RecurrenceType.DAILY, it.recurrence.encode())
            check("primeiro disparo diário", it.dateTime == LocalDateTime.of(2026, 9, 24, 7, 0), "${it.dateTime}")
        }
        p("toda sexta às 16h me lembra de fazer o fechamento semanal").let {
            check("toda sexta", it.recurrence.type == RecurrenceType.WEEKLY &&
                it.recurrence.daysOfWeek == setOf(java.time.DayOfWeek.FRIDAY), it.recurrence.encode())
            check("primeiro disparo semanal", it.dateTime == LocalDateTime.of(2026, 9, 25, 16, 0), "${it.dateTime}")
        }
        check("toda segunda-feira", p("toda segunda-feira às 8h").recurrence.daysOfWeek ==
            setOf(java.time.DayOfWeek.MONDAY))
        check("a cada 2 horas", p("me lembra a cada 2 horas").recurrence.intervalMinutes == 120)
        check("todo mês", p("todo mês às 9h").recurrence.type == RecurrenceType.MONTHLY_DAY)
        check("todo dia 30", p("todo dia 30 às 9h").recurrence.dayOfMonth == 30,
            p("todo dia 30 às 9h").recurrence.encode())
        check("primeiro dia útil do mês",
            p("primeiro dia útil do mês às 9h").recurrence.type == RecurrenceType.FIRST_BUSINESS_DAY)
        check("toda semana", p("toda semana às 10h").recurrence.type == RecurrenceType.WEEKLY)

        // 1º dia útil de outubro/2026 = quinta 01/10
        check("1º dia útil calculado",
            Recurrence(RecurrenceType.FIRST_BUSINESS_DAY).next(agora, java.time.LocalTime.of(9, 0)) ==
                LocalDateTime.of(2026, 10, 1, 9, 0),
            "${Recurrence(RecurrenceType.FIRST_BUSINESS_DAY).next(agora, java.time.LocalTime.of(9, 0))}")
        check("encode/decode recorrência",
            Recurrence.decode(Recurrence(RecurrenceType.WEEKLY,
                daysOfWeek = setOf(java.time.DayOfWeek.MONDAY, java.time.DayOfWeek.FRIDAY)).encode()).daysOfWeek.size == 2)
        check("mensal dia 31 em fevereiro",
            Recurrence(RecurrenceType.MONTHLY_DAY, dayOfMonth = 31)
                .next(LocalDateTime.of(2027, 1, 31, 12, 0), java.time.LocalTime.of(9, 0))
                ?.toLocalDate() == java.time.LocalDate.of(2027, 2, 28),
            "${Recurrence(RecurrenceType.MONTHLY_DAY, dayOfMonth = 31).next(LocalDateTime.of(2027,1,31,12,0), java.time.LocalTime.of(9,0))}")
    }

    @Test
    fun classificacaoDeIntencaoETitulo() {
        val interp = RuleBasedInterpreter(ZONE)
        val ctx = InterpreterContext(nowMillis = agoraMs)
        fun i(t: String) = interp.interpret(t, ctx)

        i("Me lembra daqui a 30 minutos de verificar o relatório.").let {
            check("intent lembrete", it.type == IntentType.CREATE_REMINDER, it.type.name)
            check("título lembrete", it.title == "Verificar o relatório", "'${it.title}'")
        }
        i("Anota que preciso terminar o sistema DMR até sexta.").let {
            check("intent tarefa", it.type == IntentType.CREATE_TASK, it.type.name)
            check("título tarefa", it.title == "Terminar o sistema DMR", "'${it.title}'")
        }
        i("Todo dia às 7 horas me lembra de revisar minhas tarefas.").let {
            check("intent recorrente", it.type == IntentType.CREATE_RECURRING_REMINDER, it.type.name)
            check("título recorrente", it.title == "Revisar minhas tarefas", "'${it.title}'")
        }
        i("Amanhã às 10 da manhã preciso conversar com a Lidiane.").let {
            check("intent compromisso", it.type == IntentType.CREATE_EVENT, it.type.name)
            check("título compromisso", it.title == "Conversar com a Lidiane", "'${it.title}'")
        }
        i("Não posso esquecer de mandar aquele e-mail amanhã.").let {
            // Item 36 do escopo: isso é um LEMBRETE, e sem hora o assistente pergunta.
            check("intent esquecer->lembrete", it.type == IntentType.CREATE_REMINDER, it.type.name)
            check("título esquecer", it.title == "Mandar aquele e-mail", "'${it.title}'")
        }
        i("Tenho que terminar o sistema de backup até sexta.").let {
            check("intent tenho que", it.type == IntentType.CREATE_TASK, it.type.name)
            check("título tenho que", it.title == "Terminar o sistema de backup", "'${it.title}'")
        }
        check("query atrasadas", i("Quais tarefas estão atrasadas?").scope == QueryScope.ATRASADAS)
        check("query atrasado", i("O que está atrasado?").type == IntentType.QUERY_TASKS)
        check("resumo hoje", i("O que eu tenho para hoje?").type == IntentType.DAILY_SUMMARY)
        check("bom dia", i("Bom dia").type == IntentType.DAILY_SUMMARY)
        check("lembretes", i("O que eu pedi para você lembrar?").type == IntentType.QUERY_REMINDERS)
        check("memória consulta", i("O que você lembra sobre mim?").type == IntentType.QUERY_MEMORY)
        check("memória salvar", i("Lembre que meu nome é Alan.").type == IntentType.SAVE_MEMORY)
        check("memória conteúdo", i("Lembre que meu nome é Alan.").content == "Meu nome é Alan",
            "'${i("Lembre que meu nome é Alan.").content}'")
        i("Guarde que toda sexta-feira faço o fechamento semanal.").let {
            check("memória com recorrência", it.type == IntentType.SAVE_MEMORY, it.type.name)
        }
        check("concluir", i("Conclua a tarefa do relatório.").type == IntentType.COMPLETE_TASK)
        check("alvo concluir", i("Conclua a tarefa do relatório.").targetRef == "Relatório",
            "'${i("Conclua a tarefa do relatório.").targetRef}'")
        check("adiar lembrete", i("Adie esse lembrete para amanhã.").type == IntentType.POSTPONE_REMINDER)
        check("não confunde lembrar-de-concluir",
            i("Me lembra de concluir o relatório às 15h").type == IntentType.CREATE_REMINDER,
            i("Me lembra de concluir o relatório às 15h").type.name)
        check("adia uma hora", i("Adia uma hora").offsetMinutes == 60, "${i("Adia uma hora").offsetMinutes}")
        check("prioridade urgente", i("Anota que preciso pagar o boleto, é urgente").priority == Priority.URGENTE)
    }

    @Test
    fun fluxoCompletoComBancoEmMemoria() {
        var bed = TestBed(agoraMs)

        bed.diga("Me lembra amanhã às 10h de enviar o relatório.").let {
            check("cria lembrete", bed.reminders.itens.size == 1, it.text)
            check("alarme agendado", bed.alarms.agendados.size == 1)
            check("resposta confirma", it.text.contains("amanhã às 10:00"), it.text)
        }

        bed.diga("Me lembra de enviar o relatório.").let {
            check("pergunta quando", it.pending?.missingSlot == Slot.DATA_HORA, it.text)
        }
        bed.diga("às 15h").let {
            check("completa após pergunta", bed.reminders.itens.size == 2, it.text)
            check("horário correto",
                bed.reminders.itens.values.any { r -> ldt(r.triggerAt) == LocalDateTime.of(2026, 9, 23, 15, 0) },
                bed.reminders.itens.values.joinToString { ldt(it.triggerAt).toString() })
        }

        bed.diga("Me lembra amanhã.").let {
            check("pergunta o quê", it.pending?.missingSlot == Slot.TITULO, it.text)
        }
        bed.diga("de revisar o contrato").let {
            check("pergunta o horário depois do título", it.pending?.missingSlot == Slot.HORA, it.text)
        }
        bed.diga("às 11h").let {
            check("título preenchido",
                bed.reminders.itens.values.any { r -> r.title == "Revisar o contrato" },
                bed.reminders.itens.values.joinToString { it.title })
            check("dia preservado na resposta só com hora",
                bed.reminders.itens.values.any { r -> ldt(r.triggerAt) == LocalDateTime.of(2026, 9, 24, 11, 0) },
                bed.reminders.itens.values.joinToString { ldt(it.triggerAt).toString() })
        }

        // Item 36 completo: frase sem horário -> pergunta -> "não" usa o padrão
        val bed36 = TestBed(agoraMs)
        bed36.diga("Não posso esquecer de mandar aquele e-mail amanhã.").let {
            check("item 36 pergunta a hora", it.pending?.missingSlot == Slot.HORA, it.text)
        }
        bed36.diga("não").let {
            check("item 36 'não' cria com padrão 09:00",
                bed36.reminders.itens.values.singleOrNull()?.let { r -> ldt(r.triggerAt) } ==
                    LocalDateTime.of(2026, 9, 24, 9, 0),
                bed36.reminders.itens.values.joinToString { ldt(it.triggerAt).toString() })
        }

        bed = TestBed(agoraMs)
        bed.diga("Anota que preciso terminar o sistema DMR até sexta.").let {
            check("tarefa criada", bed.tasks.itens.size == 1, it.text)
            check("oferece lembrete", it.pending?.missingSlot == Slot.HORA, it.text)
        }
        bed.diga("não precisa").let {
            check("negativa encerra", bed.reminders.itens.isEmpty(), it.text)
        }
        bed.diga("Conclua a tarefa do sistema DMR.").let {
            check("conclui tarefa",
                bed.tasks.itens.values.first().status == TaskStatus.CONCLUIDA, it.text)
        }

        bed = TestBed(agoraMs)
        bed.diga("Anota que preciso enviar o relatório amanhã")
        bed.diga("sim, às 9h")
        check("lembrete vinculado ao prazo", bed.reminders.itens.size == 1,
            bed.reminders.itens.values.joinToString { it.title })
        check("lembrete aponta para a tarefa",
            bed.reminders.itens.values.first().taskId == bed.tasks.itens.values.first().id)
        check("lembrete herda o dia do prazo",
            ldt(bed.reminders.itens.values.first().triggerAt) == LocalDateTime.of(2026, 9, 24, 9, 0),
            ldt(bed.reminders.itens.values.first().triggerAt).toString())
    }

    @Test
    fun desambiguacaoDeAlvo() {
        var bed = TestBed(agoraMs)
        bed.diga("Anota que preciso revisar o relatório mensal")
        bed.diga("Anota que preciso enviar o relatório do CIP")
        bed.diga("Conclua o relatório").let {
            check("pergunta qual", it.pending?.missingSlot == Slot.ALVO, it.text)
            check("mostra opções", it.text.contains("1)") && it.text.contains("2)"), it.text)
        }
        bed.diga("o do CIP").let {
            check("escolhe pelo texto",
                bed.tasks.itens.values.any { t -> t.title.contains("CIP") && t.status == TaskStatus.CONCLUIDA },
                bed.tasks.itens.values.joinToString { "${it.title}=${it.status}" })
        }
    }

    @Test
    fun disparoEReagendamentoDeRecorrentes() {
        var bed = TestBed(agoraMs)
        bed.diga("Toda sexta às 16h me lembra de fazer o fechamento semanal.")
        val rec = bed.reminders.itens.values.first()
        check("lembrete recorrente salvo", rec.recurrence.type == RecurrenceType.WEEKLY)
        check("primeiro disparo 25/09 16h", ldt(rec.triggerAt) == LocalDateTime.of(2026, 9, 25, 16, 0),
            ldt(rec.triggerAt).toString())

        bed.clock.agora = ms(LocalDateTime.of(2026, 9, 25, 16, 0))
        val disp = bed.engine.dispararLembrete(rec.id)
        check("disparo gera texto", disp != null && disp.texto.contains("fechamento"), disp?.texto ?: "null")
        check("reagendou para 02/10",
            ldt(bed.reminders.itens.getValue(rec.id).triggerAt) == LocalDateTime.of(2026, 10, 2, 16, 0),
            ldt(bed.reminders.itens.getValue(rec.id).triggerAt).toString())
        check("alarme reagendado", bed.alarms.agendados.containsKey(rec.id))

        // Lembrete simples desativa após disparar
        bed = TestBed(agoraMs)
        bed.diga("Me lembra às 16h de enviar o relatório")
        val simples = bed.reminders.itens.values.first()
        bed.clock.agora = ms(LocalDateTime.of(2026, 9, 23, 16, 0))
        bed.engine.dispararLembrete(simples.id)
        check("lembrete simples desativa", !bed.reminders.itens.getValue(simples.id).active)

        // Snooze
        bed.engine.adiarLembrete(simples.id, 30)
        check("adiar 30 min reativa",
            bed.reminders.itens.getValue(simples.id).active &&
                ldt(bed.reminders.itens.getValue(simples.id).triggerAt) == LocalDateTime.of(2026, 9, 23, 16, 30),
            ldt(bed.reminders.itens.getValue(simples.id).triggerAt).toString())
    }

    @Test
    fun recuperacaoAposReinicializacao() {
        var bed = TestBed(agoraMs)
        bed.diga("Me lembra às 16h de enviar o relatório")
        bed.diga("Me lembra amanhã às 9h de ligar para o cliente")
        bed.alarms.agendados.clear()          // simula reboot: alarmes do SO somem
        bed.clock.agora = ms(LocalDateTime.of(2026, 9, 23, 17, 0))  // ligou depois do 1º horário
        val perdidos = bed.engine.reagendarTudo()
        check("reagendou os futuros", bed.alarms.agendados.size == 1, "${bed.alarms.agendados.size}")
        check("detectou o perdido", perdidos.size == 1 && perdidos.first().title.contains("relatório"),
            perdidos.joinToString { it.title })
    }

    @Test
    fun resumosEConsultas() {
        var bed = TestBed(agoraMs)
        bed.diga("Anota que preciso enviar o relatório hoje às 11h")
        bed.diga("Anota que preciso revisar o contrato hoje às 15h")
        bed.diga("Anota que preciso pagar o boleto, é urgente")
        bed.diga("Amanhã às 10h reunião com a equipe")
        bed.diga("O que eu tenho para hoje?").let {
            check("resumo lista tarefas", it.text.contains("2 tarefas"), it.text.replace("\n", " | "))
            check("resumo tem prioridades", it.text.contains("Prioridades"), it.text.replace("\n", " | "))
        }
        bed.clock.agora = ms(LocalDateTime.of(2026, 9, 23, 23, 0))
        bed.diga("O que está atrasado?").let {
            check("detecta atrasadas", it.text.contains("atrasada", true), it.text.replace("\n", " | "))
        }

        bed = TestBed(agoraMs)
        bed.diga("Lembre que meu nome é Alan.")
        bed.diga("Guarde que toda sexta-feira faço o fechamento semanal.")
        bed.diga("O que você lembra sobre mim?").let {
            check("memória lista 2 itens",
                it.text.contains("Meu nome é Alan") && it.text.contains("fechamento"),
                it.text.replace("\n", " | "))
        }
    }

    @Test
    fun resumosAutomaticosAgendados() {
        var bed = TestBed(agoraMs)
        bed.engine.garantirResumos(7, 21)
        check("2 resumos agendados", bed.reminders.itens.size == 2, "${bed.reminders.itens.size}")
        check("resumo manhã amanhã 07h",
            bed.reminders.itens.values.any { ldt(it.triggerAt) == LocalDateTime.of(2026, 9, 24, 7, 0) },
            bed.reminders.itens.values.joinToString { ldt(it.triggerAt).toString() })
        check("resumo noite hoje 21h",
            bed.reminders.itens.values.any { ldt(it.triggerAt) == LocalDateTime.of(2026, 9, 23, 21, 0) })
        bed.engine.garantirResumos(7, 21)
        check("idempotente", bed.reminders.itens.size == 2, "${bed.reminders.itens.size}")
        bed.engine.garantirResumos(7, null)
        check("desliga resumo noturno", bed.reminders.itens.size == 1, "${bed.reminders.itens.size}")
    }

    @Test
    fun validacaoDeEntradasInvalidas() {
        var bed = TestBed(agoraMs)
        bed.diga("Me lembra ontem de fazer nada").let {
            check("não agenda no passado", bed.reminders.itens.isEmpty(), it.text)
        }
        check("valida data absurda",
            IntentValidator.validate(
                ParsedIntent(IntentType.CREATE_REMINDER, title = "x", whenAt = agoraMs + 400L * 365 * 86_400_000),
                agoraMs
            ) is IntentValidator.Result.Reject)
        check("sanitiza IA malformada",
            IntentValidator.sanitizeFromAi(
                ParsedIntent(IntentType.CREATE_REMINDER, title = "x", whenAt = -5), agoraMs
            ).whenAt == null)
    }
}
