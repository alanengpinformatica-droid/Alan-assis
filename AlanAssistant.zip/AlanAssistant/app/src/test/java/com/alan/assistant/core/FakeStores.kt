package com.alan.assistant.core

/**
 * Implementações em memória das portas do motor.
 * Permitem testar 100% da lógica de negócio na JVM, sem emulador e sem Room.
 */

class FakeTaskStore : TaskStore {
    val itens = linkedMapOf<String, Task>()
    override fun insert(task: Task) { itens[task.id] = task }
    override fun update(task: Task) { itens[task.id] = task }
    override fun delete(id: String) { itens.remove(id) }
    override fun byId(id: String): Task? = itens[id]
    override fun abertas(): List<Task> = itens.values.filter { it.status.aberta }
    override fun todas(): List<Task> = itens.values.toList()
    override fun comPrazoEntre(inicioMillis: Long, fimMillis: Long): List<Task> =
        itens.values.filter { it.dueAt != null && it.dueAt >= inicioMillis && it.dueAt < fimMillis }
    override fun concluidasEntre(inicioMillis: Long, fimMillis: Long): List<Task> =
        itens.values.filter {
            it.status == TaskStatus.CONCLUIDA && it.completedAt != null &&
                it.completedAt >= inicioMillis && it.completedAt < fimMillis
        }
}

class FakeReminderStore : ReminderStore {
    val itens = linkedMapOf<String, Reminder>()
    override fun insert(reminder: Reminder) { itens[reminder.id] = reminder }
    override fun update(reminder: Reminder) { itens[reminder.id] = reminder }
    override fun delete(id: String) { itens.remove(id) }
    override fun byId(id: String): Reminder? = itens[id]
    override fun ativos(): List<Reminder> = itens.values.filter { it.active }
    override fun ativosEntre(inicioMillis: Long, fimMillis: Long): List<Reminder> =
        itens.values.filter { it.active && it.triggerAt >= inicioMillis && it.triggerAt < fimMillis }
    override fun porTarefa(taskId: String): List<Reminder> = itens.values.filter { it.taskId == taskId }
    override fun porTipo(kind: ReminderKind): List<Reminder> = itens.values.filter { it.kind == kind }
}

class FakeMemoryStore : MemoryStore {
    val itens = linkedMapOf<String, MemoryItem>()
    override fun insert(item: MemoryItem) { itens[item.id] = item }
    override fun update(item: MemoryItem) { itens[item.id] = item }
    override fun delete(id: String) { itens.remove(id) }
    override fun todas(): List<MemoryItem> = itens.values.toList()
    override fun buscar(termo: String): List<MemoryItem> {
        val t = PtBrDateTime.normalize(termo)
        return itens.values.filter { PtBrDateTime.normalize(it.content).contains(t) }
    }
}

class FakeEventStore : EventStore {
    val itens = linkedMapOf<String, EventItem>()
    override fun insert(item: EventItem) { itens[item.id] = item }
    override fun delete(id: String) { itens.remove(id) }
    override fun entre(inicioMillis: Long, fimMillis: Long): List<EventItem> =
        itens.values.filter { it.startAt >= inicioMillis && it.startAt < fimMillis }
}

class FakeRoutineStore : RoutineStore {
    val itens = linkedMapOf<String, RoutineItem>()
    override fun insert(item: RoutineItem) { itens[item.id] = item }
    override fun update(item: RoutineItem) { itens[item.id] = item }
    override fun delete(id: String) { itens.remove(id) }
    override fun ativas(): List<RoutineItem> = itens.values.filter { it.active }
}

class FakeAudit : AuditPort {
    val linhas = mutableListOf<String>()
    override fun registrar(action: String, entityType: String, entityId: String?, detail: String?) {
        linhas.add("$action|$entityType|$entityId|$detail")
    }
}

class FakeAlarms : AlarmPort {
    val agendados = linkedMapOf<String, Long>()
    val cancelados = mutableListOf<String>()
    override fun agendar(reminder: Reminder) { agendados[reminder.id] = reminder.triggerAt }
    override fun cancelar(reminderId: String) {
        agendados.remove(reminderId); cancelados.add(reminderId)
    }
    override fun reagendarTodos(lembretes: List<Reminder>) {
        agendados.clear(); lembretes.forEach { agendados[it.id] = it.triggerAt }
    }
}

class FakeClock(var agora: Long) : ClockPort {
    override fun nowMillis(): Long = agora
    fun avancarMinutos(m: Long) { agora += m * 60_000 }
}

class FakePendings : PendingStore {
    private var atual: PendingRequest? = null
    override fun salvar(pending: PendingRequest?) { atual = pending }
    override fun carregar(): PendingRequest? = atual
}

/** Monta um motor completo com stores em memória. */
class TestBed(agoraMillis: Long, val zone: java.time.ZoneId = java.time.ZoneId.of("America/Sao_Paulo")) {
    val tasks = FakeTaskStore()
    val reminders = FakeReminderStore()
    val memories = FakeMemoryStore()
    val events = FakeEventStore()
    val routines = FakeRoutineStore()
    val audit = FakeAudit()
    val alarms = FakeAlarms()
    val clock = FakeClock(agoraMillis)
    val pendings = FakePendings()
    val engine = AssistantEngine(
        interpreter = RuleBasedInterpreter(zone),
        tasks = tasks,
        reminders = reminders,
        memories = memories,
        events = events,
        routines = routines,
        audit = audit,
        alarms = alarms,
        clock = clock,
        pendings = pendings,
        zone = zone
    )

    fun diga(texto: String): AssistantReply = engine.handle(texto)

    fun local(ms: Long): java.time.LocalDateTime =
        java.time.LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(ms), zone)
}
