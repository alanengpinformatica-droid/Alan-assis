package com.alan.assistant.data

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.alan.assistant.core.AssistantEngine
import com.alan.assistant.core.ClockPort
import com.alan.assistant.core.Ids
import com.alan.assistant.core.PendingRequest
import com.alan.assistant.core.ParsedIntent
import com.alan.assistant.core.Priority
import com.alan.assistant.core.Recurrence
import com.alan.assistant.core.RecurrenceType
import com.alan.assistant.core.Reminder
import com.alan.assistant.core.ReminderKind
import com.alan.assistant.core.RuleBasedInterpreter
import com.alan.assistant.core.Slot
import com.alan.assistant.core.Task
import com.alan.assistant.core.TaskStatus
import com.alan.assistant.core.AlarmPort
import com.alan.assistant.core.IntentType
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Testes do banco de verdade (Room) e da integração com o motor.
 *
 * Roda no emulador ou no próprio celular:  ./gradlew connectedDebugAndroidTest
 *
 * O que estes testes provam:
 *  - que a tabela grava e lê cada campo sem perder nada (inclusive
 *    recorrência e enums, que são salvos como texto);
 *  - que o motor funciona igual com Room e com os fakes;
 *  - que depois de "reiniciar o celular" os alarmes são reconstruídos e os
 *    lembretes perdidos são detectados;
 *  - que a pendência de desambiguação sobrevive ao fechamento do app.
 */
@RunWith(AndroidJUnit4::class)
class DatabaseTest {

    private lateinit var db: AlanDatabase
    private lateinit var tasks: RoomTaskStore
    private lateinit var reminders: RoomReminderStore
    private lateinit var engine: AssistantEngine
    private lateinit var alarmes: AlarmesFalsos

    private val zone: ZoneId = ZoneId.of("America/Sao_Paulo")
    private val base = LocalDateTime.of(2026, 9, 23, 8, 30)
    private val baseMs = base.atZone(zone).toInstant().toEpochMilli()
    private val relogio = RelogioAjustavel(baseMs)

    /** AlarmPort de mentira: registra o que seria agendado no AlarmManager. */
    class AlarmesFalsos : AlarmPort {
        val agendados = mutableMapOf<String, Long>()
        override fun agendar(reminder: Reminder) { agendados[reminder.id] = reminder.triggerAt }
        override fun cancelar(reminderId: String) { agendados.remove(reminderId) }
        override fun reagendarTodos(lembretes: List<Reminder>) {
            agendados.clear(); lembretes.forEach { agendar(it) }
        }
    }

    class RelogioAjustavel(var agora: Long) : ClockPort {
        override fun nowMillis(): Long = agora
    }

    @Before
    fun preparar() {
        val ctx = ApplicationProvider.getApplicationContext<android.content.Context>()
        db = Room.inMemoryDatabaseBuilder(ctx, AlanDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        tasks = RoomTaskStore(db.taskDao())
        reminders = RoomReminderStore(db.reminderDao())
        alarmes = AlarmesFalsos()
        relogio.agora = baseMs

        engine = AssistantEngine(
            interpreter = RuleBasedInterpreter(zone),
            tasks = tasks,
            reminders = reminders,
            memories = RoomMemoryStore(db.memoryDao()),
            events = RoomEventStore(db.eventDao()),
            routines = RoomRoutineStore(db.routineDao()),
            audit = RoomAudit(db.auditDao()),
            alarms = alarmes,
            clock = relogio,
            pendings = PrefsPendingStore(ctx),
            zone = zone
        )
        // Garante que nenhuma pendência de um teste anterior atrapalhe.
        PrefsPendingStore(ctx).salvar(null)
    }

    @After
    fun fechar() {
        db.close()
    }

    // ==================================================================

    @Test
    fun tarefaSobreviveAoBancoSemPerderCampos() {
        val t = Task(
            id = Ids.novo(),
            title = "Enviar o relatório do CIP",
            description = "versão final",
            createdAt = baseMs,
            updatedAt = baseMs,
            dueAt = baseMs + 86_400_000,
            hasTime = true,
            priority = Priority.URGENTE,
            category = "trabalho",
            status = TaskStatus.EM_ANDAMENTO,
            notes = "conferir com a equipe",
            recurrence = Recurrence(RecurrenceType.WEEKLY, daysOfWeek = setOf(DayOfWeek.FRIDAY))
        )
        tasks.insert(t)

        val lido = tasks.byId(t.id)
        assertNotNull(lido)
        assertEquals(t.title, lido!!.title)
        assertEquals(Priority.URGENTE, lido.priority)
        assertEquals(TaskStatus.EM_ANDAMENTO, lido.status)
        assertEquals(RecurrenceType.WEEKLY, lido.recurrence.type)
        assertEquals(setOf(DayOfWeek.FRIDAY), lido.recurrence.daysOfWeek)
        assertEquals(t.dueAt, lido.dueAt)
        assertTrue(lido.hasTime)
    }

    @Test
    fun lembreteRecorrenteSobreviveAoBanco() {
        val r = Reminder(
            id = Ids.novo(),
            title = "Fechamento semanal",
            message = null,
            triggerAt = baseMs + 3_600_000,
            recurrence = Recurrence(RecurrenceType.INTERVAL_MINUTES, intervalMinutes = 120),
            kind = ReminderKind.USER,
            createdAt = baseMs,
            updatedAt = baseMs
        )
        reminders.insert(r)

        val lido = reminders.byId(r.id)
        assertNotNull(lido)
        assertEquals(RecurrenceType.INTERVAL_MINUTES, lido!!.recurrence.type)
        assertEquals(120, lido.recurrence.intervalMinutes)
        assertEquals(1, reminders.ativos().size)
    }

    @Test
    fun motorCriaLembreteNoBancoEAgendaAlarme() {
        val resposta = engine.handle("Me lembra amanhã às 10h de enviar o relatório")

        assertEquals(IntentType.CREATE_REMINDER, resposta.intent)
        assertEquals(1, reminders.ativos().size)
        assertEquals(1, alarmes.agendados.size)

        val salvo = reminders.ativos().first()
        val quando = LocalDateTime.ofInstant(
            java.time.Instant.ofEpochMilli(salvo.triggerAt), zone
        )
        assertEquals(LocalDateTime.of(2026, 9, 24, 10, 0), quando)
    }

    @Test
    fun reagendamentoAposReinicializacaoRecuperaOsPerdidos() {
        engine.handle("Me lembra às 16h de enviar o relatório")
        engine.handle("Me lembra amanhã às 9h de ligar para o cliente")
        assertEquals(2, alarmes.agendados.size)

        // Simula o reboot: os alarmes do sistema somem e o tempo avança.
        alarmes.agendados.clear()
        relogio.agora = LocalDateTime.of(2026, 9, 23, 17, 0)
            .atZone(zone).toInstant().toEpochMilli()

        val perdidos = engine.reagendarTudo()

        assertEquals(1, perdidos.size)
        assertTrue(perdidos.first().title.contains("relatório"))
        assertEquals(1, alarmes.agendados.size)   // só o futuro é reagendado
    }

    @Test
    fun disparoDeRecorrenteReagendaAProximaOcorrencia() {
        engine.handle("Toda sexta às 16h me lembra de fazer o fechamento semanal")
        val r = reminders.ativos().first()

        relogio.agora = LocalDateTime.of(2026, 9, 25, 16, 0)
            .atZone(zone).toInstant().toEpochMilli()
        val disparo = engine.dispararLembrete(r.id)

        assertNotNull(disparo)
        val proximo = LocalDateTime.ofInstant(
            java.time.Instant.ofEpochMilli(reminders.byId(r.id)!!.triggerAt), zone
        )
        assertEquals(LocalDateTime.of(2026, 10, 2, 16, 0), proximo)
        assertTrue(alarmes.agendados.containsKey(r.id))
    }

    @Test
    fun lembreteSimplesDesativaDepoisDeDisparar() {
        engine.handle("Me lembra às 16h de enviar o relatório")
        val r = reminders.ativos().first()

        relogio.agora = LocalDateTime.of(2026, 9, 23, 16, 0)
            .atZone(zone).toInstant().toEpochMilli()
        engine.dispararLembrete(r.id)

        assertFalse(reminders.byId(r.id)!!.active)

        engine.adiarLembrete(r.id, 30)
        assertTrue(reminders.byId(r.id)!!.active)
    }

    @Test
    fun resumosAutomaticosSaoIdempotentes() {
        engine.garantirResumos(7, 21)
        assertEquals(2, reminders.ativos().size)

        engine.garantirResumos(7, 21)
        assertEquals(2, reminders.ativos().size)

        engine.garantirResumos(7, null)
        assertEquals(1, reminders.ativos().size)
    }

    @Test
    fun pendenciaDeDesambiguacaoSobreviveAoFechamentoDoApp() {
        val ctx = ApplicationProvider.getApplicationContext<android.content.Context>()
        val store = PrefsPendingStore(ctx)

        val pendencia = PendingRequest(
            question = "Para quando?",
            missingSlot = Slot.DATA_HORA,
            partial = ParsedIntent(
                type = IntentType.CREATE_REMINDER,
                title = "Enviar o relatório",
                recurrence = Recurrence(RecurrenceType.DAILY),
                rawText = "me lembra de enviar o relatório"
            ),
            options = listOf("Relatório mensal", "Relatório do CIP"),
            executarSeNegativa = true
        )
        store.salvar(pendencia)

        // Nova instância = app reaberto.
        val lido = PrefsPendingStore(ctx).carregar()

        assertNotNull(lido)
        assertEquals(Slot.DATA_HORA, lido!!.missingSlot)
        assertEquals("Enviar o relatório", lido.partial.title)
        assertEquals(RecurrenceType.DAILY, lido.partial.recurrence.type)
        assertEquals(2, lido.options.size)
        assertTrue(lido.executarSeNegativa)

        PrefsPendingStore(ctx).salvar(null)
        assertNull(PrefsPendingStore(ctx).carregar())
    }

    @Test
    fun auditoriaRegistraTudoQueOMotorFaz() {
        engine.handle("Me lembra amanhã às 10h de enviar o relatório")
        engine.handle("Lembre que meu nome é Alan")

        val registros = db.auditDao().ultimos(50)
        assertTrue(registros.isNotEmpty())
        assertTrue(registros.any { it.entityType == "reminder" })
        assertTrue(registros.any { it.entityType == "memory" })
    }

    @Test
    fun consultasPorIntervaloUsamOsIndicesCorretos() {
        val hoje = base.toLocalDate().atStartOfDay().atZone(zone).toInstant().toEpochMilli()
        val fimDeHoje = base.toLocalDate().atTime(23, 59).atZone(zone).toInstant().toEpochMilli()

        tasks.insert(
            Task(
                id = Ids.novo(), title = "Hoje", createdAt = baseMs, updatedAt = baseMs,
                dueAt = baseMs + 3_600_000, hasTime = true
            )
        )
        tasks.insert(
            Task(
                id = Ids.novo(), title = "Semana que vem", createdAt = baseMs, updatedAt = baseMs,
                dueAt = baseMs + 8 * 86_400_000L, hasTime = true
            )
        )

        assertEquals(1, tasks.comPrazoEntre(hoje, fimDeHoje).size)
        assertEquals(2, tasks.abertas().size)
    }
}
