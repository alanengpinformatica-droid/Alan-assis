# Room
-keep class androidx.room.** { *; }
-keep class com.alan.assistant.data.** { *; }
# Modelos do núcleo (usados em reflexão de backup)
-keep class com.alan.assistant.core.** { *; }
# Receivers e Workers precisam sobreviver à ofuscação
-keep class com.alan.assistant.alarm.** { *; }
-keep class com.alan.assistant.work.** { *; }
