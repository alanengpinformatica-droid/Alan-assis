# Como gerar o APK e instalar no seu celular

Dez passos. Do zero ao app instalado.
Não é preciso saber Kotlin — só seguir a ordem.

---

## Passo 1 — Instalar o Android Studio

1. Baixe em <https://developer.android.com/studio> (versão Ladybug ou mais nova).
2. Instale com as opções padrão. Ele já traz o Java necessário (JDK 17).
3. Na primeira abertura, aceite o download do **Android SDK Platform 34** e do
   **Android SDK Build-Tools**. Se ele não perguntar:
   `Settings > Languages & Frameworks > Android SDK`, aba *SDK Platforms*,
   marque **Android 14 (API 34)** e aplique.

Espaço em disco: reserve uns 10 GB.

---

## Passo 2 — Abrir o projeto

1. Descompacte `AlanAssistant.zip`.
2. No Android Studio: **File > Open** e selecione a pasta `AlanAssistant`
   (a que contém `settings.gradle.kts`). Não abra a pasta `app`.
3. Ele vai baixar o Gradle e as dependências. Na primeira vez leva de 5 a 15
   minutos, dependendo da internet.
4. Espere a barra inferior mostrar **Gradle sync finished**.

> Se aparecer erro de versão de alguma dependência, clique na sugestão do
> próprio Android Studio (*Update version*). É esperado: o projeto foi escrito
> fora do Android Studio e o primeiro sync pode pedir um ajuste de versão.

> **Sobre o `gradlew`:** o projeto vem com a configuração do wrapper
> (`gradle/wrapper/gradle-wrapper.properties`), mas não com o binário
> `gradlew` — ele é gerado pelo próprio Android Studio no primeiro sync.
> Se os comandos `./gradlew` dos passos seguintes não funcionarem, use o menu
> **Build > Make Project** e **Build > Build Bundle(s)/APK(s) > Build APK(s)**,
> que fazem exatamente a mesma coisa pela interface.

---

## Passo 3 — Rodar os testes (opcional, mas vale 2 minutos)

No terminal embutido (aba **Terminal**, embaixo):

```bash
./gradlew testDebugUnitTest
```

No Windows, use `gradlew.bat testDebugUnitTest`.

Devem passar 10 testes com 107 verificações. Se passarem, toda a lógica do
assistente está funcionando — antes mesmo de instalar no celular.

---

## Passo 4 — Gerar o APK de teste (debug)

```bash
./gradlew assembleDebug
```

O arquivo sai em:

```
app/build/outputs/apk/debug/app-debug.apk
```

Esse APK serve para uso pessoal e instala direto. Ele tem `.debug` no nome do
pacote, então pode conviver com a versão final no mesmo celular.

---

## Passo 5 — Gerar o APK final assinado (release)

O APK de release é menor, mais rápido e é o que você vai querer manter.
Ele precisa de uma chave de assinatura — **guarde esse arquivo e a senha**,
porque sem eles você não consegue atualizar o app depois.

**5.1. Criar a chave** (uma única vez):

```bash
keytool -genkey -v -keystore alan-assistant.jks \
  -keyalg RSA -keysize 2048 -validity 10000 -alias alan
```

Ele pede uma senha e alguns dados (nome, cidade). Anote a senha.
Guarde o `alan-assistant.jks` fora da pasta do projeto, em lugar seguro.

**5.2. Apontar o projeto para a chave.** Crie o arquivo `keystore.properties`
na raiz do projeto (ao lado de `settings.gradle.kts`):

```properties
storeFile=/caminho/completo/para/alan-assistant.jks
storePassword=SUA_SENHA
keyAlias=alan
keyPassword=SUA_SENHA
```

**5.3. Adicione em `app/build.gradle.kts`**, logo depois da linha
`android {`:

```kotlin
    val propsAssinatura = java.util.Properties().apply {
        val f = rootProject.file("keystore.properties")
        if (f.exists()) load(f.inputStream())
    }

    signingConfigs {
        create("release") {
            if (propsAssinatura.isNotEmpty()) {
                storeFile = file(propsAssinatura.getProperty("storeFile"))
                storePassword = propsAssinatura.getProperty("storePassword")
                keyAlias = propsAssinatura.getProperty("keyAlias")
                keyPassword = propsAssinatura.getProperty("keyPassword")
            }
        }
    }
```

E dentro de `buildTypes { release { ... } }`, acrescente:

```kotlin
            signingConfig = signingConfigs.getByName("release")
```

**5.4. Gerar:**

```bash
./gradlew assembleRelease
```

Saída: `app/build/outputs/apk/release/app-release.apk`

> Nunca coloque `keystore.properties` nem o `.jks` em repositório.

---

## Passo 6 — Instalar no celular

**Opção A — cabo USB (mais simples):**

1. No celular: *Configurações > Sobre o telefone* e toque 7 vezes em
   **Número da versão** para liberar as Opções do desenvolvedor.
2. *Configurações > Sistema > Opções do desenvolvedor* e ative
   **Depuração USB**.
3. Conecte o cabo e autorize o computador na janela que aparece no celular.
4. No Android Studio, escolha seu aparelho no topo e clique em **Run** (▶),
   ou pelo terminal:

```bash
./gradlew installDebug
```

**Opção B — mandar o arquivo:**

1. Copie o `.apk` para o celular (cabo, Google Drive, e-mail para si mesmo).
2. Abra o arquivo pelo gerenciador de arquivos do celular.
3. Autorize **Instalar apps desconhecidos** para o aplicativo que está abrindo
   o APK (normalmente o Arquivos ou o Chrome).

---

## Passo 7 — Permissões na primeira abertura

O app pede três coisas. Aceite todas:

| Permissão | Para quê | Se negar |
|---|---|---|
| **Notificações** | mostrar os lembretes | os lembretes não aparecem — é a mais importante |
| **Microfone** | falar com o assistente | o app continua funcionando por texto |
| **Alarmes e lembretes** | tocar na hora exata | os lembretes podem atrasar alguns minutos |

A permissão de alarme exato costuma vir concedida na instalação. Para conferir:
*Configurações do Android > Apps > Alan Assistant > Alarmes e lembretes*.
O app também avisa na tela inicial se ela estiver desligada, e a tela de
Ajustes tem um botão que leva direto lá.

---

## Passo 8 — Liberar o app da economia de bateria

**Este passo é o que garante que o lembrete toque.** Se o fabricante do seu
celular for agressivo (Xiaomi, Samsung, Motorola, Oppo, Realme), ele mata
apps em segundo plano.

1. Abra o Alan Assistant, vá em **Ajustes > Lembretes > Bateria**.
2. Escolha **Alan Assistant** e marque **Não otimizar** / **Sem restrições**.

E, no menu do próprio fabricante:

- **Xiaomi/Redmi**: *Configurações > Apps > Alan Assistant > Economia de
  bateria > Sem restrições*, e ative **Inicialização automática**.
- **Samsung**: *Configurações > Bateria > Limites de uso em segundo plano >
  Apps que nunca entram em suspensão* e adicione o app.
- **Motorola**: *Configurações > Bateria > Otimização da bateria >
  Alan Assistant > Não otimizar*.
- **Oppo/Realme**: *Configurações > Bateria > Gerenciamento de bateria do app >
  Alan Assistant > Permitir atividade em segundo plano*.

---

## Passo 9 — Voz em português

O assistente responde falando. Se ele ficar mudo:

1. *Configurações do Android > Sistema > Idiomas e entrada >
   Saída de texto para voz*.
2. Em **Mecanismo preferido**, toque na engrenagem e baixe o pacote de
   **Português (Brasil)**.
3. Volte ao app. Para desligar a fala, use **Ajustes > Voz**.

Para o reconhecimento de fala funcionar offline, em muitos aparelhos é preciso
baixar o idioma em *Configurações > Google > Configurações de apps do Google >
Pesquisa e Assistente > Voz > Reconhecimento de fala offline*.

---

## Passo 10 — Atualizar o app depois

Quando quiser instalar uma versão nova:

1. Em `app/build.gradle.kts`, suba `versionCode` (1 → 2) e `versionName`.
2. Gere de novo: `./gradlew assembleRelease`.
3. Instale por cima — **seus dados são preservados**, desde que a assinatura
   seja a mesma (por isso guardar o `.jks` importa).
4. Se o esquema do banco tiver mudado, a migração precisa estar escrita.
   Veja as instruções no cabeçalho de `AlanDatabase.kt`.

Antes de atualizar, faça um backup: **Ajustes > Backup > Gerar backup**.


---

# Caminho alternativo: compilar sem instalar nada

Se você não tem privilégio de administrador para instalar o Android Studio
(caso comum em máquina corporativa), dá para o **GitHub compilar o APK na
nuvem**. Você só usa o navegador — pode ser até o do celular.

O projeto já vem com o arquivo `.github/workflows/build-apk.yml`, que é a
receita de compilação. Você não precisa editá-lo.

## Passo A — Criar a conta e o repositório

1. Crie uma conta gratuita em <https://github.com>.
2. Clique em **New repository**, dê o nome `alan-assistant`, marque
   **Private** e crie.

Repositório privado: só você enxerga o código.

## Passo B — Enviar o projeto

1. No repositório vazio, clique em **uploading an existing file**.
2. Descompacte o `AlanAssistant.zip` no seu computador.
3. **Arraste a pasta `AlanAssistant` inteira** para dentro da área de upload
   da página. O navegador preserva a estrutura de pastas.
4. Role até o fim e clique em **Commit changes**.

> Atenção: arraste o **conteúdo** da pasta `AlanAssistant` (as pastas `app`,
> `gradle`, `.github` e os arquivos soltos), não a pasta dentro de outra pasta.
> Se o `settings.gradle.kts` não ficar na raiz do repositório, a compilação
> não encontra o projeto.

> A pasta `.github` começa com ponto e alguns sistemas a escondem. No Windows,
> ative *Exibir > Itens ocultos* antes de arrastar.

## Passo C — Compilar

1. Abra a aba **Actions** do repositório.
2. O processo já deve ter começado sozinho. Se não começou, clique em
   **Gerar APK** na lateral e depois em **Run workflow**.
3. Espere de 5 a 10 minutos. O círculo amarelo vira um visto verde.

Ele roda os 107 testes antes de compilar. Se algum falhar, o processo para e
o APK não é gerado — é proposital.

## Passo D — Baixar o APK

1. Clique na execução que terminou com o visto verde.
2. Role até o fim da página, em **Artifacts**, e baixe
   **alan-assistant-apk**.
3. O GitHub entrega um `.zip`. Descompacte para chegar no `app-debug.apk`.

Dá para fazer isso direto do celular: baixe o zip, abra com o app Arquivos,
extraia e toque no `.apk`. A partir daí, siga do **Passo 6** deste guia.

## Para gerar uma versão nova depois

Edite o arquivo pelo site do GitHub (ou envie os arquivos alterados) e a
compilação dispara sozinha. Não é preciso repetir nada dos passos acima.

---

# Caminho alternativo 2: Android Studio sem instalador

Se preferir compilar na sua máquina e o bloqueio for só o instalador `.exe`,
a página de download tem a opção **"no .exe"** — um `.zip` que você descompacta
na sua pasta de usuário e roda por `bin\studio64.exe`, sem administrador.
O SDK também vai para a sua pasta pessoal.

Dois avisos honestos: alguns ambientes corporativos bloqueiam executáveis
rodando de pasta de usuário (política AppLocker), e o proxy da rede pode
barrar os downloads do Gradle e do Maven. Se qualquer um dos dois acontecer,
o caminho do GitHub acima resolve sem depender da máquina da empresa.

---

# Checklist de testes manuais

Depois de instalar, leve uns 15 minutos para rodar esta lista. Ela cobre os
pontos onde um app de lembretes costuma falhar de verdade.

## Básico

- [ ] Abrir o app e ver a saudação com o seu nome
- [ ] Dizer "**Me lembra daqui a 2 minutos de testar o app**" e receber a
      notificação em 2 minutos
- [ ] Tocar em **Adiar 30 min** na notificação e conferir na aba Lembretes
- [ ] Dizer "**Anota que preciso enviar o relatório amanhã às 10h**" e
      responder "sim" quando ele oferecer o lembrete
- [ ] Marcar a tarefa como concluída na aba Tarefas e ver o lembrete sumir
- [ ] Dizer "**O que eu tenho para hoje?**" e conferir o resumo

## Voz

- [ ] Tocar em **Falar com o Alan Assistant** e falar um comando
- [ ] Conferir se ele responde falando
- [ ] Desligar a fala em Ajustes e conferir que ele só escreve
- [ ] Ativar modo avião e conferir que os comandos do dia a dia continuam
      funcionando por texto

## Confiabilidade (os testes que realmente importam)

- [ ] Criar um lembrete para daqui a 5 minutos, **fechar o app** (deslizar para
      fora dos recentes) e esperar — a notificação precisa chegar
- [ ] Criar um lembrete para daqui a 10 minutos e **reiniciar o celular** —
      a notificação precisa chegar
- [ ] Criar um lembrete, **desligar o celular** antes da hora, ligar depois —
      o lembrete deve aparecer marcado como *(atrasado)*
- [ ] Criar um lembrete recorrente ("**toda sexta às 16h…**") e conferir na aba
      Lembretes se a próxima data foi reagendada após o primeiro disparo
- [ ] Deixar o celular parado com a tela desligada por 1 hora com um lembrete
      agendado no meio — se não tocar, revise o Passo 8

## Desambiguação e memória

- [ ] Criar duas tarefas com nomes parecidos ("revisar o relatório mensal" e
      "enviar o relatório do CIP")
- [ ] Dizer "**Conclua o relatório**" e conferir se ele pergunta qual
- [ ] Responder "**o do CIP**" e conferir se concluiu a certa
- [ ] Dizer "**Lembre que meu nome é Alan**", fechar o app, reabrir e perguntar
      "**O que você lembra sobre mim?**"

## Resumos e segurança

- [ ] Em Ajustes, colocar o resumo da manhã para daqui a poucos minutos e
      esperar a notificação
- [ ] Ativar o bloqueio por biometria, fechar e reabrir o app
- [ ] Definir um PIN e testar o desbloqueio por PIN
- [ ] Gerar um backup e conferir os arquivos em
      `Android/data/com.alan.assistant/files/backups`

## Recuperação

- [ ] Gerar backup, criar tarefas novas, restaurar o backup e conferir se
      voltou ao estado anterior (o app pede para ser reaberto)

---

Se algum item falhar, o primeiro suspeito é quase sempre o **Passo 8**
(economia de bateria do fabricante) ou a permissão de **alarmes exatos**
do Passo 7.
